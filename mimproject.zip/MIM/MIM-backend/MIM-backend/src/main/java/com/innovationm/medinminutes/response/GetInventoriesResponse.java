package com.innovationm.medinminutes.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class GetInventoriesResponse {

	private long inventoryId;
	
	private boolean activeStatus;

	private String name;

	private String form;

	private String pack;

	private Integer qtyPerPack;

	private String units;

	private double mrp;

	private String prescription;

	private String type;

	private String composition;

	private String manufacture;
	
	private String formUpdateBy;

	private String packUpdateBy;

	private String qtyPerPackUpdateBy;

	private String prescriptionUpdateBy;

	private String saltUpdateBy;

	private String manufactureUpdateBy;

	private String typeUpdateBy;

	private String mrpUpdateBy;

	private String compositionUpdateBy;
	
	private String unitsUpdateBy;
	
	private String nameUpdateBy;

}
