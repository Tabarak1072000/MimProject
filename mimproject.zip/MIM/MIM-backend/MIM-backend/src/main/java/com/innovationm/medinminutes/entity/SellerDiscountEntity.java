package com.innovationm.medinminutes.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "Seller_Discount")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SellerDiscountEntity extends BaseEntity{
	
	private double discountFrom;
	
	private double discountTo;
	
	 @ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH 
				 }, fetch = FetchType.LAZY)
	@JoinColumn(name="category_id",nullable = false)
	private CategoryEntity categoryId;
	
	 @ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH }, fetch = FetchType.LAZY)
	@JoinColumn(name="seller_id" ,nullable = false)
	private SellerOrganisationBranchEntity sellerId;

}
