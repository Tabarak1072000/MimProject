package com.innovationm.medinminutes.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class GetToPackOrderBidsResponse {

	private long sellerBiddingMedicineId;
	
	private String inventoryName;
	
	private String form;

	private String pack;

	private Integer qtyPerPack;

	private String units;
	
	private double mrp;
	
	private int quantityRequired;
	
	private int quantitySellerProvide;
}
