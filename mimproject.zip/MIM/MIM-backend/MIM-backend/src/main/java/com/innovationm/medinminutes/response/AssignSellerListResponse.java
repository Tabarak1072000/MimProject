package com.innovationm.medinminutes.response;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.innovationm.medinminutes.enums.BuzzStatus;
import com.innovationm.medinminutes.enums.SellerStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AssignSellerListResponse {

	private String sellerName;
	private long sellerId;
	private String sellerOrderStatus;
	
	private Boolean action;
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date timeSinceLastAction;
	private String pincode;
	private double sellerlatitude;
	private double sellerlongitude;
	private String sellerNumber;
	private SellerStatus sellerStatus;
	private BuzzStatus buzzedStatus;
	private String appStatus;
	private double discount;
	private double distance;
	
	private GetItemFillRateResponse itemsFillRate;
	private GetSkuFillRateResponse skuFillRate;
	
	private List<BiddingMedicineDetailsResponse> biddingMedicine;
	
}
