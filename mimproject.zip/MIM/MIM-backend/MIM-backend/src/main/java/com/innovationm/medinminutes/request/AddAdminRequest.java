package com.innovationm.medinminutes.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AddAdminRequest {

	private String username;

	private String password;
	
	private String phoneNumber;
	
	private String name;
}
