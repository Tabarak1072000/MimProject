package com.innovationm.medinminutes.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.innovationm.medinminutes.entity.OrderEntity;
import com.innovationm.medinminutes.entity.SellerBiddingEntity;
import com.innovationm.medinminutes.entity.SellerOrganisationBranchEntity;
import com.innovationm.medinminutes.enums.BuzzStatus;
import com.innovationm.medinminutes.enums.SellerStatus;

@Repository
public interface SellerBiddingRepository extends JpaRepository<SellerBiddingEntity, Long> {

	List<SellerBiddingEntity> findByOrderId(Long orderId);

	public List<SellerBiddingEntity> findBySellerAndSellerStatus(SellerOrganisationBranchEntity sellerId,
			SellerStatus sellerStatus);

	public List<SellerBiddingEntity> findBySellerId(long sellerId);

	SellerBiddingEntity findByOrderAndSeller(OrderEntity order, SellerOrganisationBranchEntity seller);

	List<SellerBiddingEntity> findAllByBuzzStatusAndSnoozedBuzzTimeLessThan(BuzzStatus buzzStatus, Date time);

	@Query("Select sb from SellerBiddingEntity sb where sb.order=?1 and sb.seller.id=?2")
	SellerBiddingEntity findByOrderAndSellerId(OrderEntity orderEntity, Long sellerId);

	@Query("Select sb from SellerBiddingEntity sb where ( sb.seller=:seller ) and (sb.sellerStatus=:sellerStatus OR sb.sellerStatus='TOPACKDONE' )")
	List<SellerBiddingEntity> findBySellerAndSellerStatusPackedAndToPacKDone(SellerOrganisationBranchEntity seller,
			SellerStatus sellerStatus);
}
