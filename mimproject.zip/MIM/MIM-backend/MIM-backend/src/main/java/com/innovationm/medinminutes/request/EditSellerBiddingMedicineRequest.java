package com.innovationm.medinminutes.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EditSellerBiddingMedicineRequest {

	private long sellerBiddingMedicineId;

	private int quantityPacked;
}
