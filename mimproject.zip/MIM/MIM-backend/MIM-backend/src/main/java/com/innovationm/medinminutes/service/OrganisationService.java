package com.innovationm.medinminutes.service;

import java.util.List;

import com.innovationm.medinminutes.entity.SellerOrganisationBranchEntity;
import com.innovationm.medinminutes.request.DiscountRequest;
import com.innovationm.medinminutes.request.GetSellerListRequest;
import com.innovationm.medinminutes.request.OrganisationSignUpRequest;
import com.innovationm.medinminutes.request.UpdateSellerRequest;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.SellerDetailListResponse;
import com.innovationm.medinminutes.response.SellerDetailResponse;
import com.innovationm.medinminutes.response.SellerDiscountResponse;
import com.innovationm.medinminutes.response.SellerProfileResponse;

public interface OrganisationService {

	public SellerProfileResponse createOrganisation(OrganisationSignUpRequest organisationSignUpRequest);

	public SellerDetailResponse getSellerDetail(Long sellerId);

	public SellerDetailListResponse getSellerList(GetSellerListRequest getSellerListRequest);

	public SellerDiscountResponse sellerDiscount(DiscountRequest discount);

	public CommonSuccessResponse updateSeller(UpdateSellerRequest updateSellerRequest);
	
	public SellerOrganisationBranchEntity getSellerOrganisationByUserID(Long userId);

	SellerOrganisationBranchEntity getSellerOrganizationBranchEntity(Long sellerId);
	

}
