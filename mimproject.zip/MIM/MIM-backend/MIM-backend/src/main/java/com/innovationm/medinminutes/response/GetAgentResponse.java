package com.innovationm.medinminutes.response;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class GetAgentResponse {

	private long userId;

	private String name;

	private String email;

	private String phoneNumber;

	private String password;
	
	private boolean activeStatus;
	
	private Date startDate;
	
	private Date endDate;
	
	private String alternateMobileNo;
	
	private String LMB;
}
