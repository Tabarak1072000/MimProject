package com.innovationm.medinminutes.fcm;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
public class FirebaseRequestNotificationModel {
	
	private String title;

    private String body;

    private String priority;
    
    public FirebaseRequestNotificationModel() {
    }

    public FirebaseRequestNotificationModel(String title, String body, String priority) {
        this.title = title;
        this.body = body;
        this.priority = priority;
    }

	@Override
	public String toString() {
        return "FirebaseRequestNotificationModel{" +
                "title='" + title + '\'' +
                ", body='" + body + '\'' +
                ", priority='" + priority + '\'' +
                '}';
    }
    
    

}
