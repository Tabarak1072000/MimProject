package com.innovationm.medinminutes.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class GetItemFillRateResponse {

	private int stockedItemFillRate;

	private int packedItemFillRate;
}
