package com.innovationm.medinminutes.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AddSellerRequest {

	
	private String sellerName;
	private String sellerContact;
	private String address;
	private String city;
	private String pinCode;
	private double latitude;
	private double longitude;
	private String managerName;
	private double minDiscount;
	private double maxDiscount;
	private String gstNo;
    private String bankAccountNo;
    private String benefeciaryName;
    private String ifscCode;
    private String businessName;
	
}
