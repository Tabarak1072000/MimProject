package com.innovationm.medinminutes.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class OrganisationSignUpRequest {

	private long sellerId;
	private String businessName;
	private String branchName;
	private String managerName;
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String pinCode;
	private String referredBy;
	private Long sellerUserId;
}
