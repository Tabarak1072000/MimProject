package com.innovationm.medinminutes.resources;

public interface RestMappingConstants {

	public interface UserInterfaceUri {
		static final String USER_BASE_URI = "/user";
		static final String USER_SELLER_ADD_URI = "/addSeller";
		static final String USER_AGENT_ADD_URI = "/addAgent";
		static final String USER_ADD_URI = "/addSeller";
		static final String VERIFY_USER = "/verifySeller";
		static final String REGISTER_FCM_TOKEN = "/registerFcmToken";
		static final String TO_CHECK_REGISTERED_SELLER = "toCheckRegisteredSeller";
		static final String LOGOUT = "/logout";
		static final String CHECK_REGISTERED_USER_BY_EMAIL = "toCheckRegisteredUserByEmail";
	}

	public interface SellerInterfaceUri {
		static final String SELLER__BASE_URI = "/seller";
		static final String SELLER_ORGANISATION_ADD_URI = "/addSellerOrganisation";
		static final String GET_SELLER_DETAILS = "/getSellerDetails";
		static final String GET_SELLER_LIST = "/getSellerList";
		static final String ADD_SELLER_DISCOUNT = "/addSellerDiscount";
		static final String UPDATE_SELLER = "/updateSeller";
		static final String SELLER_LIST_BY_DISTANCE = "/findSellerListByDistance";

	}

	public interface AgentInterfaceUri {
		static final String AGENT_BASE_URI = "/agent";
		static final String USER_AGENT_ADD_URI = "/addAgent";
		static final String GET_AGENT_LIST = "/getAgentList";
		static final String UPDATE_AGENT = "/updateAgent";
		static final String ENABLE_DISABLE = "/changeAgentStatus";
	}

	public interface AdminInterfaceUri {
		static final String ADMIN__BASE_URI = "/admin";
		static final String APPROVE_SELLER = "/approveSeller";
		static final String ADD_ADMIN = "/addAdmin";
		static final String ADD_SELLER_BY_ADMIN = "/addSellerByAdmin";
	}

	public interface InventoryInterfaceUri {
		static final String INVENTORY__BASE_URI = "/inventory";

		static final String GET_INVENTORIES = "/getInventories";
		static final String GET_ALL_INVENTORIES = "/getAllInventories";
		static final String GET_INVENTORY = "/getInventory";
		static final String GET_ALL_INVENTORY = "/getAllInventory";
		static final String ADD_OR_EDIT_INVENTORY = "/addOrEditInventory";
		static final String ENABLE_DISABLE_INVENTORY = "/changeInventoryStatus";

		static final String GET_INVENTORIES_NAMES =  "/getAllInventoriesName";;
	}

	public interface OrderInterfaceUri {

		// order
		static final String ORDER_BASE_URI = "/order";
		static final String CREATE_ORDER = "/createOrder";
		static final String GET_ORDER = "/getOrder";
		static final String EDIT_ORDER = "/editOrder";

		static final String GET_ESTIMATE_BY_ORDER_ID = "/getEstimateByOrderId";

		static final String GET_CLIENTS_AND_AGENT_NAMES = "/getClientAndAgentNames";

		// items
		static final String ADD_ORDER_ITEMS = "/addOrderItems";
		static final String GET_ORDER_ITEMS = "/getOrderItems";
		static final String DELETE_ORDER_ITEM = "/deleteOrderItems";

		static final String EDIT_INVENTORY = "/editItem";
		static final String GET_ORDER_LIST = "/getOrderList";
		static final String GET_ORDER_DETAILS_BY_ORDER_ID = "/getOrderDetailsByOrderId";

		// seller bid
		static final String SUBMIT_BID = "/submiBid";
		static final String CHANGE_BID_STATUS = "/changeBidStatus";
		static final String GET_SELLER_ORDER_BY_SELLER_AND_STATUS = "/getSellerOrderByStatus";
		static final String GET_BIDDED_ITEMS_LIST = "/getBiddedItemList";
		static final String EDIT_BIDDED_ITEMS = "/editBiddedItem";
		static final String GET_ORDER_ITEMS_TO_BID = "/getOrderItemsToBid";

		static final String SELLER_ORDER = "/sellerOrder";
		static final String GET_TO_BID_ORDERS_BY_SELLER_ID = "/getToBidBySellerId";
		static final String ASSIGN_ORDER_STATUS = "/assignOrderStatus";
		static final String BUZZED_SELLER = "/buzzedSeller";
		static final String UPDATE_SELLER_STATUS = "/updateSellerStatus";
		static final String SET_APP_STATUS = "/setAppStatus";
		static final String CHANGE_AOUTO_BUZZ_STATUS="/changeStatus";
		static final String CHECK_ALREADY_ADDED_ITEMS = "/checkAlreadyAddedItems";

	}

	public interface NotificationInterfaceUri {
		static final String NOTIFICATION_BASE_URI = "/notification";
		static final String TEST_NOTIFICATION = "/testPushNotification";

	}

	

}
