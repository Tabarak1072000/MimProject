package com.innovationm.medinminutes.service;

import java.util.List;

import com.innovationm.medinminutes.request.AddAgentRequest;
import com.innovationm.medinminutes.request.ChangeAgentStatusRequest;
import com.innovationm.medinminutes.request.GetAgentListRequest;
import com.innovationm.medinminutes.request.UpdateAgentRequest;
import com.innovationm.medinminutes.response.AddUserResponse;
import com.innovationm.medinminutes.response.AgentListResponse;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.GetAgentResponse;

public interface AgentService {

	    AddUserResponse addAgent(AddAgentRequest addAgentRequest);
	
	    AgentListResponse getAgentList(GetAgentListRequest getAgentListRequest);

		CommonSuccessResponse updateAgent(UpdateAgentRequest request,String email);

		CommonSuccessResponse changeStatus(ChangeAgentStatusRequest changeAgentStatusRequest);
}
