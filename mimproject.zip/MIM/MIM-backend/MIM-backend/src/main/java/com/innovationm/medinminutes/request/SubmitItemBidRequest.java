package com.innovationm.medinminutes.request;

import java.util.Date;
import java.util.List;

import com.innovationm.medinminutes.enums.MedicineAvailabilityStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SubmitItemBidRequest {

	private long inventoryId;

	private long orderMedicineDetailsId;

	private boolean isAvailable;

	private int availableQuantity;

	private double sellerPrice;

	private MedicineAvailabilityStatus medicineAvailabilityStatus;

	private Date arrangeTime;

	private List<String> substitute;

}
