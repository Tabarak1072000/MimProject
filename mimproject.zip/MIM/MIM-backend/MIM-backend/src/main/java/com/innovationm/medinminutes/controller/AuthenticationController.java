package com.innovationm.medinminutes.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.innovationm.medinminutes.exception.PasswordMismatchException;
import com.innovationm.medinminutes.request.JwtRequest;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.response.BaseApiResponse;
import com.innovationm.medinminutes.response.ResponseBuilder;
import com.innovationm.medinminutes.service.LoginService;
import com.innovationm.medinminutes.serviceImpl.Base64PasswordService;

@RestController
@CrossOrigin
public class AuthenticationController {

	// @Autowired
	// private PasswordEncoder passwordEncoder;

	@Autowired
	private UserDetailsService userDetailsService;

	@Autowired
	LoginService loginService;

	@Autowired
	Base64PasswordService encoder;

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest authenticationRequest) throws Exception {

		final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUsername());

		String emailRequest = authenticationRequest.getUsername();

		String emailToLowerCase = emailRequest.toLowerCase();
		authenticate(userDetails, emailToLowerCase, authenticationRequest.getPassword());

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(
				loginService.verifyLogin(authenticationRequest.getUsername(), authenticationRequest.getPassword()));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}

	private void authenticate(UserDetails userDetails, String username, String password) throws Exception {

		if (!encoder.matches(password, userDetails.getPassword())) {
			throw new PasswordMismatchException(AppConstant.ErrorTypes.PASSWORD_MISMATCH_ERROR,
					AppConstant.ErrorCodes.PASSWORD_MISMATCH_ERROR_CODE,
					AppConstant.ErrorMessages.EMAIL_CREDENTIALS_MESSAGE);
		}
	}

}
