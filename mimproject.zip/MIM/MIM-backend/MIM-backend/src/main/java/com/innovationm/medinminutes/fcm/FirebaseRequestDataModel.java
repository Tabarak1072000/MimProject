package com.innovationm.medinminutes.fcm;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FirebaseRequestDataModel<T> {
	private String title;

    private String body;

    private int flag;

    private long id;

    private String icon;

    private T appData;
}
