package com.innovationm.medinminutes.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.innovationm.medinminutes.entity.OrderMedicineDetailsEntity;
import com.innovationm.medinminutes.entity.SellerBiddingEntity;
import com.innovationm.medinminutes.entity.SellerBiddingMedicine;
import com.innovationm.medinminutes.repository.OrderMedicineDetailsRepository;
import com.innovationm.medinminutes.repository.SellerBiddingMedicineRepository;
import com.innovationm.medinminutes.response.GetPackedOrderDetailsResponse;

@Service
public class TotalLeftQuantity {

	@Autowired
	OrderMedicineDetailsRepository orderMedicineRepo;

	@Autowired
	SellerBiddingMedicineRepository sellerMedicineRepo;

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public int getTotalQuantity(long orderId) {
		List<OrderMedicineDetailsEntity> entity = orderMedicineRepo.findByOrderId(orderId);
		int total = 0;
		if (entity != null) {
			for (int i = 0; i < entity.size(); i++) {

				int leftTopack = entity.get(i).getQuantityRequired();
				if (entity.get(i).getQuantitySellerProvide() != null) {
					leftTopack = entity.get(i).getQuantityRequired() - entity.get(i).getQuantitySellerProvide();
				}

				total = total + leftTopack;
			}
		}
		return total;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public int getTotalQuantityLeftToPack(long orderId, long inventory) {
		OrderMedicineDetailsEntity entity = orderMedicineRepo.findByOrderIdAndInventoryId(orderId, inventory);
		int totalLeftToPack = 0;
		if (entity != null) {

			totalLeftToPack = entity.getQuantityRequired();
			List<SellerBiddingMedicine> sellerBiddingMedicines = sellerMedicineRepo.findByOrderMedicine(entity);
			for (SellerBiddingMedicine medicine : sellerBiddingMedicines) {
				if (medicine.getQuantitySellerProvide() != null) {

					totalLeftToPack = totalLeftToPack - medicine.getQuantitySellerProvide();
				}
			}
		}
		return totalLeftToPack;
	}

	//@Transactional(propagation = Propagation.REQUIRES_NEW)
	public double getTotalMRP(long orderId) {
		List<OrderMedicineDetailsEntity> entity = orderMedicineRepo.findByOrderId(orderId);
		double total = 0;
		if (entity != null) {
			for (int i = 0; i < entity.size(); i++) {

				int leftTopack = entity.get(i).getQuantityRequired();
				if (entity.get(i).getQuantitySellerProvide() != null) {
					leftTopack = entity.get(i).getQuantityRequired() - entity.get(i).getQuantitySellerProvide();
				}

				total = total + leftTopack * entity.get(i).getMrp();
			}
		}
		return total;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public GetPackedOrderDetailsResponse getTotalMRPAndTotalQuantity(SellerBiddingEntity entity) {
		List<SellerBiddingMedicine> sellerBiddingMedicines = sellerMedicineRepo.findBySellerBidding(entity);
		GetPackedOrderDetailsResponse response = new GetPackedOrderDetailsResponse();

		List<SellerBiddingMedicine> packedMedicine = sellerBiddingMedicines.stream()
				.filter(med -> med.getIsToBePacked()).collect(Collectors.toList());
		int totalQuantity = 0;
		double totalMrp = 0;
		if (!packedMedicine.isEmpty()) {
			for (int i = 0; i < packedMedicine.size(); i++) {
				totalQuantity += packedMedicine.get(i).getQuantitySellerProvide();
				totalMrp += packedMedicine.get(i).getOrderMedicine().getMrp()
						* packedMedicine.get(i).getQuantitySellerProvide();
			}

		}
		response.setTotalMrp(totalMrp);
		response.setTotalQuantity(totalQuantity);
		return response;
	}
}
