package com.innovationm.medinminutes.response;

import java.util.Date;

import com.innovationm.medinminutes.enums.RegistrationStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SellerAdminResponse {

	private Long sellerId;
	private String sellerName;
	private String sellerContact;
	private String userName;
	private String password;
	private RegistrationStatus registrationStatus;
}
