package com.innovationm.medinminutes.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.innovationm.medinminutes.response.BaseApiResponse;
import com.innovationm.medinminutes.response.ResponseBuilder;
import com.innovationm.medinminutes.serviceImpl.BuzzSellerCronJob;
import com.innovationm.medinminutes.serviceImpl.TestServiceImpl;

@RestController
public class TestController {

	@Autowired
	TestServiceImpl service;
	
	@Autowired
	BuzzSellerCronJob croneService;

	@GetMapping("test/getTests")
	public ResponseEntity<?> getTests() {

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(service.getTestData());

		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}
	
	@GetMapping("test/getSnoozedBid")
	public ResponseEntity<?> getSnoozedBid() {

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(croneService.getSnoozedBid());

		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}
}
