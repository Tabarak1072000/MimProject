package com.innovationm.medinminutes.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.innovationm.medinminutes.enums.AutoBuzzStatus;
import com.innovationm.medinminutes.enums.OrderStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Orders")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrderEntity extends BaseEntity {

	@Column(name = "client_name")
	private String clientName;

	@Column(name = "customer_name")
	private String customerName;

	@Column(name = "client_mob", nullable = true)
	private String clientMob;

	@Column(name = "client_order_id")
	private String clientOrderId;

	@Column(name = "address")
	private String address;

	@Column(name = "city")
	private String city;

	@Column(name = "pin_code")
	private String pincode;

	@Column(name = "courier")
	private String courier;

	@Column(name = "discount")
	private double discount;

	@Column(name = "delivery_charges")
	private double deliveryCharges;

	@Enumerated(EnumType.STRING)
	@Column(name = "order_status", nullable = false, columnDefinition = "ENUM('ORDERSET','ORDERCREATED','ORDERLIVE','ORDERHOLD','ORDERCANCELLED','ORDERCOMPLETED')")
	private OrderStatus orderStatus;

	@Column(name = "order_date_time")
	private Date orderTime;

	@Column(name = "timeSinceLive", nullable = true)
	private Date timeSinceLive;

	@Column(name = "deliver_by")
	private Date deliverBy;

	@Column(name = "agent_id", nullable = false)
	private Long agentId;

	@Column(name = "agent_name")
	private String agentName;

	@Column(name = "mimOrderId")
	private String mimOrderId;

	@Column(name = "latitude")
	private double latitude;

	@Column(name = "longitude")
	private double longitude;

	@Column(name = "addedBy")
	private String addedBy;

	@Enumerated(EnumType.STRING)
	@Column(name = "autoBuzzStatus", nullable = false, columnDefinition = "ENUM('ON','OFF') default 'ON'")
	private AutoBuzzStatus autoBuzzStatus;

}
