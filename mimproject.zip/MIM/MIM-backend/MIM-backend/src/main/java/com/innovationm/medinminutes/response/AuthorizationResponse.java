package com.innovationm.medinminutes.response;

import com.innovationm.medinminutes.enums.RegistrationStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuthorizationResponse {

	private Long userId;

	private String name;

	private String email;

	private String primaryPhone;
	
	private String token;
	
	private String role;
	
	private RegistrationStatus status;
	
	private long sellerId;

}
