package com.innovationm.medinminutes.request;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class GetEstimateResponse {

	private String orderId;
	private String customerName;
	private String clientName;
	private String city;
	private double itemsValue;
	private double discount;
	private double discountValue;
	private double deliveryCharges;
	private double totalToPay;

	private List<GetEstimateItemResponse> itemsEstimate;

}
