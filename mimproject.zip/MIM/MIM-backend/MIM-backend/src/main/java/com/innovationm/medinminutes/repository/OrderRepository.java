package com.innovationm.medinminutes.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.innovationm.medinminutes.entity.OrderEntity;
import com.innovationm.medinminutes.enums.OrderStatus;

@Repository
public interface OrderRepository extends JpaRepository<OrderEntity, Long> {

	@Query(value = "SELECT distinct o FROM OrderEntity as o where o.active=true "
			+ "AND(:searchQuery IS NULL OR CONCAT(' ',COALESCE(o.customerName,''),' ',COALESCE(o.mimOrderId,'' ),' ',COALESCE(o.clientOrderId,'' ),' ' )LIKE %:searchQuery%) "
			+ "AND(:orderStatus IS NULL OR o.orderStatus = (:orderStatus))"
			+ "AND(:agentsName IS NULL OR o.agentName = (:agentsName))"
			+ "AND(:clientsName IS NULL OR o.clientName=(:clientsName) ) order by o.id desc")
	Page<OrderEntity> findAllByFilter(Pageable page, String searchQuery, OrderStatus orderStatus, String agentsName,
			String clientsName);

	@Query(value = "SELECT distinct(o.clientName) from OrderEntity as o where TRIM(o.clientName) <> '' order by o.clientName asc")
	List<String> findAllClientsNames();

	@Query(value = "SELECT distinct(o.agentName) from OrderEntity as o")
	List<String> findAllAgentsNames();

	Boolean existsByclientOrderId(String clientOrderId);

	@Query(value = "SELECT distinct o FROM OrderEntity as o where o.active=true "
			+ "AND(:searchQuery IS NULL OR CONCAT(' ',COALESCE(o.customerName,''),' ',COALESCE(o.mimOrderId,'' ),' ',COALESCE(o.clientOrderId,'' ),' ')LIKE %:searchQuery%) "
			+ "AND(:agentsName IS NULL OR o.agentName = (:agentsName))"
			+ "AND(:clientsName IS NULL OR o.clientName=(:clientsName) ) order by o.id desc")
	Page<OrderEntity> findAllOrderByIdDesc(Pageable page, String searchQuery, String agentsName,
			String clientsName);

}