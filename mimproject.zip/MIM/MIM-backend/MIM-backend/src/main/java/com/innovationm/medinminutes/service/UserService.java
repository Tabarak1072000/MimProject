package com.innovationm.medinminutes.service;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.innovationm.medinminutes.entity.User;
import com.innovationm.medinminutes.request.FcmTokenRequest;
import com.innovationm.medinminutes.response.AddUserResponse;
import com.innovationm.medinminutes.response.AuthorizationResponse;
import com.innovationm.medinminutes.response.CommonSuccessResponse;

public interface UserService {

	public AddUserResponse addSeller(String phoneNumber);

	public AuthorizationResponse verifySeller(String phoneNumber,String otp);
	
	UserDetails loadUserByUsername(String username) throws UsernameNotFoundException;

	User findById(Long id);

	public CommonSuccessResponse registerFcmToken(FcmTokenRequest fcmTokenRequest);

	public CommonSuccessResponse toCheckRegisteredUser(String phoneNumber);

	public CommonSuccessResponse logout(Long userId);

	public CommonSuccessResponse checkRegisteredUserByMail(String email);
	
}
