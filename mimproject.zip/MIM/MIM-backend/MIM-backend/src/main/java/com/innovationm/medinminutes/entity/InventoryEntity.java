package com.innovationm.medinminutes.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Inventory")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InventoryEntity extends BaseEntity {

	private String name;

	private String nameUpdateBy;

	@OneToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name = "category_id")
	private CategoryEntity categoryId;

	private String form;

	private String pack;

	private Integer packSize;

	private Integer qtyPerPack;

	private Boolean prescription;

	private String salt;

	private String manufacture;

	private String type;

	private double mrp;

	private String units;

	private String zVarientName;
	
	private String brand;

	@Column(nullable = true)
	private long zProductId;

	@Column(nullable = true)
	private long zVarientId;

	@Column(nullable = true)
	private String zVarientSKUId;

	private String composition;

	private String formUpdateBy;

	private String packUpdateBy;

	private String packSizeUpdateBy;

	private String qtyPerPackUpdateBy;

	private String prescriptionUpdateBy;

	private String saltUpdateBy;

	private String manufactureUpdateBy;

	private String typeUpdateBy;

	private String mrpUpdateBy;

	private String compositionUpdateBy;

	private String unitsUpdateBy;

}
