package com.innovationm.medinminutes.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovationm.medinminutes.request.ChangeSellerOrderStatusRequest;
import com.innovationm.medinminutes.request.EditSellerBiddingMedicineRequest;
import com.innovationm.medinminutes.request.GetSellerOrderByStatusRequest;
import com.innovationm.medinminutes.request.SetAppStatusRequest;
import com.innovationm.medinminutes.request.SubmitBidRequest;
import com.innovationm.medinminutes.resources.RestMappingConstants;
import com.innovationm.medinminutes.response.BaseApiResponse;
import com.innovationm.medinminutes.response.ResponseBuilder;
import com.innovationm.medinminutes.response.SellerListResponse;
import com.innovationm.medinminutes.service.SellerOrderService;

@RestController
@CrossOrigin
@RequestMapping(path = RestMappingConstants.OrderInterfaceUri.SELLER_ORDER)
public class SellerOrderController {

	@Autowired
	SellerOrderService sellerOrderService;

	@GetMapping(RestMappingConstants.OrderInterfaceUri.GET_TO_BID_ORDERS_BY_SELLER_ID)
	public ResponseEntity<BaseApiResponse> getToBidOrders(@RequestParam(name = "sellerId") Long sellerId) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(sellerOrderService.getToBidOrdersBySellerId(sellerId));
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}

	@PostMapping(RestMappingConstants.OrderInterfaceUri.SUBMIT_BID)
	public ResponseEntity<BaseApiResponse> submitBid(@RequestBody SubmitBidRequest submitBidRequest) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(sellerOrderService.submitBid(submitBidRequest));
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}
	
	@PostMapping(RestMappingConstants.OrderInterfaceUri.SET_APP_STATUS)
	public ResponseEntity<BaseApiResponse> setAppStatus(@RequestBody SetAppStatusRequest setAppStatusRequest) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(sellerOrderService.setAppStatus(setAppStatusRequest));
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}

	@PostMapping(RestMappingConstants.OrderInterfaceUri.CHANGE_BID_STATUS)
	public ResponseEntity<BaseApiResponse> changeBidStatus(
			@RequestBody ChangeSellerOrderStatusRequest changeSellerStatus) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(sellerOrderService.changeSellerOrderStatus(changeSellerStatus));
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}

	@PostMapping(RestMappingConstants.SellerInterfaceUri.SELLER_LIST_BY_DISTANCE)
	public ResponseEntity<BaseApiResponse> getSellerList(@RequestParam(name = "distance") double distance,
			@RequestParam(name = "orderId") Long orderId, HttpServletRequest request, HttpServletResponse response) {

		List<SellerListResponse> commonSuccessResponse = sellerOrderService.getSellerList(distance, orderId);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@PostMapping(RestMappingConstants.OrderInterfaceUri.GET_SELLER_ORDER_BY_SELLER_AND_STATUS)
	public ResponseEntity<BaseApiResponse> getSellerOrderByStatus(@RequestBody GetSellerOrderByStatusRequest request) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(sellerOrderService.getSellerOrdersByStatus(request));
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}

	@PostMapping(RestMappingConstants.OrderInterfaceUri.GET_BIDDED_ITEMS_LIST)
	public ResponseEntity<BaseApiResponse> getBiddedItemList(@RequestHeader long sellerBiddingId) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(sellerOrderService.getToPackOrdersBidsBySellerBiddingId(sellerBiddingId));
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}
	
	@PutMapping(RestMappingConstants.OrderInterfaceUri.EDIT_BIDDED_ITEMS)
	public ResponseEntity<BaseApiResponse> editSellerBiddingMedicineDetails(@RequestBody List<EditSellerBiddingMedicineRequest> request) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(sellerOrderService.editSellerBiddingMedicine(request));
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}

}
