package com.innovationm.medinminutes.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.innovationm.medinminutes.entity.SellerDiscountEntity;
import com.innovationm.medinminutes.entity.SellerOrganisationBranchEntity;

public interface SellerDiscountRepository extends JpaRepository<SellerDiscountEntity, Long> {

	// @Query(value="select d from SellerDiscountEntity d where
	// d.sellerId=:sellerId")
	SellerDiscountEntity findBySellerId(SellerOrganisationBranchEntity sellerEntity);

	public List<SellerDiscountEntity> findAllBySellerId(SellerOrganisationBranchEntity sellerId);

}
