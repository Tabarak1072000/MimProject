package com.innovationm.medinminutes.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.innovationm.medinminutes.enums.DeviceType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "Fcm_Auth_Info")
@Setter
@Getter
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class FcmAuthInfoEntity extends BaseEntity {

	@Column(name = "fcm_token", nullable = true, updatable = true, columnDefinition = "Text")
	private String fcmToken;

//	    @Column(name="email",nullable = true,updatable = true,columnDefinition = "Text")
//	    private String email;

	@Column(name = "device_id", nullable = false, columnDefinition = "Text")
	private String deviceId;

	@Column(name = "device_type", nullable = false, updatable = true, columnDefinition = "enum ('NA','ANDROID','IOS')")
	@Enumerated(EnumType.STRING)
	private DeviceType deviceType;

	private long userId;

}
