package com.innovationm.medinminutes.enums;

public enum AutoBuzzStatus {

	ON,OFF
}
