package com.innovationm.medinminutes.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.innovationm.medinminutes.entity.SellerBiddingEntity;
import com.innovationm.medinminutes.enums.BuzzStatus;
import com.innovationm.medinminutes.repository.SellerBiddingRepository;
import com.innovationm.medinminutes.request.AddAgentRequest;
import com.innovationm.medinminutes.request.ChangeAgentStatusRequest;
import com.innovationm.medinminutes.request.GetAgentListRequest;
import com.innovationm.medinminutes.request.UpdateAgentRequest;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.resources.RestMappingConstants;
import com.innovationm.medinminutes.response.AgentListResponse;
import com.innovationm.medinminutes.response.BaseApiResponse;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.GetAgentResponse;
import com.innovationm.medinminutes.response.ResponseBuilder;
import com.innovationm.medinminutes.service.AgentService;
import com.innovationm.medinminutes.serviceImpl.BuzzSellerCronJob;

@RestController
@CrossOrigin
@RequestMapping(path = RestMappingConstants.AgentInterfaceUri.AGENT_BASE_URI)
public class AgentController {

	@Autowired
	AgentService agentService;
	
	@Autowired
	BuzzSellerCronJob buzzSellerCronJob;

	@PostMapping(RestMappingConstants.AgentInterfaceUri.USER_AGENT_ADD_URI)
	public ResponseEntity<?> createAgent(@RequestBody AddAgentRequest addAgentRequest,HttpServletRequest request
			, HttpServletResponse response) {
		Long accountId=(Long) request.getAttribute(AppConstant.Commons.USER_ACCOUNT_ID);
		System.out.println("accountId="+accountId);
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(agentService.addAgent(addAgentRequest));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);

	}

	@PostMapping(RestMappingConstants.AgentInterfaceUri.GET_AGENT_LIST)
	public ResponseEntity<BaseApiResponse> getAgentList(@RequestBody GetAgentListRequest agentListRequest,
			HttpServletRequest request, HttpServletResponse response) {

		AgentListResponse commonSuccessResponse = agentService.getAgentList(agentListRequest);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@PostMapping(RestMappingConstants.AgentInterfaceUri.UPDATE_AGENT)
	public ResponseEntity<BaseApiResponse> updateAgent(@RequestBody UpdateAgentRequest updateAgentRequest,
			HttpServletRequest request, HttpServletResponse response) {
        
		String email= request.getUserPrincipal().getName();
		System.out.println("email="+email);
		CommonSuccessResponse commonSuccessResponse = agentService.updateAgent(updateAgentRequest,email);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}
	@PostMapping(RestMappingConstants.AgentInterfaceUri.ENABLE_DISABLE)
	public ResponseEntity<BaseApiResponse> changeStatus(@RequestBody ChangeAgentStatusRequest  changeAgentStatusRequest ,
			HttpServletRequest request, HttpServletResponse response) {

		CommonSuccessResponse commonSuccessResponse = agentService.changeStatus(changeAgentStatusRequest);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}
	@PostMapping(value = "/getSnoozeBids")
	public ResponseEntity<BaseApiResponse> getSnoozedBid() {

		List<SellerBiddingEntity> commonSuccessResponse = buzzSellerCronJob.getSnoozedBid();

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

}
