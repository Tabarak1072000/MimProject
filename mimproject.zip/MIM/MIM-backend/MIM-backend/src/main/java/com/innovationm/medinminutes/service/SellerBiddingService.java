package com.innovationm.medinminutes.service;

import com.innovationm.medinminutes.entity.SellerBiddingEntity;

public interface SellerBiddingService {

	SellerBiddingEntity findSellerBiddingEntityById(long sellerBiddingId);
}
