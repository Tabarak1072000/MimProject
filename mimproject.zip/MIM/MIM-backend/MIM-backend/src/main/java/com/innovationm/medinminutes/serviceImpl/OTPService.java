package com.innovationm.medinminutes.serviceImpl;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.innovationm.medinminutes.exception.FailToSendOtpException;
import com.innovationm.medinminutes.resources.AppConstant;

@Service
public class OTPService {

	@Autowired
	TwilioService twilioService;

	private LoadingCache<String, Integer> otpCache = null;

	public OTPService() {
		super();
		otpCache = CacheBuilder.newBuilder().expireAfterAccess(AppConstant.OtpService.OTP_EXPIRY_TIME, TimeUnit.MINUTES)
				.build(new CacheLoader<String, Integer>() {
					public Integer load(String key) {
						return 0;
					}
				});
	}

	public int generateOTP(String key) {
		Random random = new Random();
		int otp = random.nextInt(900000) + 100000;
		otpCache.put(key, otp);

		return otp;

	}

	public boolean createPhoneOTP(String phoneNumber, int otp) {
		boolean response = false;

		String sendOTPPhone = String.valueOf(otp);

		try {

			twilioService.sendMessage(phoneNumber, sendOTPPhone);

			response = true;
		} catch (Exception e) {
			throw new FailToSendOtpException(AppConstant.ErrorTypes.FAILED_TO_SEND_OTP_ON_PHONE_ERROR,
					AppConstant.ErrorCodes.FAILED_TO_SEND_OTP_ON_PHONE_ERROR_CODE,
					AppConstant.ErrorMessages.FAILED_TO_SEND_OTP_ON_PHONE_ERROR);
		}
		return response;
	}
}
