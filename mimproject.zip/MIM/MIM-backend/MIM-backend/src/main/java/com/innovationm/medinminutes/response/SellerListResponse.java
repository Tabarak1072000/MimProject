package com.innovationm.medinminutes.response;

import java.util.List;

import com.innovationm.medinminutes.enums.SellerStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SellerListResponse {

    private String sellerName;
	private Long sellerId;
	private String sellerOrderStatus;
	
	private Boolean action;
	private String timeSinceLastAction;
	private String pincode;
	private double sellerlatitude;
	private double sellerlongitude;
	private String sellerNumber;
	private SellerStatus sellerStatus;
	private String appStatus;
	private double discount;
	private double distance;
	private int rank;
}
