package com.innovationm.medinminutes.response;

import java.util.List;

import com.innovationm.medinminutes.fcm.PushNotificationResponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PushNotificationListResponse {

	private List<PushNotificationResponse> notificationList;
}
