package com.innovationm.medinminutes.serviceImpl;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.innovationm.medinminutes.entity.FcmAuthInfoEntity;
import com.innovationm.medinminutes.entity.InventoryEntity;
import com.innovationm.medinminutes.entity.OrderEntity;
import com.innovationm.medinminutes.entity.OrderMedicineDetailsEntity;
import com.innovationm.medinminutes.entity.SellerBiddingEntity;
import com.innovationm.medinminutes.entity.SellerOrganisationBranchEntity;
import com.innovationm.medinminutes.enums.SellerStatus;
import com.innovationm.medinminutes.exception.ResourceNotFoundException;
import com.innovationm.medinminutes.exception.UserNotFoundException;
import com.innovationm.medinminutes.fcm.FCMServiceForSingleToken;
import com.innovationm.medinminutes.fcm.PushNotificationResponse;
import com.innovationm.medinminutes.repository.FcmAuthRepository;
import com.innovationm.medinminutes.repository.InventoryRepository;
import com.innovationm.medinminutes.repository.OrderMedicineDetailsRepository;
import com.innovationm.medinminutes.repository.OrderRepository;
import com.innovationm.medinminutes.repository.OrganisationRepository;
import com.innovationm.medinminutes.repository.SellerBiddingRepository;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.response.GetPackedOrderDetailsResponse;

@Service
public class NotificationService {

	@Autowired
	OrderRepository orderRepository;

	@Autowired
	OrderMedicineDetailsRepository orderMedicineRepo;

	@Autowired
	FcmAuthRepository fcmAuthRepository;

	@Autowired
	FCMServiceForSingleToken fCMServiceForSingleToken;

	@Autowired
	OrganisationRepository organisationRepository;

	@Autowired
	SellerBiddingRepository sellerBiddingRepository;

	@Autowired
	InventoryRepository inventoryRepository;

	@Autowired
	SellerOrderServiceImpl sellerOrderServiceImpl;

	@Autowired
	TotalLeftQuantity totalLeftQuantity;

	@Autowired
	LTPTotalPrice lTPTotalPrice;

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public PushNotificationResponse convertToPushNotification(Long sellerBidddingId, OrderEntity orderEntity) {

		SellerBiddingEntity sellerBidding = sellerBiddingRepository.findById(sellerBidddingId)
				.orElseThrow(() -> new ResourceNotFoundException(AppConstant.ErrorTypes.ORDER_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.ORDER_ERROR_CODE,
						AppConstant.ErrorMessages.SELLER_BIDDING_NOT_EXIST_MESSAGE));

		SellerOrganisationBranchEntity seller = organisationRepository.findById(sellerBidding.getSeller().getId())
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.SELLER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.SELLER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.SELLER_DOES_NOT_EXIST_MESSAGE));

		FcmAuthInfoEntity fcmEntity = fcmAuthRepository.findByUserId(seller.getSellerUserId());

//		int totalQuantity = getTotalQuantity(orderEntity.getId());
//		double totalMRP = getTotalMRP(orderEntity.getId());

		int leftQuantity = totalLeftQuantity.getTotalQuantity(orderEntity.getId());
		double leftQuantityPrice = lTPTotalPrice.getTotalMRP(orderEntity.getId());

		Date buzzTime = sellerBidding.getBuzzTime();

//		buzzTime.setHours(buzzTime.getHours() + 6);
//		buzzTime.setMinutes(buzzTime.getMinutes() - 30);
//
//		Date buzzTimeNew = sellerBidding.getBuzzTime();
//		System.out.println(buzzTimeNew);
//		// Date updatedTime=updateTime(buzzTimeNew);
////		buzzTime.setHours(buzzTime.getHours() + 6);
////		buzzTime.setMinutes(buzzTime.getMinutes() - 30);
//
		Calendar cal = Calendar.getInstance();
		cal.setTime(buzzTime);
		cal.add(Calendar.MINUTE, 30);
		cal.add(Calendar.HOUR, 5);
		Date updatedBuzzTime = cal.getTime();

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String buzzDate = formatter.format(updatedBuzzTime);

		System.out.println("buzzDate:" + buzzDate);

		PushNotificationResponse response = new PushNotificationResponse();

		if (fcmEntity != null) {
			String messageContent = "please bid for this order";
			HashMap<String, String> appData = new HashMap<>();
			appData.put("OrderId", orderEntity.getId().toString());
			appData.put("customerName", orderEntity.getCustomerName());
			appData.put("totalQuantity", String.valueOf(leftQuantity));
			appData.put("totalMRP", String.valueOf(leftQuantityPrice));
			appData.put("sellerBiddingId", sellerBidddingId.toString());
			appData.put("buzzedTime", buzzDate);
			String title = "To Bid";
			Integer flag = AppConstant.Commons.FLAG_VALUE_FOR_TOBID;

			try {

				response = fCMServiceForSingleToken.sendNotification(fcmEntity, appData, title, messageContent, flag);

			} catch (Exception e) {
				// TODO: handle exception
			}

		}

		return response;
	}

	public Date updateTime(Date date) {
		// TODO Auto-generated method stub
		date.setHours(date.getHours() + 6);
//		date.setMinutes(date.getMinutes() - 30);
		System.out.println("buzz" + date);
		return date;
	}

	public int getTotalQuantity(long orderId) {
		List<OrderMedicineDetailsEntity> entity = orderMedicineRepo.findByOrderId(orderId);
		int total = 0;
		if (entity != null) {
			for (int i = 0; i < entity.size(); i++) {
				total = total + entity.get(i).getQuantityRequired();
			}
		}
		return total;
	}

	public double getTotalMRP(Long orderId) {
		List<OrderMedicineDetailsEntity> entity = orderMedicineRepo.findByOrderId(orderId);

		double totalMRP = 0;
		if (entity != null) {
			for (long i = 0; i < entity.size(); i++) {
				InventoryEntity inventory = inventoryRepository.findById(entity.get((int) i).getInventory().getId())
						.orElseThrow(
								() -> new ResourceNotFoundException(AppConstant.ErrorTypes.INVENTORY_NOT_EXIST_ERROR,
										AppConstant.ErrorCodes.INVENTORY_ERROR_CODE,
										AppConstant.ErrorMessages.INVENTORY_NOT_EXIST_MESSAGE));

				int quantity = entity.get((int) i).getQuantityRequired();

				totalMRP = totalMRP + quantity * inventory.getMrp();

			}
		}
		return totalMRP;
	}

	public PushNotificationResponse convertToApproveRejectPushNotification(SellerOrganisationBranchEntity seller) {

		FcmAuthInfoEntity fcmEntity = fcmAuthRepository.findByUserId(seller.getSellerUserId());

		PushNotificationResponse response = new PushNotificationResponse();

		if (fcmEntity != null) {
			String messageContent = "Application Status";
			HashMap<String, String> appData = new HashMap<>();
			String isApproved = "Application Accepted";
			Integer flag = AppConstant.Commons.FLAG_VALUE_FOR_APPLICATION_ACCEPTED;

			if (!seller.getIsApproved()) {
				isApproved = "Application Rejected";
				flag = AppConstant.Commons.FLAG_VALUE_FOR_APPLICATION_REJECTED;
			}

			appData.put("Approved", isApproved);
			String title = isApproved;

			try {

				response = fCMServiceForSingleToken.sendNotification(fcmEntity, appData, title, messageContent, flag);

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}

		}

		return response;
	}

	public PushNotificationResponse sendOrderNotificationToSeller(SellerBiddingEntity sellerBiddingEntity,
			SellerStatus sellerStatus) {
		PushNotificationResponse response = new PushNotificationResponse();
		OrderEntity order = sellerBiddingEntity.getOrder();
		SellerOrganisationBranchEntity seller = sellerBiddingEntity.getSeller();
		FcmAuthInfoEntity fcmEntity = fcmAuthRepository.findByUserId(seller.getSellerUserId());

		int totalQuantity = getTotalQuantity(order.getId());
		System.out.println(String.valueOf("quantity=" + totalQuantity));

		double totalMRP = getTotalMRP(order.getId());

		Date buzzTime = sellerBiddingEntity.getBuzzTime();

		buzzTime.setHours(buzzTime.getHours() + 6);
		buzzTime.setMinutes(buzzTime.getMinutes() - 30);

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String buzzDate = formatter.format(buzzTime);

		System.out.println(buzzDate);

		if (fcmEntity != null) {
			String messageContent = null;
			String title = null;
			Integer flagValue = AppConstant.Commons.FLAG_VALUE_FOR_TOBID;
			HashMap<String, String> appData = new HashMap<>();
			appData.put("OrderId", order.getId().toString());
			appData.put("customerName", order.getCustomerName());
			appData.put("totalQuantity", String.valueOf(totalQuantity));
			appData.put("totalMRP", String.valueOf(totalMRP));
			appData.put("sellerBiddingId", sellerBiddingEntity.getId().toString());
			appData.put("buzzedTime", buzzDate);

			if (sellerStatus == SellerStatus.TOPACK) {
				title = "To Pack";
				messageContent = "Please pack for this order";
				flagValue = AppConstant.Commons.FLAG_VALUE_FOR_TOPACK;
			}
			if (sellerStatus == SellerStatus.PACKED) {
				title = "To Send";
				messageContent = "Please Send the Order";
				flagValue = AppConstant.Commons.FLAG_VALUE_FOR_SEND;
			}

			try {

				response = fCMServiceForSingleToken.sendNotification(fcmEntity, appData, title, messageContent,
						flagValue);

			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		return response;
	}

	public PushNotificationResponse sendToPackAndPackedNotificationToSeller(SellerBiddingEntity sellerBiddingEntity,
			SellerStatus sellerStatus) {
		PushNotificationResponse response = new PushNotificationResponse();
		OrderEntity order = sellerBiddingEntity.getOrder();
		SellerOrganisationBranchEntity seller = sellerBiddingEntity.getSeller();
		FcmAuthInfoEntity fcmEntity = fcmAuthRepository.findByUserId(seller.getSellerUserId());
		int totalQuantity = 0;
		double totalMRP = 0;
		if (sellerStatus.equals(SellerStatus.TOPACK)) {
			totalQuantity = totalLeftQuantity.getTotalQuantity(order.getId());
			totalMRP = totalLeftQuantity.getTotalMRP(order.getId());

			System.out.println(String.valueOf("quantity=" + totalQuantity));
			System.out.println(String.valueOf("mrp=" + totalMRP));
		}
		if (sellerStatus.equals(SellerStatus.PACKED)) {
			GetPackedOrderDetailsResponse getPackedOrderDetailsResponse = totalLeftQuantity
					.getTotalMRPAndTotalQuantity(sellerBiddingEntity);
			totalMRP = getPackedOrderDetailsResponse.getTotalMrp();
			totalQuantity = getPackedOrderDetailsResponse.getTotalQuantity();
		}
		Date buzzTime = sellerBiddingEntity.getBuzzTime();

		buzzTime.setHours(buzzTime.getHours() + 6);
		buzzTime.setMinutes(buzzTime.getMinutes() - 30);

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String buzzDate = formatter.format(buzzTime);

		System.out.println(buzzDate);

		if (fcmEntity != null) {
			String messageContent = null;
			String title = null;
			Integer flagValue = AppConstant.Commons.FLAG_VALUE_FOR_TOBID;
			HashMap<String, String> appData = new HashMap<>();
			appData.put("OrderId", order.getId().toString());
			appData.put("customerName", order.getCustomerName());
			appData.put("totalQuantity", String.valueOf(totalQuantity));
			appData.put("totalMRP", String.valueOf(totalMRP));
			appData.put("sellerBiddingId", sellerBiddingEntity.getId().toString());
			appData.put("buzzedTime", buzzDate);

			if (sellerStatus == SellerStatus.TOPACK) {
				title = "To Pack";
				messageContent = "Please pack for this order";
				flagValue = AppConstant.Commons.FLAG_VALUE_FOR_TOPACK;
			}
			if (sellerStatus == SellerStatus.PACKED) {
				title = "To Send";
				messageContent = "Please Send the Order";
				flagValue = AppConstant.Commons.FLAG_VALUE_FOR_SEND;
			}

			try {

				response = fCMServiceForSingleToken.sendNotification(fcmEntity, appData, title, messageContent,
						flagValue);

			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		return response;
	}
}
