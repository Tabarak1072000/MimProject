package com.innovationm.medinminutes.request;

import com.innovationm.medinminutes.enums.BuzzStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ChangeSellerOrderStatusRequest {

	private BuzzStatus sellerBuzzStatus;
	
	private long sellerBiddingId;
	
}
