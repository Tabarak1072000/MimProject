package com.innovationm.medinminutes.controller;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.innovationm.medinminutes.fcm.FCMService;
import com.innovationm.medinminutes.fcm.PushNotificationResponse;
import com.innovationm.medinminutes.request.FcmNotificationRequest;
import com.innovationm.medinminutes.resources.RestMappingConstants;
import com.innovationm.medinminutes.response.BaseApiResponse;
import com.innovationm.medinminutes.response.ResponseBuilder;

@RestController
@CrossOrigin
@RequestMapping(path = RestMappingConstants.NotificationInterfaceUri.NOTIFICATION_BASE_URI)
public class NotificationController {

	@Autowired
	FCMService fcmService; 
	
	@PostMapping(RestMappingConstants.NotificationInterfaceUri.TEST_NOTIFICATION)
	public ResponseEntity<BaseApiResponse> testNotification(
	
			@RequestBody FcmNotificationRequest fcmNotificationRequest,
			HttpServletRequest request){
		
		HashMap<String, String> appData=new HashMap<>();
		appData.put("pushData", fcmNotificationRequest.getPushData());
		PushNotificationResponse response =fcmService.sendNotification(fcmNotificationRequest.getPushNotificationRequest(),appData,fcmNotificationRequest.getTitle(),
				fcmNotificationRequest.getContent(), 1);
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(response);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}
}
