package com.innovationm.medinminutes.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.innovationm.medinminutes.entity.CategoryEntity;
import com.innovationm.medinminutes.entity.InventoryEntity;
import com.innovationm.medinminutes.entity.OrderMedicineDetailsEntity;
import com.innovationm.medinminutes.entity.User;
import com.innovationm.medinminutes.exception.InvalidInputException;
import com.innovationm.medinminutes.exception.InventoryExistException;
import com.innovationm.medinminutes.exception.ResourceNotFoundException;
import com.innovationm.medinminutes.repository.InventoryRepository;
import com.innovationm.medinminutes.repository.OrderMedicineDetailsRepository;
import com.innovationm.medinminutes.request.AddOrUpdateInventoryRequest;
import com.innovationm.medinminutes.request.ChangeInventoryStatusRequest;
import com.innovationm.medinminutes.request.GetInventoriesListRequest;
import com.innovationm.medinminutes.request.UpdateItemRequest;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.GetAllInvenotriesResponse;
import com.innovationm.medinminutes.response.GetInventoriesNameResponse;
import com.innovationm.medinminutes.response.GetInventoriesResponse;
import com.innovationm.medinminutes.service.CategoryService;
import com.innovationm.medinminutes.service.InventoryService;
import com.innovationm.medinminutes.service.OrderMedicineDetailsService;
import com.innovationm.medinminutes.service.UserService;

@Service
public class InventoryServiceImpl implements InventoryService {

	@Autowired
	InventoryRepository inventoryRepository;

	@Autowired
	UserService userService;

	@Autowired
	OrderMedicineDetailsRepository orderMedicineDetailsRepository;

	@Autowired
	OrderMedicineDetailsService orderMedicineDetialsService;

	@Autowired
	CategoryService categoryService;

	@Override
	public InventoryEntity findInventoryById(Long id) {
		if (id == null) {
			throw new InvalidInputException(AppConstant.ErrorTypes.ID_NULL_EXIST_ERROR,
					AppConstant.ErrorCodes.ID_NULL_ERROR_CODE, AppConstant.ErrorMessages.ID_EMPTY_MESSAGE);
		} else {
			return inventoryRepository.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException(AppConstant.ErrorTypes.INVENTORY_NOT_EXIST_ERROR,
							AppConstant.ErrorCodes.INVENTORY_ERROR_CODE,
							AppConstant.ErrorMessages.INVENTORY_NOT_EXIST_MESSAGE));
		}
	}

	@Override
	public CommonSuccessResponse updateInventory(UpdateItemRequest request) {

		CommonSuccessResponse response = new CommonSuccessResponse(false);

		InventoryEntity inventory = findInventoryById(request.getInventoryId());
		User agent = userService.findById(request.getAgentId());

//		Date date = new Date();
//		DateFormat istFormat = new SimpleDateFormat();
//		DateFormat gmtFormat = new SimpleDateFormat();
//		TimeZone gmtTime = TimeZone.getTimeZone("GMT");
//		TimeZone istTime = TimeZone.getTimeZone("IST");
//
//		istFormat.setTimeZone(gmtTime);
//		gmtFormat.setTimeZone(istTime);
		
		Boolean preSubscription = null;
		if (request.getPrescription() != null) {
			if (request.getPrescription().equals("Yes")) {
				preSubscription = true;
			} else {
				preSubscription = false;
			}
		}

		StringBuilder updatedByString = new StringBuilder("");
		updatedByString.append("By " + agent.getName() + " on ");
		updatedByString.append(new Date().toLocaleString());
		String updatedBy = updatedByString.toString();

		if (preSubscription != inventory.getPrescription()) {
			inventory.setPrescription(preSubscription);
			inventory.setPrescriptionUpdateBy(updatedBy);
		}
		if (request.getComposition() != inventory.getComposition()) {
			inventory.setComposition(request.getComposition());
			inventory.setCompositionUpdateBy(updatedBy);
		}
		if (request.getForm() != inventory.getForm()) {
			inventory.setForm(request.getForm());
			inventory.setFormUpdateBy(updatedBy);
		}
		if (request.getManufacture() != inventory.getManufacture()) {
			inventory.setManufacture(request.getManufacture());
			inventory.setManufactureUpdateBy(updatedBy);
		}
		if (request.getMrp() != inventory.getMrp()) {
			inventory.setMrp(request.getMrp());
			inventory.setMrpUpdateBy(updatedBy);
		}
		if (request.getName() != inventory.getName()) {
			inventory.setName(request.getName());
			inventory.setNameUpdateBy(updatedBy);
		}
		if (request.getPack() != inventory.getPack()) {
			inventory.setPack(request.getPack());
			inventory.setPackUpdateBy(updatedBy);
		}
		if (request.getQtyPerPack() != inventory.getQtyPerPack()) {
			inventory.setQtyPerPack(request.getQtyPerPack());
			inventory.setQtyPerPackUpdateBy(updatedBy);
		}
		if (request.getType() != inventory.getType()) {
			inventory.setType(request.getType());
			inventory.setTypeUpdateBy(updatedBy);
		}
		if (request.getUnits() != inventory.getUnits()) {
			inventory.setUnits(request.getUnits());
			inventory.setUnitsUpdateBy(updatedBy);
		}

		inventory.setActive(true);
		inventory.setUpdated(new Date());
		inventory.setUpdatedBy(agent.getName());

		if (request.getQuantityRequired() != null) {
			OrderMedicineDetailsEntity orderMedicineDetailsEntity = orderMedicineDetialsService
					.findOrderMedicineDetailsById(request.getOrderMedicineId());
			orderMedicineDetailsEntity.setQuantityRequired(request.getQuantityRequired());
			orderMedicineDetailsRepository.save(orderMedicineDetailsEntity);
		}
		try {
			inventoryRepository.save(inventory);

			response.setSuccess(true);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return response;

	}

	@Override
	public List<GetInventoriesResponse> findInventoriesByName(String name) {
		List<InventoryEntity> inventoryEntities = inventoryRepository.findAllByNameStartsWithOrderByNameAsc(name);

		return inventoryEntities.stream().map(inventory -> convertToGetInventoriesResponse(inventory))
				.collect(Collectors.toList());
	}

	@Override
	public GetAllInvenotriesResponse findAllInventories(GetInventoriesListRequest request) {

		GetAllInvenotriesResponse response = new GetAllInvenotriesResponse();

		Pageable page = PageRequest.of(request.getPageNo(), request.getPageSize());
		if (request.getInventoryName() != null) {
			Page<InventoryEntity> inventoryEntities = inventoryRepository.findAllByNameContainsOrderByIdDesc(page,
					request.getInventoryName());

			List<GetInventoriesResponse> inventories = inventoryEntities.stream()
					.map(inventory -> convertToGetInventoriesResponse(inventory)).collect(Collectors.toList());

			response.setNoOfPagesAsPerPageLimit(inventoryEntities.getTotalPages());
			response.setInventories(inventories);
		} else {
			Page<InventoryEntity> inventoryEntities = inventoryRepository.findAllOrderByIdDesc(page);

			List<GetInventoriesResponse> inventories = inventoryEntities.stream()
					.map(inventory -> convertToGetInventoriesResponse(inventory)).collect(Collectors.toList());

			response.setNoOfPagesAsPerPageLimit(inventoryEntities.getTotalPages());
			response.setInventories(inventories);
		}
		return response;
	}

	@Override
	public List<GetInventoriesNameResponse> findAllInventoriesName() {
		List<InventoryEntity> names = inventoryRepository.findAllNames();
		List<GetInventoriesNameResponse> responses = new ArrayList<GetInventoriesNameResponse>();
		try {
			responses = names.stream().map(entity -> convertToGetInventoriesNameResponse(entity))
					.collect(Collectors.toList());

		} catch (Exception e) {
			// TODO: handle exceptione
			e.printStackTrace();
		}
		return responses;
	}
	
	
	@Override
	public List<GetInventoriesNameResponse> findAllInventoriesNames(String name) {
		List<InventoryEntity> names = inventoryRepository.findAllInventoryByNames(name);
		List<GetInventoriesNameResponse> responses = new ArrayList<GetInventoriesNameResponse>();
		try {
			responses = names.stream().map(entity -> convertToGetInventoriesNameResponse(entity))
					.collect(Collectors.toList());

		} catch (Exception e) {
			// TODO: handle exceptione
			e.printStackTrace();
		}
		return responses;
	}

	@Override
	public GetInventoriesResponse getInventoryById(Long id) {
		InventoryEntity entity = findInventoryById(id);
		return convertToGetInventoriesResponse(entity);
	}

	public GetInventoriesResponse convertToGetInventoriesResponse(InventoryEntity entity) {

		String subscription = null;
		if (entity.getPrescription() == Boolean.TRUE) {
			subscription = "Yes";
		} else {
			subscription = "No";
		}

		return GetInventoriesResponse.builder().composition(entity.getComposition())
				.compositionUpdateBy(entity.getCompositionUpdateBy()).form(entity.getForm())
				.formUpdateBy(entity.getFormUpdateBy()).inventoryId(entity.getId()).manufacture(entity.getManufacture())
				.manufactureUpdateBy(entity.getManufactureUpdateBy()).mrp(entity.getMrp())
				.mrpUpdateBy(entity.getMrpUpdateBy()).name(entity.getName()).nameUpdateBy(entity.getNameUpdateBy())
				.pack(entity.getPack()).packUpdateBy(entity.getPackUpdateBy()).prescription(subscription)
				.prescriptionUpdateBy(entity.getPrescriptionUpdateBy()).qtyPerPack(entity.getQtyPerPack())
				.qtyPerPackUpdateBy(entity.getQtyPerPackUpdateBy()).type(entity.getType())
				.typeUpdateBy(entity.getTypeUpdateBy()).units(entity.getUnits())
				.unitsUpdateBy(entity.getUnitsUpdateBy()).activeStatus(entity.getActive()).build();
	}

	public GetInventoriesNameResponse convertToGetInventoriesNameResponse(InventoryEntity entity) {

		return GetInventoriesNameResponse.builder().inventoryId(entity.getId()).name(entity.getName()).build();
	}

	@Override
	public CommonSuccessResponse addOrUpdateInventory(AddOrUpdateInventoryRequest request) {
		CommonSuccessResponse response = new CommonSuccessResponse(false);

		User agent = userService.findById(request.getAgentId());

		Date date = new Date();
//		DateFormat istFormat = new SimpleDateFormat();
//		DateFormat gmtFormat = new SimpleDateFormat();
//		TimeZone gmtTime = TimeZone.getTimeZone("GMT");
//		TimeZone istTime = TimeZone.getTimeZone("IST");
//
//		istFormat.setTimeZone(gmtTime);
//		gmtFormat.setTimeZone(istTime);
		date.setHours(date.getHours() + 6);
		date.setMinutes(date.getMinutes() - 30);

		StringBuilder updatedByString = new StringBuilder("");
		updatedByString.append("By " + agent.getName() + " on ");
		updatedByString.append(date.toLocaleString());
		String updatedBy = updatedByString.toString();

		Boolean preSubscription = null;
		if (request.getPrescription() != null) {
			if (request.getPrescription().equals("Yes")) {
				preSubscription = true;
			} else {
				preSubscription = false;
			}
		}
		InventoryEntity inventory = null;
		if (request.getInventoryId() != 0) {
			inventory = findInventoryById(request.getInventoryId());

			// if (request.getPrescription()!=null && inventory.getPrescription()) {
			if (!preSubscription.equals(inventory.getPrescription())) {
				inventory.setPrescription(preSubscription);
				inventory.setPrescriptionUpdateBy(updatedBy);
			}
			if (request.getComposition() != null && !request.getComposition().equals(inventory.getComposition())) {
				inventory.setComposition(request.getComposition());
				inventory.setCompositionUpdateBy(updatedBy);
			}
			if (request.getForm() != null && !request.getForm().equals(inventory.getForm())) {
				inventory.setForm(request.getForm());
				inventory.setFormUpdateBy(updatedBy);
			}
			if (request.getManufacture() != null && !request.getManufacture().equals(inventory.getManufacture())) {
				inventory.setManufacture(request.getManufacture());
				inventory.setManufactureUpdateBy(updatedBy);
			}
			if (request.getMrp() != 0  && request.getMrp()!=inventory.getMrp()) {
				inventory.setMrp(request.getMrp());
				inventory.setMrpUpdateBy(updatedBy);
			}
			if (request.getName() != null && !request.getName().equals(inventory.getName())) {
				
				InventoryEntity inventory1=inventoryRepository.findByNameAndQtyPerPack(request.getName(),request.getQtyPerPack());
				
				if (inventory1 != null) {
					throw new InventoryExistException(AppConstant.ErrorTypes.INVENTORY_EXIST_ERROR,
							AppConstant.ErrorCodes.INVENTORY_EXIST_ERROR_CODE, AppConstant.ErrorMessages.INVENTORY_EXIST_ERROR_MESSAGE);
				} 
				
				inventory.setName(request.getName());
				inventory.setNameUpdateBy(updatedBy);
			}
			if (request.getPack() != null && !request.getPack().equals(inventory.getPack())) {
				inventory.setPack(request.getPack());
				inventory.setPackUpdateBy(updatedBy);
			}
			if (request.getQtyPerPack() != 0 && !request.getQtyPerPack().equals(inventory.getQtyPerPack())) {
              
				InventoryEntity inventory1=inventoryRepository.findByNameAndQtyPerPack(request.getName(),request.getQtyPerPack());
				if (inventory1 != null) {
					throw new InventoryExistException(AppConstant.ErrorTypes.INVENTORY_EXIST_ERROR,
							AppConstant.ErrorCodes.INVENTORY_EXIST_ERROR_CODE, AppConstant.ErrorMessages.INVENTORY_EXIST_ERROR_MESSAGE);
				} 
				
				
				inventory.setQtyPerPack(request.getQtyPerPack());
				inventory.setQtyPerPackUpdateBy(updatedBy);
			}
			if (request.getType() != null && !request.getType().equals(inventory.getType())) {
				inventory.setType(request.getType());
				inventory.setTypeUpdateBy(updatedBy);
			}
			if (request.getUnits() != null && !request.getUnits().equals(inventory.getUnits())) {
				inventory.setUnits(request.getUnits());
				inventory.setUnitsUpdateBy(updatedBy);
			}

			inventory.setActive(true);
			inventory.setUpdated(new Date());
			inventory.setUpdatedBy(agent.getName());
		} else {
			
			InventoryEntity inventory1=inventoryRepository.findByNameAndQtyPerPack(request.getName(),request.getQtyPerPack());
			
			if (inventory1 != null) {
				throw new InventoryExistException(AppConstant.ErrorTypes.INVENTORY_EXIST_ERROR,
						AppConstant.ErrorCodes.INVENTORY_EXIST_ERROR_CODE, AppConstant.ErrorMessages.INVENTORY_EXIST_ERROR_MESSAGE);
			} 
			
			CategoryEntity categoryEntity = categoryService.findCategoryById((long) 1);
			inventory = InventoryEntity.builder().categoryId(categoryEntity).composition(request.getComposition())
					.compositionUpdateBy(updatedBy).form(request.getForm()).formUpdateBy(updatedBy)
					.manufacture(request.getManufacture()).manufactureUpdateBy(updatedBy).mrp(request.getMrp())
					.mrpUpdateBy(updatedBy).name(request.getName()).nameUpdateBy(updatedBy).pack(request.getPack())
					.packUpdateBy(updatedBy).prescription(preSubscription).prescriptionUpdateBy(updatedBy)
					.qtyPerPack(request.getQtyPerPack()).qtyPerPackUpdateBy(updatedBy).type(request.getType())
					.typeUpdateBy(updatedBy).units(request.getUnits()).unitsUpdateBy(updatedBy).build();

			inventory.setCreatedBy(agent.getName());
		}

		try {
			inventoryRepository.save(inventory);
			response.setSuccess(true);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return response;
	}

	public CommonSuccessResponse changeInventoryStatus(ChangeInventoryStatusRequest changeInventoryStatusRequest) {

		CommonSuccessResponse response = new CommonSuccessResponse(false);
		InventoryEntity item = findInventoryById(changeInventoryStatusRequest.getInventoryId());

		if (item == null) {
			throw new ResourceNotFoundException(AppConstant.ErrorTypes.INVENTORY_NOT_EXIST_ERROR,
					AppConstant.ErrorCodes.INVENTORY_ERROR_CODE, AppConstant.ErrorMessages.INVENTORY_NOT_EXIST_MESSAGE);
		}

		if (changeInventoryStatusRequest.isStatus()) {
			item.setActive(true);
		} else {
			item.setActive(false);
		}

		try {

			inventoryRepository.save(item);
			response.setSuccess(true);
		} catch (Exception e) {
			throw new InvalidInputException(AppConstant.ErrorTypes.INVENTORY_NOT_EXIST_ERROR,
					AppConstant.ErrorCodes.FAILED_TO_UPDATE_RESOURCE_ERROR_CODE,
					AppConstant.ErrorMessages.FAILED_TO_DELETE_ITEM_MESSAGE);
		}

		return response;
	}
}
