package com.innovationm.medinminutes.service;

import com.innovationm.medinminutes.entity.RoleEntity;

public interface RoleService {

	public RoleEntity findById(Long id);
}
