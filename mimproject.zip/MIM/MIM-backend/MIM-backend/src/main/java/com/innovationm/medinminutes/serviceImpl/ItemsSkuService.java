package com.innovationm.medinminutes.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.innovationm.medinminutes.entity.OrderMedicineDetailsEntity;
import com.innovationm.medinminutes.entity.SellerBiddingEntity;
import com.innovationm.medinminutes.entity.SellerBiddingMedicine;
import com.innovationm.medinminutes.enums.SellerStatus;
import com.innovationm.medinminutes.repository.SellerBiddingMedicineRepository;
import com.innovationm.medinminutes.response.GetItemFillRateResponse;
import com.innovationm.medinminutes.response.GetSkuFillRateResponse;

@Service
public class ItemsSkuService {

	@Autowired
	SellerBiddingMedicineRepository sellerBiddingMedicineRepository;

	public GetItemFillRateResponse calculateItemsFillRate(List<OrderMedicineDetailsEntity> orderMedicineDetailsEntity,
			SellerBiddingEntity sellerBidding) {

		int itemFillsRate = 0;

		GetItemFillRateResponse response=new GetItemFillRateResponse();
//		if (sellerBidding.getSellerStatus().equals(SellerStatus.TOBID)) {
//			int totalItemsOrdered = 0;
//			for (int j = 0; j < orderMedicineDetailsEntity.size(); j++) {
//				int quantityRequired = orderMedicineDetailsEntity.get(j).getQuantityRequired();
//				totalItemsOrdered = totalItemsOrdered + quantityRequired;
//			}
//			itemFillsRate = totalItemsOrdered;
//		}

		if (sellerBidding.getSellerStatus().equals(SellerStatus.BIDDED)
				|| sellerBidding.getSellerStatus().equals(SellerStatus.PACKED)
				|| sellerBidding.getSellerStatus().equals(SellerStatus.TOPACKDONE)
				|| sellerBidding.getSellerStatus().equals(SellerStatus.TOPACK))  {
			if (orderMedicineDetailsEntity.size() > 0) {
				int totalStockItem = 0;
				int totalItemsOrdered = 0;
				
				for (int j = 0; j < orderMedicineDetailsEntity.size(); j++) {
                 
					int sellerAvailableQuantity = 0;
					int quantityRequired = orderMedicineDetailsEntity.get(j).getQuantityRequired();

					SellerBiddingMedicine sellerBiddingMedicine = sellerBiddingMedicineRepository
							.findBySellerBiddingAndOrderMedicine(sellerBidding.getId(),
									orderMedicineDetailsEntity.get(j).getId());

					if (sellerBiddingMedicine != null && sellerBiddingMedicine.getAvailableAmount() != null) {
						sellerAvailableQuantity = sellerBiddingMedicine.getAvailableAmount();
						if (quantityRequired < sellerAvailableQuantity) {
							sellerAvailableQuantity = quantityRequired;
						}

					}

					totalStockItem = totalStockItem + sellerAvailableQuantity;
					System.out.println("totalStockItem="+totalStockItem);
					totalItemsOrdered = totalItemsOrdered + quantityRequired;
					System.out.println("totalItemsOrdered="+totalItemsOrdered);
				}

				float itemFillsRateValue = (float) totalStockItem / totalItemsOrdered;
				float itemFillsRatePercentage = itemFillsRateValue * 100;
				System.out.println("itemFillsRateValue" + itemFillsRatePercentage);
				itemFillsRate = (int) itemFillsRatePercentage;
				response.setStockedItemFillRate(itemFillsRate);
			}
		}

		if (sellerBidding.getSellerStatus().equals(SellerStatus.PACKED)
				|| sellerBidding.getSellerStatus().equals(SellerStatus.TOPACKDONE)) {
			if (orderMedicineDetailsEntity.size() > 0) {
				int totalPackedItem = 0;
				
				int totalQuantityRequired = 0;
				for (int j = 0; j < orderMedicineDetailsEntity.size(); j++) {

					int sellerProvideQuantity = 0;
					SellerBiddingMedicine sellerBiddingMedicine = sellerBiddingMedicineRepository
							.findBySellerBiddingAndOrderMedicine(sellerBidding.getId(),
									orderMedicineDetailsEntity.get(j).getId());

					if (sellerBiddingMedicine != null && sellerBiddingMedicine.getAvailableAmount() != null) {
						sellerProvideQuantity = sellerBiddingMedicine.getQuantitySellerProvide();
					}

					totalPackedItem = totalPackedItem + sellerProvideQuantity;
					System.out.println(totalPackedItem);

					totalQuantityRequired = totalQuantityRequired
							+ orderMedicineDetailsEntity.get(j).getQuantityRequired();
				}

				float itemFillsRateValue = (float) totalPackedItem / totalQuantityRequired;
				float itemFillsRatePercentage = itemFillsRateValue * 100;
				itemFillsRate = (int) itemFillsRatePercentage;
				
				response.setPackedItemFillRate(itemFillsRate);
			}
		}

		return response;
	}

	public GetSkuFillRateResponse calculateSkuFillRate(List<OrderMedicineDetailsEntity> orderMedicineDetailsEntity,
			SellerBiddingEntity sellerBidding) {

		int skuFillsRate = 0;
		GetSkuFillRateResponse response=new GetSkuFillRateResponse();
//		if (sellerBidding.getSellerStatus().equals(SellerStatus.TOBID)) {
//			skuFillsRate = orderMedicineDetailsEntity.size();
//		}

		if (sellerBidding.getSellerStatus().equals(SellerStatus.BIDDED) 
			|| sellerBidding.getSellerStatus().equals(SellerStatus.PACKED)
			|| sellerBidding.getSellerStatus().equals(SellerStatus.TOPACKDONE)
			|| sellerBidding.getSellerStatus().equals(SellerStatus.TOPACK)) {
			if (orderMedicineDetailsEntity.size() > 0) {
				int totalStockSku = 0;

				for (int j = 0; j < orderMedicineDetailsEntity.size(); j++) {

					SellerBiddingMedicine sellerBiddingMedicine = sellerBiddingMedicineRepository
							.findBySellerBiddingAndOrderMedicine(sellerBidding.getId(),
									orderMedicineDetailsEntity.get(j).getId());

					int skuStock = 0;
					if (sellerBiddingMedicine != null && (sellerBiddingMedicine.getAvailableAmount() == null
							|| sellerBiddingMedicine.getAvailableAmount() == 0)) {
						skuStock = 0;
					}

					else if (sellerBiddingMedicine != null && sellerBiddingMedicine.getAvailableAmount() > 0) {
						skuStock = 1;
					}

					totalStockSku = totalStockSku + skuStock;
					System.out.println(totalStockSku);

				}
				float skuFillsRateValue = (float) totalStockSku / orderMedicineDetailsEntity.size();
				float skuFillsRatePercentage = skuFillsRateValue * 100;
				skuFillsRate = (int) skuFillsRatePercentage;
				response.setStockedSkuFillRate(skuFillsRate);
			}

		}

		if (sellerBidding.getSellerStatus().equals(SellerStatus.PACKED)
				|| sellerBidding.getSellerStatus().equals(SellerStatus.TOPACKDONE)) {
			if (orderMedicineDetailsEntity.size() > 0) {
				int totalPackedSku = 0;

				for (int j = 0; j < orderMedicineDetailsEntity.size(); j++) {

					SellerBiddingMedicine sellerBiddingMedicine = sellerBiddingMedicineRepository
							.findBySellerBiddingAndOrderMedicine(sellerBidding.getId(),
									orderMedicineDetailsEntity.get(j).getId());

					int skuPacked = 0;

					if (sellerBiddingMedicine != null && (sellerBiddingMedicine.getAvailableAmount() == null
							|| sellerBiddingMedicine.getAvailableAmount() == 0)) {
						skuPacked = 0;
					}

					else if (sellerBiddingMedicine != null && sellerBiddingMedicine.getAvailableAmount() > 0) {
						skuPacked = 1;
					}

					totalPackedSku = totalPackedSku + skuPacked;
					System.out.println(totalPackedSku);

				}
				float skuFillsRateValue = (float) totalPackedSku / orderMedicineDetailsEntity.size();
				float skuFillsRatePercentage = skuFillsRateValue * 100;
				skuFillsRate = (int) skuFillsRatePercentage;
				response.setPackedSkuFillRate(skuFillsRate);
			}

		}

		return response;
	}

}