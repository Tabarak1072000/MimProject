package com.innovationm.medinminutes.response;

import java.util.Date;

import com.innovationm.medinminutes.enums.RegistrationStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SellerProfileResponse {

	private Long sellerId;
	private RegistrationStatus status;
}
