package com.innovationm.medinminutes.response;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.innovationm.medinminutes.exception.AppException;
import com.innovationm.medinminutes.resources.AppConstant;

public class ResponseBuilder {

	public static BaseApiResponse getSuccessResponse(Object responseData) throws AppException {

		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.SUCCESS));
		baseApiResponse.setResponseData(responseData);
		baseApiResponse.setMessage("Success");

		return baseApiResponse;
	}

	public static BaseApiResponse getSuccessResponse() throws AppException {

		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.SUCCESS));
		baseApiResponse.setMessage("Success");
		baseApiResponse.setResponseData(null);

		return baseApiResponse;
	}

	public static BaseApiResponse getErrorResponse(AppException errorDetails) {

		RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
		HttpServletResponse httpServletResponse = ((ServletRequestAttributes) requestAttributes).getResponse();

		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setStatusCode(Integer.parseInt(errorDetails.getErrorCode()));

		BaseApiResponse response = new BaseApiResponse();
		response.setResponseStatus(responseStatus);
		httpServletResponse.setStatus(404);
		return response;

	}
}