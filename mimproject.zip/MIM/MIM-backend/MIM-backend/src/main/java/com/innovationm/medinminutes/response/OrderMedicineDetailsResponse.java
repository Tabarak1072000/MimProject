package com.innovationm.medinminutes.response;

import com.innovationm.medinminutes.entity.InventoryEntity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class OrderMedicineDetailsResponse {

	private Integer quantityRequired;
	private String inventoryName;
	private Integer leftToPack;
	private double price;

}
