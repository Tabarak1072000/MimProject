package com.innovationm.medinminutes.request;


import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@AllArgsConstructor	
@NoArgsConstructor
@Data
public class FcmNotificationRequest {
    private List<PushNotificationTokenRequest> pushNotificationRequest;
    private String pushData;
    private String title;
    private String content;
}
