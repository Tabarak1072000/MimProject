package com.innovationm.medinminutes.service;

import java.util.List;

import com.innovationm.medinminutes.entity.InventoryEntity;
import com.innovationm.medinminutes.request.AddOrUpdateInventoryRequest;
import com.innovationm.medinminutes.request.ChangeInventoryStatusRequest;
import com.innovationm.medinminutes.request.GetInventoriesListRequest;
import com.innovationm.medinminutes.request.UpdateItemRequest;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.GetAllInvenotriesResponse;
import com.innovationm.medinminutes.response.GetInventoriesNameResponse;
import com.innovationm.medinminutes.response.GetInventoriesResponse;

public interface InventoryService {

	public InventoryEntity findInventoryById(Long id);

	CommonSuccessResponse updateInventory(UpdateItemRequest request);

	List<GetInventoriesResponse> findInventoriesByName(String name);

	List<GetInventoriesNameResponse> findAllInventoriesName();
	
    List<GetInventoriesNameResponse> findAllInventoriesNames(String name);

	GetInventoriesResponse getInventoryById(Long id);

	CommonSuccessResponse addOrUpdateInventory(AddOrUpdateInventoryRequest request);

	CommonSuccessResponse changeInventoryStatus(ChangeInventoryStatusRequest request);

	GetAllInvenotriesResponse findAllInventories(GetInventoriesListRequest request);
}
