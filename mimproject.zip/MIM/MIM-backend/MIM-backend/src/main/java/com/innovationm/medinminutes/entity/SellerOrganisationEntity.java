package com.innovationm.medinminutes.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Seller_Organisation")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SellerOrganisationEntity extends BaseEntity {

	private String name;
	
}
