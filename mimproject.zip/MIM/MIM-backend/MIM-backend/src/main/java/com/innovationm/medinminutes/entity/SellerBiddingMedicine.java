package com.innovationm.medinminutes.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.innovationm.medinminutes.enums.BuzzStatus;
import com.innovationm.medinminutes.enums.MedicineAvailabilityStatus;
import com.innovationm.medinminutes.enums.SellerStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "seller_bidding_medicine")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SellerBiddingMedicine extends BaseEntity{

	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH, 
			CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name="inventory_id",nullable = false)
	private InventoryEntity inventory;
	
    private Integer quantitySellerProvide;
    
    private Integer availableAmount;
	
	private double discount ;
	
	private double sellerPrice;
	
	private Boolean isToBePacked;
	
	private Boolean havingSubstitute;
	
	private Date arrangeTime;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "medicineAvailabiltyStatus", nullable = false, columnDefinition = "ENUM('AVAILABLE','CANNOT','TODAY','TOMORROW')")
	private MedicineAvailabilityStatus medicineAvailabiltyStatus;
	
	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH, 
			CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name="seller_bidding_id",nullable = false)
	private SellerBiddingEntity sellerBidding;
	
	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH, 
			CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name="order_Medicine_id",nullable = false)
	private OrderMedicineDetailsEntity orderMedicine;
	
	private double mrp;
	
}
