package com.innovationm.medinminutes.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovationm.medinminutes.request.AddAdminRequest;
import com.innovationm.medinminutes.request.AddSellerRequest;
import com.innovationm.medinminutes.resources.RestMappingConstants;
import com.innovationm.medinminutes.response.BaseApiResponse;
import com.innovationm.medinminutes.response.ResponseBuilder;
import com.innovationm.medinminutes.response.SellerAdminResponse;
import com.innovationm.medinminutes.service.AdminService;

@RestController
@CrossOrigin
@RequestMapping(path = RestMappingConstants.AdminInterfaceUri.ADMIN__BASE_URI)
public class AdminController {

	@Autowired
	AdminService adminService;

	@PostMapping(RestMappingConstants.AdminInterfaceUri.ADD_ADMIN)
	public ResponseEntity<?> createAdmin(@RequestBody AddAdminRequest addAdminRequest) {

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(adminService.addAdmin(addAdminRequest));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);

	}

	@PutMapping(RestMappingConstants.AdminInterfaceUri.APPROVE_SELLER)
	public ResponseEntity<BaseApiResponse> approveSeller(@RequestParam(name = "sellerId") Long sellerId,
			@RequestParam(name = "accepted") boolean accepted, HttpServletRequest request,
			HttpServletResponse response) {

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(adminService.approveSeller(sellerId, accepted));
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@PostMapping(RestMappingConstants.AdminInterfaceUri.ADD_SELLER_BY_ADMIN)
	public ResponseEntity<BaseApiResponse> createSellerByAdmin(@RequestBody AddSellerRequest sellerRequest,
			HttpServletRequest request, HttpServletResponse response) {

		String email= request.getUserPrincipal().getName();
		System.out.println("email="+email);
		SellerAdminResponse commonSuccessResponse = adminService.createSellerByAdmin(sellerRequest,email);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}
}
