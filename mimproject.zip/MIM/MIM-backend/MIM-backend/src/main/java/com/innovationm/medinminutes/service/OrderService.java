package com.innovationm.medinminutes.service;


import com.innovationm.medinminutes.entity.OrderEntity;
import com.innovationm.medinminutes.fcm.PushNotificationResponse;
import com.innovationm.medinminutes.request.BuzzedSellerRequest;
import com.innovationm.medinminutes.request.ChangeAutoBuzzStatusRequest;
import com.innovationm.medinminutes.request.ChangeOrderStatusRequest;
import com.innovationm.medinminutes.request.CreateOrderRequest;
import com.innovationm.medinminutes.request.EditOrderRequest;
import com.innovationm.medinminutes.request.GetEstimateResponse;
import com.innovationm.medinminutes.request.OrderFilterRequest;
import com.innovationm.medinminutes.request.UpdateSellerStatusRequest;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.CreateOrderResponse;
import com.innovationm.medinminutes.response.GetAgentAndClientNameResponse;
import com.innovationm.medinminutes.response.GetOrderResponse;
import com.innovationm.medinminutes.response.OrderListResponse;
import com.innovationm.medinminutes.response.PushNotificationListResponse;

public interface OrderService {

	CreateOrderResponse createOrder(CreateOrderRequest orderRequest,String email);

	OrderEntity findOrderById(Long id);

	CommonSuccessResponse editOrder(EditOrderRequest editOrderRequest);

	OrderListResponse getOrderList(int pageNo, int pageLimit, String searchQuery, OrderFilterRequest filterRequest);

	GetOrderResponse getOrderDetails(Long orderId);

	GetEstimateResponse getEstimateByOrderId(long orderId);

	CommonSuccessResponse changeStatus(ChangeOrderStatusRequest changeOrderStatusRequest);

	PushNotificationListResponse assignSeller(BuzzedSellerRequest buzzedSellerRequest);

	PushNotificationResponse updateSellerStatus(UpdateSellerStatusRequest updateSellerStatusRequest);

	GetAgentAndClientNameResponse getAgentsAndClientsNames();

	GetEstimateResponse getEstimateBySellerBiddingId(long sellerBidding);

	CommonSuccessResponse changeAutoBuzzStatus(ChangeAutoBuzzStatusRequest changeAutoBuzzStatusRequest);

	CommonSuccessResponse alreadyAdddedItems(String inventoryName,Long orderId,Integer qtyPerPack);


}