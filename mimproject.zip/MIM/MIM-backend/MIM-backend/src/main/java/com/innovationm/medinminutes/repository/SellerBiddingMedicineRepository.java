package com.innovationm.medinminutes.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovationm.medinminutes.entity.OrderMedicineDetailsEntity;
import com.innovationm.medinminutes.entity.SellerBiddingEntity;
import com.innovationm.medinminutes.entity.SellerBiddingMedicine;

public interface SellerBiddingMedicineRepository extends JpaRepository<SellerBiddingMedicine, Long> {

	List<SellerBiddingMedicine> findBySellerBidding(SellerBiddingEntity bidding);

	List<SellerBiddingMedicine> findBySellerBiddingAndIsToBePacked(SellerBiddingEntity bidding, boolean isToBePacked);

	@Query("Select SUM(o.quantitySellerProvide) from SellerBiddingMedicine o where o.sellerBidding =:sellerBiddingEntity")
	Long getTotalQuantity(SellerBiddingEntity sellerBiddingEntity);

	@Query("select sb from SellerBiddingMedicine sb where sb.sellerBidding.id=?1 AND sb.orderMedicine.id=?2")
	SellerBiddingMedicine findBySellerBiddingAndOrderMedicine(Long sellerBiddingId, Long orderMedicineId);
	
	List<SellerBiddingMedicine> findByOrderMedicine(OrderMedicineDetailsEntity entity);
}
