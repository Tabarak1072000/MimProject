package com.innovationm.medinminutes.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.innovationm.medinminutes.entity.RoleEntity;
import com.innovationm.medinminutes.exception.InvalidInputException;
import com.innovationm.medinminutes.exception.ResourceNotFoundException;
import com.innovationm.medinminutes.repository.RoleRepository;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService {

	@Autowired
	RoleRepository rolerRepository;

	@Override
	public RoleEntity findById(Long id) {
		if (id == null) {
			throw new InvalidInputException(AppConstant.ErrorTypes.ID_NULL_EXIST_ERROR,
					AppConstant.ErrorCodes.ID_NULL_ERROR_CODE, AppConstant.ErrorMessages.ID_EMPTY_MESSAGE);
		} else {
			return rolerRepository.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException(AppConstant.ErrorTypes.ROLE_NOT_EXIST_ERROR,
							AppConstant.ErrorCodes.ROLE_ERROR_CODE, AppConstant.ErrorMessages.ROLE_NOT_EXIST_MESSAGE));
		}
	}

}
