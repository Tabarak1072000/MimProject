package com.innovationm.medinminutes.service;

import java.util.List;

import com.innovationm.medinminutes.entity.SellerBiddingMedicine;
import com.innovationm.medinminutes.request.ChangeSellerOrderStatusRequest;
import com.innovationm.medinminutes.request.EditSellerBiddingMedicineRequest;
import com.innovationm.medinminutes.request.GetSellerOrderByStatusRequest;
import com.innovationm.medinminutes.request.SetAppStatusRequest;
import com.innovationm.medinminutes.request.SubmitBidRequest;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.GetSellerOrdersResponse;
import com.innovationm.medinminutes.response.GetToPackOrderBidsResponse;
import com.innovationm.medinminutes.response.SellerListResponse;
//github.com/InnovationM-Developer/MIM-backend.git
import com.innovationm.medinminutes.response.ToBidOrderResponse;

public interface SellerOrderService {

	CommonSuccessResponse submitBid(SubmitBidRequest submitBidRequest);

	List<ToBidOrderResponse> getToBidOrdersBySellerId(Long sellerId);

	CommonSuccessResponse changeSellerOrderStatus(ChangeSellerOrderStatusRequest changeSellerOrderRequest);

	List<GetToPackOrderBidsResponse> getToPackOrdersBidsBySellerBiddingId(Long sellerBiddingId);

	List<GetSellerOrdersResponse> getSellerOrdersByStatus(GetSellerOrderByStatusRequest request);

	List<SellerListResponse> getSellerList(double distance, Long orderId);

	SellerBiddingMedicine findSellerBiddingMedicineById(Long id);

	CommonSuccessResponse editSellerBiddingMedicine(List<EditSellerBiddingMedicineRequest> request);
	
	CommonSuccessResponse setAppStatus(SetAppStatusRequest setAppStatusRequest);

	

}
