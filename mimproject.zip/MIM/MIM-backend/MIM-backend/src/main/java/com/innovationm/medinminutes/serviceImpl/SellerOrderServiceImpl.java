package com.innovationm.medinminutes.serviceImpl;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.innovationm.medinminutes.entity.InventoryEntity;
import com.innovationm.medinminutes.entity.OrderEntity;
import com.innovationm.medinminutes.entity.OrderMedicineDetailsEntity;
import com.innovationm.medinminutes.entity.SellerBiddingEntity;
import com.innovationm.medinminutes.entity.SellerBiddingMedicine;
import com.innovationm.medinminutes.entity.SellerOrganisationBranchEntity;
import com.innovationm.medinminutes.entity.SubstituteDetailsEntity;
import com.innovationm.medinminutes.enums.AutoBuzzStatus;
import com.innovationm.medinminutes.enums.BuzzStatus;
import com.innovationm.medinminutes.enums.MedicineAvailabilityStatus;
import com.innovationm.medinminutes.enums.OrderStatus;
import com.innovationm.medinminutes.enums.RegistrationStatus;
import com.innovationm.medinminutes.enums.SellerStatus;
import com.innovationm.medinminutes.exception.InvalidInputException;
import com.innovationm.medinminutes.exception.ResourceNotFoundException;
import com.innovationm.medinminutes.exception.UserNotFoundException;
import com.innovationm.medinminutes.repository.OrderMedicineDetailsRepository;
import com.innovationm.medinminutes.repository.OrderRepository;
import com.innovationm.medinminutes.repository.SellerBiddingMedicineRepository;
import com.innovationm.medinminutes.repository.SellerBiddingRepository;
import com.innovationm.medinminutes.repository.SellerOrganisationBranchRepository;
import com.innovationm.medinminutes.repository.SubstituteDetailsRepository;
import com.innovationm.medinminutes.request.ChangeSellerOrderStatusRequest;
import com.innovationm.medinminutes.request.EditSellerBiddingMedicineRequest;
import com.innovationm.medinminutes.request.GetEstimateResponse;
import com.innovationm.medinminutes.request.GetSellerOrderByStatusRequest;
import com.innovationm.medinminutes.request.SetAppStatusRequest;
import com.innovationm.medinminutes.request.SubmitBidRequest;
import com.innovationm.medinminutes.request.SubmitItemBidRequest;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.GetItemFillRateResponse;
import com.innovationm.medinminutes.response.GetSellerOrdersResponse;
import com.innovationm.medinminutes.response.GetToPackOrderBidsResponse;
import com.innovationm.medinminutes.response.SellerListResponse;
//github.com/InnovationM-Developer/MIM-backend.git
import com.innovationm.medinminutes.response.ToBidOrderResponse;
import com.innovationm.medinminutes.service.InventoryService;
import com.innovationm.medinminutes.service.OrderMedicineDetailsService;
import com.innovationm.medinminutes.service.OrganisationService;
import com.innovationm.medinminutes.service.SellerBiddingService;
import com.innovationm.medinminutes.service.SellerOrderService;

@Service
public class SellerOrderServiceImpl implements SellerOrderService {

	@Autowired
	SellerBiddingRepository sellerBiddingRepo;

	@Autowired
	SellerBiddingMedicineRepository sellerBiddingMedicineRepo;

	@Autowired
	SellerBiddingService sellerBiddingService;

	@Autowired
	InventoryService inventoryService;

	@Autowired
	OrderMedicineDetailsService orderMedicineService;

	@Autowired
	SellerOrganisationBranchRepository sellerOrganisationBranchRepository;

	@Autowired
	OrderRepository orderRepository;

	@Autowired
	OrderMedicineDetailsRepository orderMedicineDetailsRepository;

	@Autowired
	OrderServiceImpl orderService;

	@Autowired
	SubstituteDetailsRepository substituteRepository;

	@Autowired
	OrganisationService organizationService;

	@Autowired
	TotalLeftQuantity totalLeftQuantity;

	@Autowired
	EstimateForTOBid estimateForTOBid;

	@Autowired
	TotalLeftQuantity totalLeftQuantityServiceImpl;
	
	@Autowired
	ItemsSkuService itemSkuService;

	@Override
	@Transactional
	public CommonSuccessResponse submitBid(SubmitBidRequest submitBidRequest) {

		CommonSuccessResponse response = new CommonSuccessResponse(false);

		List<SellerBiddingMedicine> entityList = new ArrayList<SellerBiddingMedicine>();
		SellerBiddingEntity sellerBiddingEntity = sellerBiddingService
				.findSellerBiddingEntityById(submitBidRequest.getSellerBiddingID());

		for (int i = 0; i < submitBidRequest.getItemBidDetails().size(); i++) {
			if (submitBidRequest.getItemBidDetails().get(i).isAvailable()) {
				entityList.add(
						convertToAvailableEntity(submitBidRequest.getItemBidDetails().get(i), sellerBiddingEntity));
			} else {

				InventoryEntity inventory = inventoryService
						.findInventoryById(submitBidRequest.getItemBidDetails().get(i).getInventoryId());
				OrderMedicineDetailsEntity orderMedicine = orderMedicineService.findOrderMedicineDetailsById(
						submitBidRequest.getItemBidDetails().get(i).getOrderMedicineDetailsId());

				List<SubstituteDetailsEntity> substituteDetailsList = new ArrayList<SubstituteDetailsEntity>();

				if (submitBidRequest.getItemBidDetails().get(i).getSubstitute() != null) {
					for (int j = 0; j < submitBidRequest.getItemBidDetails().get(i).getSubstitute().size(); j++) {
						SubstituteDetailsEntity substitute = new SubstituteDetailsEntity();
						substitute.setActive(true);
						substitute.setCreated(new Date());
						substitute.setInventory(inventory);
						substitute.setOrderMedicineDetail(orderMedicine);
						substitute
								.setSubstituteName(submitBidRequest.getItemBidDetails().get(i).getSubstitute().get(j));
						substitute.setSellerBidding(sellerBiddingEntity);
						substituteDetailsList.add(substitute);
					}
				}
				substituteRepository.saveAll(substituteDetailsList);
				entityList.add(
						convertToNotAvailableEntity(submitBidRequest.getItemBidDetails().get(i), sellerBiddingEntity));

			}
		}

		try {
			sellerBiddingMedicineRepo.saveAll(entityList);
			sellerBiddingEntity.setSellerDiscount(submitBidRequest.getSellerDiscount());
			sellerBiddingEntity.setUpdated(new Date());
			SellerOrganisationBranchEntity sellerOrganisationBranchEntity = sellerBiddingEntity.getSeller();

			if (sellerOrganisationBranchEntity.getMaxdiscount() != 0) {
				if (sellerOrganisationBranchEntity.getMaxdiscount() < submitBidRequest.getSellerDiscount()) {
					sellerOrganisationBranchEntity.setMaxdiscount(submitBidRequest.getSellerDiscount());
				}
			}

			sellerBiddingEntity.setSellerStatus(SellerStatus.BIDDED);
			sellerOrganisationBranchRepository.save(sellerOrganisationBranchEntity);
			sellerBiddingRepo.save(sellerBiddingEntity);
			
			List<OrderMedicineDetailsEntity> orderMedicineDetailsEntities=orderMedicineDetailsRepository.findByOrderId(sellerBiddingEntity.getOrder().getId());
			GetItemFillRateResponse itemFillRate=itemSkuService.calculateItemsFillRate(orderMedicineDetailsEntities, sellerBiddingEntity);
			if(itemFillRate.getStockedItemFillRate()>=100)
			{
				OrderEntity orderEntity=sellerBiddingEntity.getOrder();
				orderEntity.setAutoBuzzStatus(AutoBuzzStatus.OFF);
				orderRepository.save(orderEntity);
			}
			
			
			response.setSuccess(true);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return response;
	}

	public SellerBiddingMedicine convertToAvailableEntity(SubmitItemBidRequest request,
			SellerBiddingEntity sellerBiddingEntity) {

		InventoryEntity inventory = inventoryService.findInventoryById(request.getInventoryId());
		OrderMedicineDetailsEntity orderMedicine = orderMedicineService
				.findOrderMedicineDetailsById(request.getOrderMedicineDetailsId());
		return SellerBiddingMedicine.builder().availableAmount(request.getAvailableQuantity()).inventory(inventory)
				.isToBePacked(true).orderMedicine(orderMedicine).sellerPrice(request.getSellerPrice())
				.mrp(inventory.getMrp()).havingSubstitute(false)
				.medicineAvailabiltyStatus(MedicineAvailabilityStatus.AVAILABLE).sellerBidding(sellerBiddingEntity)
				.build();
	}

	public SellerBiddingMedicine convertToNotAvailableEntity(SubmitItemBidRequest request,
			SellerBiddingEntity sellerBiddingEntity) {

		InventoryEntity inventory = inventoryService.findInventoryById(request.getInventoryId());
		OrderMedicineDetailsEntity orderMedicine = orderMedicineService
				.findOrderMedicineDetailsById(request.getOrderMedicineDetailsId());
		return SellerBiddingMedicine.builder().inventory(inventory).isToBePacked(false).orderMedicine(orderMedicine)
				.sellerPrice(request.getSellerPrice()).arrangeTime(request.getArrangeTime()).quantitySellerProvide(0)
				.medicineAvailabiltyStatus(request.getMedicineAvailabilityStatus()).sellerBidding(sellerBiddingEntity)
				.havingSubstitute(true).build();
	}

	@Override
	public List<ToBidOrderResponse> getToBidOrdersBySellerId(Long sellerId) {

		SellerOrganisationBranchEntity sellerOrganisationBranchEntity = sellerOrganisationBranchRepository
				.findById(sellerId).orElse(null);

		List<ToBidOrderResponse> toBidOrderResponseList = new ArrayList<>();

		if (sellerOrganisationBranchEntity != null) {
			List<SellerBiddingEntity> sellerBiddingEntities = sellerBiddingRepo
					.findBySellerId(sellerOrganisationBranchEntity.getId());

			for (SellerBiddingEntity i : sellerBiddingEntities) {
				OrderEntity orderEntity = orderRepository.findById(i.getOrder().getId()).orElse(null);

				String totalQty = orderMedicineDetailsRepository.getTotalQuantity(orderEntity).toString();

				ToBidOrderResponse toBidOrderResponse = new ToBidOrderResponse();
				toBidOrderResponse.setOrderId(orderEntity.getId());
				toBidOrderResponse.setMimOrderId(orderEntity.getMimOrderId());
				toBidOrderResponse.setSellerBiddingId(i.getId());
				toBidOrderResponse.setCustomerName(orderEntity.getCustomerName());
				toBidOrderResponse.setTotalQuantity(totalQty);

				GetEstimateResponse getEstimateResponse = orderService.getEstimateByOrderId(orderEntity.getId());

				toBidOrderResponse.setTotalAmount(getEstimateResponse.getTotalToPay());

				toBidOrderResponseList.add(toBidOrderResponse);
			}

			return toBidOrderResponseList;

		}

		return toBidOrderResponseList;

	}

	@Override
	public CommonSuccessResponse changeSellerOrderStatus(ChangeSellerOrderStatusRequest changeSellerOrderRequest) {
		CommonSuccessResponse response = new CommonSuccessResponse(false);

		SellerBiddingEntity sellerBiddingEntity = sellerBiddingService
				.findSellerBiddingEntityById(changeSellerOrderRequest.getSellerBiddingId());

		if (changeSellerOrderRequest.getSellerBuzzStatus().equals(BuzzStatus.SNOOZED))

		{
			Date time = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(time);
			cal.add(Calendar.MINUTE, 1);
			Date updatedBuzzTime = cal.getTime();

			sellerBiddingEntity.setSnoozedBuzzTime(updatedBuzzTime);
			// sellerBiddingEntity.setSellerStatus(SellerStatus.SNOOZED); //after discussion
			// we will not update after snooze
		}

		else if (changeSellerOrderRequest.getSellerBuzzStatus().equals(BuzzStatus.REJECTED)) {
			sellerBiddingEntity.setSellerStatus(SellerStatus.REJECTED);
		}
		sellerBiddingEntity.setBuzzStatus(changeSellerOrderRequest.getSellerBuzzStatus());
		try {
			sellerBiddingRepo.save(sellerBiddingEntity);
			response.setSuccess(true);
		} catch (Exception e) {
			// TODO: handle exception
		}

		return response;
	}

	@Override
	public List<GetToPackOrderBidsResponse> getToPackOrdersBidsBySellerBiddingId(Long sellerBiddingId) {

		// get bidded medicine details of pack data

		SellerBiddingEntity sellerBiddingEntity = sellerBiddingService.findSellerBiddingEntityById(sellerBiddingId);
		List<SellerBiddingMedicine> sellerMedicineEntities = sellerBiddingMedicineRepo
				.findBySellerBidding(sellerBiddingEntity);

		if (sellerBiddingEntity.getSellerStatus().equals(SellerStatus.PACKED)
				|| sellerBiddingEntity.getSellerStatus().equals(SellerStatus.SENT)) {
			return sellerMedicineEntities.stream()
					.map(sellerMedicine -> convertToGetPackedOrSentOrderBidsResponse(sellerMedicine,
							sellerBiddingEntity.getOrder().getId()))
					.collect(Collectors.toList());
		} else {
			return sellerMedicineEntities.stream()
					.map(sellerMedicine -> convertToGetToPackOrderBidsResponse(sellerMedicine,
							sellerBiddingEntity.getOrder().getId()))
					.filter(getToPackOrderBidsResponse -> getToPackOrderBidsResponse.getQuantityRequired() > 0)
					.collect(Collectors.toList());
		}
	}

	public GetToPackOrderBidsResponse convertToGetToPackOrderBidsResponse(SellerBiddingMedicine entity, long orderId) {
		Integer quantitySellerProvide = 0;
		if (entity.getQuantitySellerProvide() != null) {
			quantitySellerProvide = entity.getQuantitySellerProvide();
		}
		int totalLeftToPack = totalLeftQuantityServiceImpl.getTotalQuantityLeftToPack(orderId,
				entity.getInventory().getId());
		return GetToPackOrderBidsResponse.builder().inventoryName(entity.getInventory().getName())
				.mrp(entity.getInventory().getMrp()).quantityRequired(totalLeftToPack)
				.quantitySellerProvide(quantitySellerProvide).sellerBiddingMedicineId(entity.getId())
				.form(entity.getInventory().getForm()).pack(entity.getInventory().getPack())
				.qtyPerPack(entity.getInventory().getQtyPerPack()).units(entity.getInventory().getUnits()).build();
	}

	public GetToPackOrderBidsResponse convertToGetPackedOrSentOrderBidsResponse(SellerBiddingMedicine entity,
			long orderId) {
		int totalLeftToPack = totalLeftQuantityServiceImpl.getTotalQuantityLeftToPack(orderId,
				entity.getInventory().getId());
		return GetToPackOrderBidsResponse.builder().inventoryName(entity.getInventory().getName())
				.mrp(entity.getInventory().getMrp()).quantityRequired(totalLeftToPack)
				.quantitySellerProvide(entity.getQuantitySellerProvide()).sellerBiddingMedicineId(entity.getId())
				.form(entity.getInventory().getForm()).pack(entity.getInventory().getPack())
				.qtyPerPack(entity.getInventory().getQtyPerPack()).units(entity.getInventory().getUnits()).build();
	}

	@Override
	public List<GetSellerOrdersResponse> getSellerOrdersByStatus(GetSellerOrderByStatusRequest request) {

		SellerOrganisationBranchEntity seller = organizationService
				.getSellerOrganizationBranchEntity(request.getSellerId());

		List<SellerBiddingEntity> sellerBiddingList;
		if (request.getSellerStatus().equals(SellerStatus.PACKED)) {
			sellerBiddingList = sellerBiddingRepo.findBySellerAndSellerStatusPackedAndToPacKDone(seller,
					request.getSellerStatus());
		} else {

			sellerBiddingList = sellerBiddingRepo.findBySellerAndSellerStatus(seller, request.getSellerStatus());
		}
//		if(sellerBiddingList.get(0).getOrder().getOrderStatus().equals(OrderStatus.ORDERCOMPLETED))
//		{
//			List<GetSellerOrdersResponse> response=new ArrayList<GetSellerOrdersResponse>();
//			return response;
//		}
		sellerBiddingList = sellerBiddingList.stream()
				.filter(sellerBidding -> sellerBidding.getBuzzStatus().equals(BuzzStatus.SNOOZED)
						|| sellerBidding.getBuzzStatus().equals(BuzzStatus.BUZZED))
				.filter(sellerBidding -> !(sellerBidding.getOrder().getOrderStatus()).equals(OrderStatus.ORDERCANCELLED)
						&& !(sellerBidding.getOrder().getOrderStatus()).equals(OrderStatus.ORDERCOMPLETED)
						&& !(sellerBidding.getOrder().getOrderStatus()).equals(OrderStatus.ORDERHOLD))
				.collect(Collectors.toList());

		return sellerBiddingList.stream().map(sellerBidding -> convertToGetSellerOrderResponse(sellerBidding))
				.collect(Collectors.toList());

	}

	public GetSellerOrdersResponse convertToGetSellerOrderResponse(SellerBiddingEntity entity) {
		DecimalFormat df = new DecimalFormat("0.00");

		OrderEntity orderEntity = entity.getOrder();
		GetEstimateResponse getEstimateResponse = null;

		Long totalQty = (long) 0;
		if (entity.getSellerStatus().equals(SellerStatus.PACKED)
				|| entity.getSellerStatus().equals(SellerStatus.SENT) || entity.getSellerStatus().equals(SellerStatus.TOPACKDONE)) {
			System.out.println("Packed");
			getEstimateResponse = orderService.getEstimateBySellerBiddingId(entity.getId());
			totalQty = sellerBiddingMedicineRepo.getTotalQuantity(entity);
		} else if (entity.getSellerStatus().equals(SellerStatus.TOPACK)) {
			List<SellerBiddingMedicine> sellerBiddingMedicines = sellerBiddingMedicineRepo
					.findBySellerBiddingAndIsToBePacked(entity, true);
			getEstimateResponse = orderService.getEstimateByOrderId(orderEntity.getId());
//			totalQty = (long) sellerBiddingMedicines.stream().map(sellerbid->)
//					.mapToInt(sellerBiddingMed -> sellerBiddingMed.getOrderMedicine().getQuantityRequired()).sum();
			if (!sellerBiddingMedicines.isEmpty()) {
				for (int i = 0; i < sellerBiddingMedicines.size(); i++) {
					totalQty += (long) totalLeftQuantityServiceImpl.getTotalQuantityLeftToPack(
							entity.getOrder().getId(), sellerBiddingMedicines.get(i).getInventory().getId());
				}
			}
			

		} else {
			getEstimateResponse = estimateForTOBid.getEstimateByOrderId(orderEntity.getId());
			// totalQty = orderMedicineDetailsRepository.getTotalQuantity(orderEntity);
			totalQty = (long) totalLeftQuantity.getTotalQuantity(entity.getOrder().getId());

		}

		Date sellerTime = null;

		if (entity.getUpdated() != null && (entity.getSellerStatus().equals(SellerStatus.PACKED)
				|| entity.getSellerStatus().equals(SellerStatus.SENT)
				|| entity.getSellerStatus().equals(SellerStatus.TOPACK))) {
//			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//			dateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			System.out.println(entity.getUpdated());
			 sellerTime=entity.getUpdated();
			sellerTime.setHours(sellerTime.getHours() + 6);
			sellerTime.setMinutes(sellerTime.getMinutes() - 30);
			System.out.println("sellerTime"+sellerTime);
			
		} else {
//			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//			dateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			 sellerTime=entity.getBuzzTime();
			System.out.println(sellerTime);
			sellerTime.setHours(sellerTime.getHours() + 6);
			sellerTime.setMinutes(sellerTime.getMinutes() - 30);
		}

		double totalAmount = getEstimateResponse.getItemsValue();

		double totalToPay = getEstimateResponse.getTotalToPay();

		if(entity.getSellerStatus().equals(SellerStatus.TOPACK))
		{
			totalAmount=totalLeftQuantity.getTotalMRP(orderEntity.getId());
		}
		return GetSellerOrdersResponse.builder().customerName(orderEntity.getCustomerName())
				.mimOrderId(orderEntity.getMimOrderId()).orderId(orderEntity.getId()).sellerBiddingId(entity.getId())
				.totalAmount(df.format(totalAmount)).totalToPay(df.format(totalToPay))
				.discount(entity.getSellerDiscount()).sellerTiming(sellerTime).totalQuantity(totalQty)
				.sellerStatus(entity.getSellerStatus()).build();

	}

	public List<SellerListResponse> getSellerList(double distance, Long orderId) {

		OrderEntity orderEntity = orderRepository.findById(orderId)
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.ORDER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.ORDER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.ORDER_DOES_NOT_EXIST_MESSAGE));

		List<SellerOrganisationBranchEntity> sellerEntity = sellerOrganisationBranchRepository.findAll();

		List<SellerOrganisationBranchEntity> filterSellerEntity = sellerEntity.stream()
				.filter(seller -> seller.getRegistrationStatus() != null
						&& (seller.getRegistrationStatus().equals(RegistrationStatus.LIVE)
								|| seller.getRegistrationStatus().equals(RegistrationStatus.MANUAL)))
				.collect(Collectors.toList());

		List<SellerOrganisationBranchEntity> seller = new ArrayList<>();

//		for (SellerOrganisationBranchEntity sellerList1 : sellerEntity) {
//			double sellerCustomerDistance = getDistance(sellerList1.getLatitude(), sellerList1.getLongitude(),
//					orderEntity.getLatitude(), orderEntity.getLongitude());
//
//			if (sellerCustomerDistance <= distance) {
//				seller.add(sellerList1);
//
//			}
//		}	
//       List<SellerBiddingEntity> sellerBiddingList=sellerBiddingRepo.findByOrderId(orderId);
//		if(sellerBiddingList!=null) {
//		List<Long> buzzedSellerId = new ArrayList<>();
//		for (SellerBiddingEntity sellerEntity3 : sellerBiddingList) {
//			buzzedSellerId.add(sellerEntity3.getSeller().getId());
//		}
//		
//		List<SellerOrganisationBranchEntity> buzzedSellerList = sellerOrganisationBranchRepository.findAllById(buzzedSellerId);
//		
//		seller.removeIf(sell->buzzedSellerList.contains(sell));  //remove list from list
//		}

		TreeMap<Double, SellerOrganisationBranchEntity> sellerMap = new TreeMap<>();
		for (SellerOrganisationBranchEntity sellerList1 : filterSellerEntity) {
			double sellerCustomerDistance = getDistance1(sellerList1.getLatitude(), sellerList1.getLongitude(),
					orderEntity.getLatitude(), orderEntity.getLongitude());

			if (sellerCustomerDistance <= distance) {
				seller.add(sellerList1);
				sellerMap.put(sellerCustomerDistance, sellerList1);

			}
		}

		System.out.println(sellerMap);
		return sellerMap.values().stream().map(sellerNew -> convertToListSeller(sellerNew, orderEntity))
				.collect(Collectors.toList());
//		return seller.stream().map(sellerNew -> convertToListSeller(sellerNew, orderEntity))
//				.collect(Collectors.toList());

	}

	private SellerListResponse convertToListSeller(SellerOrganisationBranchEntity seller, OrderEntity orderEntity) {

		final DecimalFormat df = new DecimalFormat("0.00");

		double sellerCustomerDistance = getDistance1(seller.getLatitude(), seller.getLongitude(),
				orderEntity.getLatitude(), orderEntity.getLongitude());

		String sellerCustomerDistanceValue = df.format(sellerCustomerDistance);

		SellerBiddingEntity sellerBidding = sellerBiddingRepo.findByOrderAndSellerId(orderEntity, seller.getId());
		if (sellerBidding == null) {

			SellerBiddingEntity entity = SellerBiddingEntity.builder().order(orderEntity).seller(seller)
					.buzzStatus(BuzzStatus.TOFIND).sellerStatus(SellerStatus.TOFIND).appStatus(false).build();
			sellerBiddingRepo.save(entity);
		}
		return SellerListResponse.builder().sellerName(seller.getSellerName()).sellerNumber(seller.getWhatsAppNumber())
				.pincode(seller.getPincode()).distance(Double.valueOf(sellerCustomerDistanceValue))
				.sellerlatitude(seller.getLatitude()).sellerlongitude(seller.getLongitude())
				.discount(seller.getMaxdiscount()).sellerId(seller.getId()).build();

	}

	public double getDistance(double lat1, double lon1, double lat2, double lon2) {
		double earthRadious = 6371;

		return Math.acos(
				Math.sin(lat2 * Math.PI / 180.0) * Math.sin(lat1 * Math.PI / 180.0) + Math.cos(lat2 * Math.PI / 180.0)
						* Math.cos(lat1 * Math.PI / 180.0) * Math.cos((lon1 - lon2) * Math.PI / 180.0))
				* earthRadious;

	}

	public double getDistance1(double lat1, double lon1, double lat2, double lon2) {

		return Math.sqrt(Math.pow(((lat2 - lat1) * 110.9480), 2) + Math.pow(((lon2 - lon1) * 102.1889), 2));

		// new client provided
	}

	// find Seller Bidding Medicine by id

	@Override
	public SellerBiddingMedicine findSellerBiddingMedicineById(Long id) {
		if (id == null) {
			throw new InvalidInputException(AppConstant.ErrorTypes.ID_NULL_EXIST_ERROR,
					AppConstant.ErrorCodes.ID_NULL_ERROR_CODE, AppConstant.ErrorMessages.ID_EMPTY_MESSAGE);
		} else {
			return sellerBiddingMedicineRepo.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException(
							AppConstant.ErrorTypes.SELLER_BIDDING_MEDICINE_NOT_EXIST_ERROR,
							AppConstant.ErrorCodes.SELLER_BIDDING_MEDICINE_ERROR_CODE,
							AppConstant.ErrorMessages.SELLER_BIDDING_MEDICINE_NOT_EXIST_MESSAGE));
		}
	}

	// edit Seller Bidding Medicine by id for quantity

	@Override
	public CommonSuccessResponse editSellerBiddingMedicine(List<EditSellerBiddingMedicineRequest> request) {

		CommonSuccessResponse response = new CommonSuccessResponse(false);

		List<SellerBiddingMedicine> sellerBiddingMedicines = new ArrayList<SellerBiddingMedicine>();

		SellerBiddingMedicine medicine = findSellerBiddingMedicineById(request.get(0).getSellerBiddingMedicineId());

		SellerBiddingEntity sellerBiddingEntity = medicine.getSellerBidding();
		if (!request.isEmpty()) {
			for (int i = 0; i < request.size(); i++) {

				SellerBiddingMedicine medicine1 = findSellerBiddingMedicineById(
						request.get(i).getSellerBiddingMedicineId());

				SellerBiddingMedicine sellerBiddingMedicine = findSellerBiddingMedicineById(
						request.get(i).getSellerBiddingMedicineId());
				sellerBiddingMedicine.setQuantitySellerProvide(request.get(i).getQuantityPacked());

				if (request.get(i).getQuantityPacked() > 0) {
					sellerBiddingMedicine.setIsToBePacked(true);
					sellerBiddingMedicine.setMrp(sellerBiddingMedicine.getInventory().getMrp());
				}

				sellerBiddingMedicines.add(sellerBiddingMedicine);

				// for Ltp purpose

				OrderMedicineDetailsEntity orderMedicine = orderMedicineService
						.findOrderMedicineDetailsById(medicine1.getOrderMedicine().getId());
				int totalPacked = 0;
				if (orderMedicine.getQuantitySellerProvide() != null) {
					totalPacked = orderMedicine.getQuantitySellerProvide() + request.get(i).getQuantityPacked();
				} else {
					totalPacked = request.get(i).getQuantityPacked();
				}
				orderMedicine.setQuantitySellerProvide(totalPacked);
				orderMedicineDetailsRepository.save(orderMedicine);
			}
		}

		try {
			sellerBiddingMedicineRepo.saveAll(sellerBiddingMedicines);
			sellerBiddingEntity.setSellerStatus(SellerStatus.TOPACKDONE);
			sellerBiddingEntity.setUpdated(new Date());
			sellerBiddingRepo.save(sellerBiddingEntity);

			response.setSuccess(true);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return response;

	}

	@Override
	public CommonSuccessResponse setAppStatus(SetAppStatusRequest setAppStatusRequest) {

		CommonSuccessResponse response = new CommonSuccessResponse(false);

		OrderEntity entity = orderRepository.findById(setAppStatusRequest.getOrderId())
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.ORDER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.ORDER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.ORDER_DOES_NOT_EXIST_MESSAGE));

		SellerOrganisationBranchEntity sellerEntity = sellerOrganisationBranchRepository
				.findById(setAppStatusRequest.getSellerId())
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.SELLER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.SELLER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.SELLER_DOES_NOT_EXIST_MESSAGE));

		SellerBiddingEntity sellerBiddingEntity = sellerBiddingRepo.findByOrderAndSeller(entity, sellerEntity);

		if (sellerBiddingEntity != null) {
			sellerBiddingEntity.setAppStatus(true);

			try {
				sellerBiddingRepo.save(sellerBiddingEntity);
				response.setSuccess(true);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		return response;

	}
}