package com.innovationm.medinminutes.response;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.innovationm.medinminutes.enums.SellerStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GetSellerOrdersResponse {

	private Long orderId;
	private String mimOrderId;
	private Long sellerBiddingId;
	private Long totalQuantity;
	private String totalAmount;
	private String customerName;
	private String totalToPay;
	private double discount;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date sellerTiming;
	private SellerStatus sellerStatus;
}
