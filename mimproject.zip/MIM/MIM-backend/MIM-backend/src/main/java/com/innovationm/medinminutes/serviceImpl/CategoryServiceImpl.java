package com.innovationm.medinminutes.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.innovationm.medinminutes.entity.CategoryEntity;
import com.innovationm.medinminutes.exception.InvalidInputException;
import com.innovationm.medinminutes.exception.ResourceNotFoundException;
import com.innovationm.medinminutes.repository.CategoryRepository;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	CategoryRepository categoryRepository;

	@Override
	public CategoryEntity findCategoryById(Long id) {
		if (id == null) {
			throw new InvalidInputException(AppConstant.ErrorTypes.ID_NULL_EXIST_ERROR,
					AppConstant.ErrorCodes.ID_NULL_ERROR_CODE, AppConstant.ErrorMessages.ID_EMPTY_MESSAGE);
		} else {
			return categoryRepository.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException(AppConstant.ErrorTypes.CATEGORY_NOT_EXIST_ERROR,
							AppConstant.ErrorCodes.CATEGORY_ERROR_CODE,
							AppConstant.ErrorMessages.CATEGORY_NOT_EXIST_MESSAGE));
		}
	}

}
