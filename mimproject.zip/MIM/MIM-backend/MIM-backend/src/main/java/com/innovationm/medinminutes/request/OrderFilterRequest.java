package com.innovationm.medinminutes.request;

import com.innovationm.medinminutes.enums.OrderStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class OrderFilterRequest {

	private  String clientName;
	private String agentName;
	private OrderStatus orderStatus;
}
