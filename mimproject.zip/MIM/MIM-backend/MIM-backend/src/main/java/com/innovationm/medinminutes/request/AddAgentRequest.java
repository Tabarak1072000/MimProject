package com.innovationm.medinminutes.request;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AddAgentRequest {

	private String name;

	private String email;
	
	private String phoneNumber;
	
	private String alternatePhoneNumber;
	
	private String password;
	
	private Date startDate;
	
	private Date endDate;
}
