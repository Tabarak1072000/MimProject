package com.innovationm.medinminutes.service;

import com.innovationm.medinminutes.response.AuthorizationResponse;

public interface LoginService {

	AuthorizationResponse verifyLogin(String email, String password);

}
