package com.innovationm.medinminutes.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovationm.medinminutes.entity.InventoryEntity;

public interface InventoryRepository extends JpaRepository<InventoryEntity, Long> {

	List<InventoryEntity> findAllByNameStartsWithOrderByNameAsc(String name);

	@Query(value = "SELECT distinct o from InventoryEntity as o where o.active=true order by o.name asc")
	List<InventoryEntity> findAllNames();

	Page<InventoryEntity> findByOrderByNameDesc(Pageable pageable);
	
	@Query(value = "SELECT distinct o from InventoryEntity as o where o.name like %:name%  order by o.id desc")
	Page<InventoryEntity> findAllByNameContainsOrderByIdDesc(Pageable pageable,String name);

	@Query(value = "SELECT distinct o from InventoryEntity as o  order by o.id desc")
	Page<InventoryEntity> findAllOrderByIdDesc(Pageable page);

	InventoryEntity findByNameAndQtyPerPack(String name, Integer qtyPerPack);

	@Query(value = "SELECT  o from InventoryEntity as o  where o.name=?1 AND o.qtyPerPack=?2")
	List<InventoryEntity> findByNameAndQtyPerPacks(String inventoryName, Integer qtyPerPack);

	@Query(value = "SELECT distinct o from InventoryEntity as o where o.active=true and o.name like %:name%")
	List<InventoryEntity> findAllInventoryByNames(String name);
}
