package com.innovationm.medinminutes.serviceImpl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.innovationm.medinminutes.entity.InventoryEntity;
import com.innovationm.medinminutes.entity.OrderEntity;
import com.innovationm.medinminutes.entity.OrderMedicineDetailsEntity;
import com.innovationm.medinminutes.entity.RoleEntity;
import com.innovationm.medinminutes.entity.SellerBiddingEntity;
import com.innovationm.medinminutes.entity.SellerBiddingMedicine;
import com.innovationm.medinminutes.entity.SellerOrganisationBranchEntity;
import com.innovationm.medinminutes.entity.SubstituteDetailsEntity;
import com.innovationm.medinminutes.entity.User;
import com.innovationm.medinminutes.enums.AutoBuzzStatus;
import com.innovationm.medinminutes.enums.BuzzStatus;
import com.innovationm.medinminutes.enums.OrderStatus;
import com.innovationm.medinminutes.enums.RegistrationStatus;
import com.innovationm.medinminutes.enums.SellerStatus;
import com.innovationm.medinminutes.exception.BuzzPausedException;
import com.innovationm.medinminutes.exception.ClientOrderIdAlreadyExistException;
import com.innovationm.medinminutes.exception.InvalidIdException;
import com.innovationm.medinminutes.exception.InvalidInputException;
import com.innovationm.medinminutes.exception.LtpOverException;
import com.innovationm.medinminutes.exception.ResourceNotFoundException;
import com.innovationm.medinminutes.exception.UserNotFoundException;
import com.innovationm.medinminutes.fcm.FCMService;
import com.innovationm.medinminutes.fcm.FCMServiceForSingleToken;
import com.innovationm.medinminutes.fcm.PushNotificationResponse;
import com.innovationm.medinminutes.repository.FcmAuthRepository;
import com.innovationm.medinminutes.repository.InventoryRepository;
import com.innovationm.medinminutes.repository.OrderMedicineDetailsRepository;
import com.innovationm.medinminutes.repository.OrderRepository;
import com.innovationm.medinminutes.repository.OrganisationRepository;
import com.innovationm.medinminutes.repository.SellerBiddingMedicineRepository;
import com.innovationm.medinminutes.repository.SellerBiddingRepository;
import com.innovationm.medinminutes.repository.SellerDiscountRepository;
import com.innovationm.medinminutes.repository.SubstituteDetailsRepository;
import com.innovationm.medinminutes.repository.UserRepository;
import com.innovationm.medinminutes.request.BuzzedSellerRequest;
import com.innovationm.medinminutes.request.ChangeAutoBuzzStatusRequest;
import com.innovationm.medinminutes.request.ChangeOrderStatusRequest;
import com.innovationm.medinminutes.request.CreateOrderRequest;
import com.innovationm.medinminutes.request.EditOrderRequest;
import com.innovationm.medinminutes.request.GetEstimateItemResponse;
import com.innovationm.medinminutes.request.GetEstimateResponse;
import com.innovationm.medinminutes.request.OrderFilterRequest;
import com.innovationm.medinminutes.request.UpdateSellerStatusRequest;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.response.AssignSellerListResponse;
import com.innovationm.medinminutes.response.BiddingMedicineDetailsResponse;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.CreateOrderResponse;
import com.innovationm.medinminutes.response.GetAgentAndClientNameResponse;
import com.innovationm.medinminutes.response.GetItemFillRateResponse;
import com.innovationm.medinminutes.response.GetOrderResponse;
import com.innovationm.medinminutes.response.GetSkuFillRateResponse;
import com.innovationm.medinminutes.response.OrderListResponse;
import com.innovationm.medinminutes.response.OrderMedicineDetailsResponse;
import com.innovationm.medinminutes.response.PushNotificationListResponse;
import com.innovationm.medinminutes.service.OrderService;
import com.innovationm.medinminutes.service.OrganisationService;
import com.innovationm.medinminutes.service.RoleService;
import com.innovationm.medinminutes.service.SellerBiddingService;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	OrderRepository orderRepository;

//	@Autowired
//	OrderBuzzStatusRepository orderBuzzStatusRepo;

	@Autowired
	OrderMedicineDetailsRepository orderMedicineRepo;

	@Autowired
	InventoryRepository inventoryRepository;

	@Autowired
	SellerBiddingRepository sellerBiddingRepository;

	@Autowired
	OrganisationRepository organisationRepository;

	@Autowired
	SellerDiscountRepository sellerDiscountRepository;

	@Autowired
	SellerBiddingMedicineRepository sellerBiddingMedicineRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	RoleService roleService;

	@Autowired
	FCMService fcmService;

	@Autowired
	FcmAuthRepository fcmAuthRepository;

	@Autowired
	NotificationService notificationService;

	@Autowired
	FCMServiceForSingleToken fCMServiceForSingleToken;

	@Autowired
	SellerBiddingService sellerBiddingService;

	@Autowired
	ItemsSkuService itemsSkuService;

	@Autowired
	SubstituteDetailsRepository substituteRepository;

	@Autowired
	SellerOrderServiceImpl sellerOrderServiceImpl;

	@Autowired
	EntityManager entityManager;

	@Autowired
	OrderBuzz1 orderBuzz1;

	@Autowired
	OrderBuzz2 orderBuzz2;

	@Autowired
	OrderBuzz3 orderBuzz3;

	@Autowired
	TotalLeftQuantity totalLeftQuantity;

	@Autowired
	OrganisationService organisationService;

	@Override
	public CreateOrderResponse createOrder(CreateOrderRequest orderRequest, String email) {
		CreateOrderResponse response = new CreateOrderResponse();

		Boolean check = orderRepository.existsByclientOrderId(orderRequest.getClientOrderId());
		if (Boolean.TRUE.equals(check)) {
			throw new ClientOrderIdAlreadyExistException(AppConstant.ErrorTypes.CLIENT_ORDERID_ALREADY_EXIST_ERROR,
					AppConstant.ErrorCodes.CLIENT_ORDERID_ALREADY_EXIST_ERROR_CODE,
					AppConstant.ErrorMessages.CLIENT_ORDERID_ALREADY_EXIST_ERROR_MESSAGE);
		}

		User account = userRepository.findByEmail(email);
		String updatedBy = "Admin";
		if (account != null) {
			updatedBy = account.getName();
		}

		OrderEntity orderEntity = OrderEntity.builder().address(orderRequest.getAddress())
				.agentId(orderRequest.getAgentId()).agentName(orderRequest.getAgentName()).city(orderRequest.getCity())
				.pincode(orderRequest.getPincode()).clientName(orderRequest.getClientName())
				.clientOrderId(orderRequest.getClientOrderId()).courier(orderRequest.getCourier())
				.customerName(orderRequest.getCustomerName()).deliverBy(orderRequest.getDeliverBy())
				.deliveryCharges(orderRequest.getDeliveryCharges()).discount(orderRequest.getDiscount())
				.latitude(orderRequest.getLatitude()).longitude(orderRequest.getLongitude())
				.orderStatus(OrderStatus.ORDERCREATED).orderTime(new Date()).addedBy(updatedBy)
				.autoBuzzStatus(AutoBuzzStatus.OFF).build();

		try {
			orderEntity = orderRepository.save(orderEntity);
			String mimOrderId = createMimOrderId(orderEntity.getId());
			orderEntity.setMimOrderId(mimOrderId);
			orderEntity.setCreatedBy("Admin");
			orderRepository.save(orderEntity);
			response.setOrderId(orderEntity.getId());

		} catch (Exception e) {

		}
		return response;
	}

	@Override
	@Transactional
	public OrderEntity findOrderById(Long id) {
		if (id == null) {
			throw new InvalidInputException(AppConstant.ErrorTypes.ID_NULL_EXIST_ERROR,
					AppConstant.ErrorCodes.ID_NULL_ERROR_CODE, AppConstant.ErrorMessages.ID_EMPTY_MESSAGE);
		} else {
			return orderRepository.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException(AppConstant.ErrorTypes.ORDER_NOT_EXIST_ERROR,
							AppConstant.ErrorCodes.ORDER_ERROR_CODE,
							AppConstant.ErrorMessages.ORDER_NOT_EXIST_MESSAGE));
		}
	}

	public CommonSuccessResponse editOrder(EditOrderRequest editOrderRequest) {

		if (editOrderRequest.getOrderId() == null) {
			throw new InvalidIdException(AppConstant.ErrorTypes.ID_NULL_EXIST_ERROR,
					AppConstant.ErrorCodes.ID_NULL_ERROR_CODE, AppConstant.ErrorMessages.ID_EMPTY_MESSAGE);
		}
		OrderEntity orderEntity = orderRepository.findById(editOrderRequest.getOrderId())

				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.ORDER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.ORDER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.ORDER_DOES_NOT_EXIST_MESSAGE));

		CommonSuccessResponse response = new CommonSuccessResponse();

		if (editOrderRequest.getCustomerName() != null) {
			orderEntity.setCustomerName(editOrderRequest.getCustomerName());
		}
		if (editOrderRequest.getAddress() != null) {
			orderEntity.setAddress(editOrderRequest.getAddress());
		}
		if (editOrderRequest.getCity() != null) {
			orderEntity.setCity(editOrderRequest.getCity());
		}
		if (editOrderRequest.getPincode() != null) {
			orderEntity.setPincode(editOrderRequest.getPincode());
		}
		if (editOrderRequest.getLatitude() != 0) {
			orderEntity.setLatitude(editOrderRequest.getLatitude());
		}
		if (editOrderRequest.getLongitude() != 0) {
			orderEntity.setLongitude(editOrderRequest.getLongitude());
		}
		if (editOrderRequest.getDeliverBy() != null) {
			orderEntity.setDeliverBy(editOrderRequest.getDeliverBy());
		}
		if (editOrderRequest.getCourier() != null) {
			orderEntity.setCourier(editOrderRequest.getCourier());
		}
		if (editOrderRequest.getDeliveryCharges() != 0) {
			orderEntity.setDeliveryCharges(editOrderRequest.getDeliveryCharges());
		}
		if (editOrderRequest.getAgentId() != null) {
			orderEntity.setAgentId(editOrderRequest.getAgentId());
		}
		if (editOrderRequest.getAgentName() != null) {
			orderEntity.setAgentName(editOrderRequest.getAgentName());
		}
		if (editOrderRequest.getDiscount() != 0) {
			orderEntity.setDiscount(editOrderRequest.getDiscount());
		}

		try {

			orderRepository.save(orderEntity);
			response.setSuccess(true);
		} catch (Exception e) {
			response.setSuccess(false);
		}

		return response;

	}

	public String createMimOrderId(long orderId) {
		StringBuilder mimId = new StringBuilder();
		mimId.append("MIM");
		LocalDate date = LocalDate.now();
		mimId.append(String.format("%02d", date.getMonthValue()));

		mimId.append(String.format("%06d", orderId));

		return mimId.toString();

	}

	@Override
	public OrderListResponse getOrderList(int pageNo, int pageLimit, String searchQuery,
			OrderFilterRequest filterRequest) {

		Pageable page = PageRequest.of(pageNo, pageLimit);

		OrderListResponse response = new OrderListResponse();

		if (filterRequest.getOrderStatus() == null || filterRequest.getOrderStatus().equals(OrderStatus.ORDERALL)) {
			Page<OrderEntity> orderPages = orderRepository.findAllOrderByIdDesc(page, searchQuery,
					filterRequest.getAgentName(), filterRequest.getClientName());
			List<OrderEntity> orderList = orderPages.getContent();
			response.setOrderList(
					orderList.stream().map(orders -> convertOrderList(orders)).collect(Collectors.toList()));
			response.setNoOfPagesAsPerPageLimit(orderPages.getTotalPages());

		} else {
			Page<OrderEntity> orderPages = orderRepository.findAllByFilter(page, searchQuery,
					filterRequest.getOrderStatus(), filterRequest.getAgentName(), filterRequest.getClientName());
			List<OrderEntity> orderList = orderPages.getContent();
			response.setOrderList(
					orderList.stream().map(orders -> convertOrderList(orders)).collect(Collectors.toList()));
			response.setNoOfPagesAsPerPageLimit(orderPages.getTotalPages());

		}

		return response;
	}

	private GetOrderResponse convertOrderList(OrderEntity orders) {

		Date delivaryDate = orders.getDeliverBy();

		delivaryDate.setHours(delivaryDate.getHours() + 6);
		delivaryDate.setMinutes(delivaryDate.getMinutes() - 30);

		Date timeSinceLive = orders.getTimeSinceLive();
		if (timeSinceLive != null) {
			timeSinceLive.setHours(timeSinceLive.getHours() + 6);
			timeSinceLive.setMinutes(timeSinceLive.getMinutes() - 30);
		}

		Date startTime = orders.getOrderTime();
		if (startTime != null) {
			startTime.setHours(startTime.getHours() + 6);
			startTime.setMinutes(startTime.getMinutes() - 30);
		}

		return GetOrderResponse.builder().orderId(orders.getId()).clientOrderId(orders.getClientOrderId())
				.orderdate(orders.getOrderTime()).agentName(orders.getAgentName())
				.customerName(orders.getCustomerName()).city(orders.getCity()).deliverBy(delivaryDate)
				.orderStatus(orders.getOrderStatus()).sinceLive(timeSinceLive).pinCode(orders.getPincode())
				.mimOrderid(orders.getMimOrderId()).customerMob(orders.getClientMob())
				.clientName(orders.getClientName()).courier(orders.getCourier()).startTime(startTime).build();

	}

	@Override
	public GetEstimateResponse getEstimateByOrderId(long orderId) {

		double total = 0;

		GetEstimateResponse response = new GetEstimateResponse();
		OrderEntity order = findOrderById(orderId);

		List<OrderMedicineDetailsEntity> itemsDetails = orderMedicineRepo.findByOrderAndActive(order, true);

		List<GetEstimateItemResponse> itemResponse = itemsDetails.stream()
				.map(item -> convertToItemEstimateResponse(item)).collect(Collectors.toList());

		for (GetEstimateItemResponse i : itemResponse) {
			total += i.getTotal();
		}
		double discountValue = total * order.getDiscount() / 100;
		double totalToPay = (total + order.getDeliveryCharges()) - discountValue;
		response.setCity(order.getCity());
		response.setClientName(order.getClientName());
		response.setCustomerName(order.getCustomerName());
		response.setDeliveryCharges(order.getDeliveryCharges());
		response.setItemsValue(total);
		response.setDiscount(order.getDiscount());
		response.setDiscountValue(discountValue);
		response.setItemsEstimate(itemResponse);
		response.setOrderId(order.getMimOrderId());
		response.setTotalToPay(totalToPay);

		return response;
	}

	@Override
	public GetEstimateResponse getEstimateBySellerBiddingId(long sellerBiddingId) {

		double total = 0;

		SellerBiddingEntity sellerBiddingEntity = sellerBiddingService.findSellerBiddingEntityById(sellerBiddingId);

		GetEstimateResponse response = new GetEstimateResponse();

		List<SellerBiddingMedicine> sellerBiddingMedicines = sellerBiddingMedicineRepository
				.findBySellerBidding(sellerBiddingEntity);

		List<SellerBiddingMedicine> toBePackedSellerBiddingMedicines = sellerBiddingMedicines.stream()
				.filter(sellerbidding -> sellerbidding.getIsToBePacked()).collect(Collectors.toList());

		List<GetEstimateItemResponse> itemResponse = toBePackedSellerBiddingMedicines.stream()
				.map(item -> convertToPackedItemEstimateResponse(item)).collect(Collectors.toList());

		for (GetEstimateItemResponse i : itemResponse) {
			total += i.getTotal();
		}
		double totalToPay = total * sellerBiddingEntity.getSellerDiscount() / 100;

		totalToPay = total - totalToPay + sellerBiddingEntity.getOrder().getDeliveryCharges();
		System.out.println("total to pay:-" + totalToPay);
		response.setCity(sellerBiddingEntity.getOrder().getCity());
		response.setClientName(sellerBiddingEntity.getOrder().getClientName());
		response.setCustomerName(sellerBiddingEntity.getOrder().getCustomerName());
		response.setDeliveryCharges(sellerBiddingEntity.getOrder().getDeliveryCharges());
		response.setItemsValue(total);
		response.setDiscount(sellerBiddingEntity.getOrder().getDiscount());
		response.setDiscountValue(0);
		response.setItemsEstimate(itemResponse);
		response.setOrderId(sellerBiddingEntity.getOrder().getMimOrderId());
		response.setTotalToPay(totalToPay);

		return response;
	}

	private GetEstimateItemResponse convertToPackedItemEstimateResponse(SellerBiddingMedicine entity) {
		Double total = 0.0;
		Integer sellerProvideQuantity = 0;

		System.out.println(entity.getQuantitySellerProvide());

		if (entity.getQuantitySellerProvide() != null) {
			total = entity.getQuantitySellerProvide() * entity.getMrp();
			sellerProvideQuantity = entity.getQuantitySellerProvide();
		}

		System.out.println("total=" + total);
		System.out.println("quantity=" + sellerProvideQuantity);
		return GetEstimateItemResponse.builder().itemName(entity.getInventory().getName())
				.quantity(sellerProvideQuantity).rate(entity.getMrp()).total(total).build();
	}

	private GetEstimateItemResponse convertToItemEstimateResponse(OrderMedicineDetailsEntity item) {

		double total = item.getQuantityRequired() * item.getMrp();
		return GetEstimateItemResponse.builder().itemName(item.getInventory().getName())
				.quantity(item.getQuantityRequired()).rate(item.getMrp()).total(total).build();
	}

	public GetOrderResponse getOrderDetails(Long orderId) {

		OrderEntity entity = orderRepository.findById(orderId)
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.ORDER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.ORDER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.ORDER_DOES_NOT_EXIST_MESSAGE));

		Date delivaryDate = entity.getDeliverBy();

		delivaryDate.setHours(delivaryDate.getHours() + 6);
		delivaryDate.setMinutes(delivaryDate.getMinutes() - 30);

		Date timeSinceLive = entity.getTimeSinceLive();
		if (timeSinceLive != null) {
			timeSinceLive.setHours(timeSinceLive.getHours() + 6);
			timeSinceLive.setMinutes(timeSinceLive.getMinutes() - 30);
		}

		Date startTime = entity.getOrderTime();
		if (startTime != null) {
			startTime.setHours(startTime.getHours() + 6);
			startTime.setMinutes(startTime.getMinutes() - 30);
		}

		GetOrderResponse response = GetOrderResponse.builder().clientOrderId(entity.getClientOrderId())
				.orderId(entity.getId()).orderdate(entity.getOrderTime()).agentName(entity.getAgentName())
				.customerName(entity.getCustomerName()).city(entity.getCity()).deliverBy(delivaryDate)
				.customerMob(entity.getClientMob()) // not present in db
				.discount(entity.getDiscount()).deliveryCharges(entity.getDeliveryCharges())
				.orderStatus(entity.getOrderStatus()).sinceLive(timeSinceLive).clientName(entity.getClientName())
				.addedBy(entity.getAddedBy()).courier(entity.getCourier()).deliveryAddress(entity.getAddress())
				.latitude(entity.getLatitude()).longitude(entity.getLongitude()).mimOrderid(entity.getMimOrderId())
				.startTime(startTime).pinCode(entity.getPincode()).autoBuzzedStatus(entity.getAutoBuzzStatus()).build();

		List<OrderMedicineDetailsEntity> orderMedicineDetailsEntity = orderMedicineRepo.findByOrderId(orderId);

		response.setOrderMedicine(orderMedicineDetailsEntity.stream().map(medicine -> orderMedicine(medicine))
				.collect(Collectors.toList()));

		List<SellerBiddingEntity> sellerBidding = sellerBiddingRepository.findByOrderId(orderId);

		if (sellerBidding != null) {
			response.setSellerList(
					sellerBidding.stream().map(bidding -> convertToSellerBidding(bidding, orderMedicineDetailsEntity))
							.collect(Collectors.toList()));
		}

		return response;

	}

	private OrderMedicineDetailsResponse orderMedicine(OrderMedicineDetailsEntity medicine) {
		int leftTopack = medicine.getQuantityRequired();
		if (medicine.getQuantitySellerProvide() != null) {
			leftTopack = medicine.getQuantityRequired() - medicine.getQuantitySellerProvide();
		}

		InventoryEntity inventory = inventoryRepository.findById(medicine.getInventory().getId()).orElseThrow(null);
		return OrderMedicineDetailsResponse.builder().inventoryName(inventory.getName()).leftToPack(leftTopack)
				.quantityRequired(medicine.getQuantityRequired()).price(medicine.getMrp()).build();
	}

	private AssignSellerListResponse convertToSellerBidding(SellerBiddingEntity bidding,
			List<OrderMedicineDetailsEntity> orderMedicineDetailsEntity) {

		SellerOrganisationBranchEntity seller = organisationRepository.findById(bidding.getSeller().getId())
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.SELLER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.SELLER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.SELLER_DOES_NOT_EXIST_MESSAGE));

		List<SellerBiddingMedicine> sellerBiddingMedicine = sellerBiddingMedicineRepository
				.findBySellerBidding(bidding);

		GetItemFillRateResponse itemFillRate = itemsSkuService.calculateItemsFillRate(orderMedicineDetailsEntity,
				bidding);
		GetSkuFillRateResponse skuFillRate = itemsSkuService.calculateSkuFillRate(orderMedicineDetailsEntity, bidding);

		Optional<OrderEntity> orderEntity = orderRepository.findById(bidding.getOrder().getId());

		double sellerCustomerDistance = sellerOrderServiceImpl.getDistance1(seller.getLatitude(), seller.getLongitude(),
				orderEntity.get().getLatitude(), orderEntity.get().getLongitude());

		String appStatus = "Off";
		if (bidding.getAppStatus() == Boolean.TRUE) {
			appStatus = "On";
		}

		Date timeSinceLastAction = bidding.getUpdated();
		if (timeSinceLastAction != null) {
			timeSinceLastAction.setHours(timeSinceLastAction.getHours() + 6);
			timeSinceLastAction.setMinutes(timeSinceLastAction.getMinutes() - 30);
		}

		AssignSellerListResponse response = AssignSellerListResponse.builder().action(null).appStatus(null)
				.discount(seller.getMaxdiscount()).pincode(seller.getPincode()).distance(sellerCustomerDistance)
				.sellerName(seller.getSellerName()).sellerId(seller.getId()).sellerlatitude(seller.getLatitude())
				.sellerlongitude(seller.getLongitude()).sellerNumber(seller.getWhatsAppNumber()).sellerOrderStatus(null)
				.sellerStatus(bidding.getSellerStatus()).buzzedStatus(bidding.getBuzzStatus())
				.timeSinceLastAction(timeSinceLastAction).itemsFillRate(itemFillRate).skuFillRate(skuFillRate)
				.appStatus(appStatus).build();

		response.setBiddingMedicine(
				sellerBiddingMedicine.stream().map(med -> convertToBiddingMedicine(med)).collect(Collectors.toList()));
		return response;
	}

	private BiddingMedicineDetailsResponse convertToBiddingMedicine(SellerBiddingMedicine med) {

		InventoryEntity inventory = inventoryRepository.findById(med.getInventory().getId()).orElseThrow(null);

		int totalSubs = 0;
		List<String> substituteName = new ArrayList();
		if (Boolean.TRUE.equals(med.getHavingSubstitute())) {
			System.out.println("Order medicine details id:- " + med.getOrderMedicine());
			List<SubstituteDetailsEntity> substituteList = substituteRepository
					.findByorderMedicineDetailAndSellerBidding(med.getOrderMedicine(), med.getSellerBidding());
			totalSubs = substituteList.size();

			for (SubstituteDetailsEntity name : substituteList) {
				substituteName.add(name.getSubstituteName());
			}
		}
		System.out.println(substituteName + " " + substituteName.size());
		return BiddingMedicineDetailsResponse.builder().havingSubstitute(med.getHavingSubstitute())
				.isToBePacked(med.getIsToBePacked()).sellerPrice(med.getSellerPrice())
				.avlQuantity(med.getAvailableAmount()).quantitySellerProvide(med.getQuantitySellerProvide())
				.discount(med.getDiscount()).inventoryId(inventory.getId()).inventoryName(inventory.getName())
				.totalSubs(totalSubs).substituteName(substituteName).build();
	}

	@Override
	public CommonSuccessResponse changeStatus(ChangeOrderStatusRequest changeOrderStatusRequest) {

		CommonSuccessResponse response = new CommonSuccessResponse(false);

		OrderEntity orderEntity = orderRepository.findById(changeOrderStatusRequest.getOrderId())
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.ORDER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.ORDER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.ORDER_DOES_NOT_EXIST_MESSAGE));

		orderEntity.setOrderStatus(changeOrderStatusRequest.getOrderStatus());

		if (changeOrderStatusRequest.getOrderStatus().equals(OrderStatus.ORDERLIVE)) {
			orderEntity.setTimeSinceLive(new Date());
		}
		orderEntity.setUpdated(new Date());
		orderEntity.setUpdatedBy("Admin");

		try {
			orderRepository.save(orderEntity);
			response.setSuccess(true);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return response;

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public PushNotificationListResponse assignSeller(BuzzedSellerRequest buzzedSellerRequest) {

		OrderEntity orderEntity = orderBuzz1.findOrderDetails(buzzedSellerRequest.getOrderId());
		if (orderEntity.getAutoBuzzStatus().equals(AutoBuzzStatus.OFF)) {
			orderBuzz2.updateBuzzStatus(buzzedSellerRequest.getOrderId());

			PushNotificationListResponse response1 = new PushNotificationListResponse();
			if (!buzzedSellerRequest.getSellerId().isEmpty()) {

				List<Long> sellerBidddingId = new ArrayList();
				for (int i = 0; i < buzzedSellerRequest.getSellerId().size(); i++) {

					SellerOrganisationBranchEntity seller = organisationService
							.getSellerOrganizationBranchEntity(buzzedSellerRequest.getSellerId().get(i));
					if (seller.getRegistrationStatus().equals(RegistrationStatus.LIVE)) {
						OrderEntity orderEntity1 = orderBuzz1.findOrderDetails(buzzedSellerRequest.getOrderId());
						System.out.println("firstLoop" + i);
						System.out.println("buzzedStatus===" + orderEntity1.getAutoBuzzStatus());
						if (orderEntity1.getAutoBuzzStatus().equals(AutoBuzzStatus.ON)) {

							int LTP = totalLeftQuantity.getTotalQuantity(buzzedSellerRequest.getOrderId());
							System.out.println("LTP="+LTP);
							if (LTP > 0) {

								SellerBiddingEntity sellerBidding = sellerBiddingRepository
										.findByOrderAndSellerId(orderEntity, buzzedSellerRequest.getSellerId().get(i));

//							if (sellerBidding.getBuzzStatus().equals(BuzzStatus.BUZZED)
//									&& !sellerBidding.getSellerStatus().equals(SellerStatus.TOFIND)) {
//								throw new AlreadyAddedItemException(AppConstant.ErrorTypes.ALREADY_BUZZED_ERROR,
//										AppConstant.ErrorCodes.ALREADY_BUZZED_ERROR_CODE,
//										AppConstant.ErrorMessages.ALREADY_BUZZED_ERROR_MESSAGE);
//							}
								if (sellerBidding.getBuzzStatus() == BuzzStatus.TOFIND) {
//							long sellerBiddingId = assignOrderToSeller(buzzedSellerRequest.getSellerId().get(i),
//									orderEntity);
									long sellerBiddingId = orderBuzz3
											.assignSeller(buzzedSellerRequest.getSellerId().get(i), orderEntity);
									sellerBidddingId.add(sellerBiddingId);

									try {
										Logger logger = Logger.getLogger(OrderServiceImpl.class);
										logger.warn("started push notification");
										List<Long> tempSellerBidddingId = new ArrayList();
										tempSellerBidddingId.add(sellerBiddingId);
										response1.setNotificationList(tempSellerBidddingId.stream().map(
												id -> notificationService.convertToPushNotification(id, orderEntity))
												.collect(Collectors.toList()));
										logger.warn("end push notification");

									} catch (Exception e) {
										// TODO: handle exception
										e.printStackTrace();
									}

									if (buzzedSellerRequest.getSellerId().size() > 1) {
										try {
//									 if(i==(buzzedSellerRequest.getSellerId().size())-1) {
//											break;
//										}
											Thread.sleep(5 * 60 * 1000);
										} catch (InterruptedException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
									}
								}
							}
							 else {
								 orderBuzz2.updateBuzzStatusOFF(buzzedSellerRequest.getOrderId());
									System.out.println("exception occur");
									throw new LtpOverException(AppConstant.ErrorTypes.QUANTITY_NOT_AVL_ERROR,
											AppConstant.ErrorCodes.QUANTITY_NOT_AVL_ERROR_CODE,
											AppConstant.ErrorMessages.QUANTITY_NOT_AVL_MESSAGE);
								}
						}
					}
				}

				 orderBuzz2.updateBuzzStatusOFF(buzzedSellerRequest.getOrderId());

			}

			return response1;
		} else {
			throw new BuzzPausedException(AppConstant.ErrorTypes.BUZZ_PAUSED_ERROR,
					AppConstant.ErrorCodes.BUZZ_PAUSED_ERROR_CODE, AppConstant.ErrorMessages.BUZZ_PROCESSING_MESSAGE);
		}
	}

// assign order to seller
	private long assignOrderToSeller(Long sellerId, OrderEntity orderEntity) {

		SellerOrganisationBranchEntity sellerEntity = organisationRepository.findById(sellerId)
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.SELLER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.SELLER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.SELLER_DOES_NOT_EXIST_MESSAGE));

//		SellerBiddingEntity seller = sellerBiddingRepository.findByOrderAndSeller(orderEntity, sellerEntity);
//		if (seller != null) {
//			throw new UserNotFoundException(AppConstant.ErrorTypes.ALREADY_BUZZED_ERROR,
//					AppConstant.ErrorCodes.ALREADY_BUZZED_ERROR_CODE,
//					AppConstant.ErrorMessages.ALREADY_BUZZED_ERROR_MESSAGE);
//		}

		SellerBiddingEntity entity = SellerBiddingEntity.builder().order(orderEntity).seller(sellerEntity)
				.buzzStatus(BuzzStatus.BUZZED).buzzTime(new Date()).sellerStatus(SellerStatus.TOBID).appStatus(false)
				.build();
		entity = sellerBiddingRepository.save(entity);
		return entity.getId();

	}

	@Override
	public GetAgentAndClientNameResponse getAgentsAndClientsNames() {

		GetAgentAndClientNameResponse response = new GetAgentAndClientNameResponse();

		RoleEntity agentRole = roleService.findById((long) 2);
		List<String> clientNames = orderRepository.findAllClientsNames();
		List<String> agentNames = userRepository.findAllByRole(agentRole);
		response.setClientName(clientNames);
		response.setAgentName(agentNames);
		return response;
	}

//	@Override
//	public PushNotificationResponse updateSellerStatus(UpdateSellerStatusRequest updateSellerStatusRequest) {
//
//		PushNotificationResponse response = new PushNotificationResponse();
//
//		OrderEntity orderEntity = orderRepository.findById(updateSellerStatusRequest.getOrderId())
//				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.ORDER_DOES_NOT_EXIST_ERROR,
//						AppConstant.ErrorCodes.ORDER_DOES_NOT_EXIST_ERROR_CODE,
//						AppConstant.ErrorMessages.ORDER_DOES_NOT_EXIST_MESSAGE));
//
//		SellerOrganisationBranchEntity sellerEntity = organisationRepository
//				.findById(updateSellerStatusRequest.getSellerId())
//				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.SELLER_DOES_NOT_EXIST_ERROR,
//						AppConstant.ErrorCodes.SELLER_DOES_NOT_EXIST_ERROR_CODE,
//						AppConstant.ErrorMessages.SELLER_DOES_NOT_EXIST_MESSAGE));
//
//		SellerBiddingEntity sellerBiddingEntity = sellerBiddingRepository.findByOrderAndSeller(orderEntity,
//				sellerEntity);
//
//		sellerBiddingEntity.setSellerStatus(updateSellerStatusRequest.getSellerStatus());
//		sellerBiddingEntity.setBuzzTime(new Date());
//		sellerBiddingRepository.save(sellerBiddingEntity);
//
//		if (!updateSellerStatusRequest.getSellerStatus().equals(SellerStatus.SENT)) {
//			FcmAuthInfoEntity fcmEntity = fcmAuthRepository.findByUserId(sellerEntity.getSellerUserId());
//
//			int totalQuantity = notificationService.getTotalQuantity(orderEntity.getId());
//			System.out.println(String.valueOf("quantity=" + totalQuantity));
//
//			double totalMRP = notificationService.getTotalMRP(orderEntity.getId());
//
//			Date buzzTime = sellerBiddingEntity.getBuzzTime();
//			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//			String buzzDate = formatter.format(buzzTime);
//
//			System.out.println(buzzDate);
//
//			if (fcmEntity != null) {
//				String messageContent = null;
//				String title = null;
//				Integer flagValue = AppConstant.Commons.FLAG_VALUE_FOR_TOBID;
//				HashMap<String, String> appData = new HashMap<>();
//				appData.put("OrderId", orderEntity.getId().toString());
//				appData.put("customerName", orderEntity.getCustomerName());
//				appData.put("totalQuantity", String.valueOf(totalQuantity));
//				appData.put("totalMRP", String.valueOf(totalMRP));
//				appData.put("sellerBiddingId", sellerBiddingEntity.getId().toString());
//				appData.put("buzzedTime", buzzDate);
//
//				if (updateSellerStatusRequest.getSellerStatus() == SellerStatus.TOPACK) {
//					title = "To Pack";
//					messageContent = "please pack for this order";
//					flagValue = AppConstant.Commons.FLAG_VALUE_FOR_TOPACK;
//				}
//				try {
//
//					response = fCMServiceForSingleToken.sendNotification(fcmEntity, appData, title, messageContent,
//							flagValue);
//
//				} catch (Exception e) {
//					// TODO: handle exception
//				}
//			}
//		}
//		return response;
//	}

	@Override
	public PushNotificationResponse updateSellerStatus(UpdateSellerStatusRequest updateSellerStatusRequest) {

		PushNotificationResponse response = new PushNotificationResponse();

		OrderEntity orderEntity = orderRepository.findById(updateSellerStatusRequest.getOrderId())
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.ORDER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.ORDER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.ORDER_DOES_NOT_EXIST_MESSAGE));

		SellerOrganisationBranchEntity sellerEntity = organisationRepository
				.findById(updateSellerStatusRequest.getSellerId())
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.SELLER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.SELLER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.SELLER_DOES_NOT_EXIST_MESSAGE));

		SellerBiddingEntity sellerBiddingEntity = sellerBiddingRepository.findByOrderAndSeller(orderEntity,
				sellerEntity);

		sellerBiddingEntity.setSellerStatus(updateSellerStatusRequest.getSellerStatus());
		sellerBiddingEntity.setBuzzTime(new Date());
		sellerBiddingEntity.setUpdated(new Date());
		sellerBiddingRepository.save(sellerBiddingEntity);

		if (updateSellerStatusRequest.getSellerStatus().equals(SellerStatus.TOPACK)
				|| updateSellerStatusRequest.getSellerStatus().equals(SellerStatus.PACKED)) {
			response = notificationService.sendToPackAndPackedNotificationToSeller(sellerBiddingEntity,
					updateSellerStatusRequest.getSellerStatus());
		}

		return response;
	}

	@Override
	@Transactional
	public CommonSuccessResponse changeAutoBuzzStatus(ChangeAutoBuzzStatusRequest changeAutoBuzzStatusRequest) {

		CommonSuccessResponse response = new CommonSuccessResponse(false);

		OrderEntity orderEntity = orderRepository.findById(changeAutoBuzzStatusRequest.getOrderId())
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.ORDER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.ORDER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.ORDER_DOES_NOT_EXIST_MESSAGE));

		// OrderBuzzStatusEntity orderBuzzStatusEntity = new OrderBuzzStatusEntity();
		if (changeAutoBuzzStatusRequest.getAutoBuzzStatus().equals(AutoBuzzStatus.ON)) {
			orderEntity.setAutoBuzzStatus(AutoBuzzStatus.ON);
			// orderBuzzStatusEntity.setAutoBuzzStatus(AutoBuzzStatus.ON);
		}

		else {
			orderEntity.setAutoBuzzStatus(AutoBuzzStatus.OFF);
			// orderBuzzStatusEntity.setAutoBuzzStatus(AutoBuzzStatus.OFF);
		}

		// orderBuzzStatusEntity.setOrder(orderEntity);
		try {
			synchronized (orderEntity) {
				orderRepository.save(orderEntity);
				// orderBuzzStatusRepo.save(orderBuzzStatusEntity);
			}
			response.setSuccess(true);
		} catch (Exception e) {
			// TODO: handle exception
		}

		return response;
	}

	@Override
	public CommonSuccessResponse alreadyAdddedItems(String inventoryName, Long orderId, Integer qtyPerPack) {

		CommonSuccessResponse response = new CommonSuccessResponse(false);

		OrderEntity orderEntity = orderRepository.findById(orderId)
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.ORDER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.ORDER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.ORDER_DOES_NOT_EXIST_MESSAGE));

		List<InventoryEntity> inventory = inventoryRepository.findByNameAndQtyPerPacks(inventoryName, qtyPerPack);

		if (inventory.size() > 0) {
			System.out.println(inventory);
			System.out.println(inventory.get(0).getId());

			OrderMedicineDetailsEntity orderMedicine = orderMedicineRepo
					.findByOrderIdAndInventoryId(orderEntity.getId(), inventory.get(0).getId());

			if (orderMedicine != null) {
				System.out.println(orderMedicine.getInventory().getName());
				response.setSuccess(true);
			}
		}
		return response;
	}
}