package com.innovationm.medinminutes.serviceImpl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.innovationm.medinminutes.entity.OrderEntity;
import com.innovationm.medinminutes.entity.SellerBiddingEntity;
import com.innovationm.medinminutes.entity.SellerOrganisationBranchEntity;
import com.innovationm.medinminutes.enums.BuzzStatus;
import com.innovationm.medinminutes.enums.SellerStatus;
import com.innovationm.medinminutes.exception.UserNotFoundException;
import com.innovationm.medinminutes.repository.OrganisationRepository;
import com.innovationm.medinminutes.repository.SellerBiddingRepository;
import com.innovationm.medinminutes.resources.AppConstant;

@Service
public class OrderBuzz3 {

	
	@Autowired
	OrganisationRepository organisationRepository;
	
	@Autowired
	SellerBiddingRepository sellerBiddingRepository;

	// assign order to seller new changes
		@Transactional(propagation= Propagation.REQUIRES_NEW)
		public long assignSeller(Long sellerId, OrderEntity orderEntity) {

			SellerOrganisationBranchEntity sellerEntity = organisationRepository.findById(sellerId)
					.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.SELLER_DOES_NOT_EXIST_ERROR,
							AppConstant.ErrorCodes.SELLER_DOES_NOT_EXIST_ERROR_CODE,
							AppConstant.ErrorMessages.SELLER_DOES_NOT_EXIST_MESSAGE));

			SellerBiddingEntity entity = sellerBiddingRepository.findByOrderAndSeller(orderEntity, sellerEntity);

			entity.setBuzzStatus(BuzzStatus.BUZZED);
			entity.setBuzzTime(new Date());
			entity.setSnoozedBuzzTime(new Date());
			entity.setSellerStatus(SellerStatus.TOBID);
			entity.setAppStatus(false);

//	             SellerBiddingEntity entity = SellerBiddingEntity.builder().order(orderEntity).seller(sellerEntity)
//						.buzzStatus(BuzzStatus.BUZZED).buzzTime(new Date()).sellerStatus(SellerStatus.TOBID).appStatus(false)
//						.build();
			entity = sellerBiddingRepository.save(entity);
			return entity.getId();

		}
}
