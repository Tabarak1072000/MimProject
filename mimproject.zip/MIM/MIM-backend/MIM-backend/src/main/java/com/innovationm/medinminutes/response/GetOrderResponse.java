package com.innovationm.medinminutes.response;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.innovationm.medinminutes.enums.AutoBuzzStatus;
import com.innovationm.medinminutes.enums.OrderStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data

public class GetOrderResponse {

	private long orderId;
	private String mimOrderid;
	private String clientOrderId;
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date orderdate;
	private OrderStatus orderStatus;
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date sinceLive;
	private String agentName;
	private String customerName;
	private String clientName;
	private String city;
	private String pinCode;
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date deliverBy;
	private String customerMob;
	private double discount;
	private double deliveryCharges;
	private String courier;
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date startTime;
	private String deliveryAddress;
	private double latitude;
	private double longitude;
	private String addedBy;
	private String ordersStatus;
	
	private AutoBuzzStatus autoBuzzedStatus;
	
	
	
	private List<AssignSellerListResponse> sellerList;
	
	private List<OrderMedicineDetailsResponse> orderMedicine;
	
	
}
