package com.innovationm.medinminutes.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.innovationm.medinminutes.entity.OrderEntity;
import com.innovationm.medinminutes.exception.UserNotFoundException;
import com.innovationm.medinminutes.repository.OrderRepository;
import com.innovationm.medinminutes.resources.AppConstant;

@Service
public class OrderBuzz1 {

	@Autowired
	OrderRepository orderRepository;
	
	@Transactional(propagation= Propagation.REQUIRES_NEW)
	public OrderEntity findOrderDetails(Long orderId) {
		return orderRepository.findById(orderId)
		.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.ORDER_DOES_NOT_EXIST_ERROR,
				AppConstant.ErrorCodes.ORDER_DOES_NOT_EXIST_ERROR_CODE,
				AppConstant.ErrorMessages.ORDER_DOES_NOT_EXIST_MESSAGE));
		}
	
}
