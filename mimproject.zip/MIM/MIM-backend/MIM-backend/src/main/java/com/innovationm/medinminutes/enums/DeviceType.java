package com.innovationm.medinminutes.enums;

public enum DeviceType {
  NA, ANDROID, IOS
}
