package com.innovationm.medinminutes.service;

import com.innovationm.medinminutes.entity.CategoryEntity;

public interface CategoryService {

	public CategoryEntity findCategoryById(Long id);
}
