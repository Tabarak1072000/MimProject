package com.innovationm.medinminutes.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Substitute_Details")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SubstituteDetailsEntity extends BaseEntity{
	
	private String substituteName;
	
	private double price;
	
	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH, 
			CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name="inventory_id", nullable = false)
	private InventoryEntity inventory;
	
	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH, 
			CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name="order_medicine_details_id", nullable = false)
	private OrderMedicineDetailsEntity orderMedicineDetail;
	
	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH, 
			CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name="seller_bidding_id", nullable = false)
	private SellerBiddingEntity sellerBidding;
}
