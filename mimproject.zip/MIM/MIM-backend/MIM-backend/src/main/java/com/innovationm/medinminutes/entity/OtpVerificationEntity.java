package com.innovationm.medinminutes.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "otp_verification")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OtpVerificationEntity extends BaseEntity {

	private String otp;

	private String phoneNumber;

	private String email;

	private Boolean isVerified;

}
