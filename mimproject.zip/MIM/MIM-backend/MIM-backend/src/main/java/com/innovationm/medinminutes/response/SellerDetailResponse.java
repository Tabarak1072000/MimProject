package com.innovationm.medinminutes.response;

import java.util.Date;

import com.innovationm.medinminutes.enums.RegistrationStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SellerDetailResponse {

	private Long sellerId;
	private String businessName;
	private String branchName;
	private String managerName;
	private String whatsAppNumber;
	private String address;
	private String city;
	private String pincode;
	private Boolean isAgreementAccepted;
	private Boolean isApproved;
	private Date requestRejectionTime;
	private String referredBy;
	private String sellerName;
	private String sellerPhoneNumber;
	private double discountTo;
	private double discountFrom;
	private double maxDiscount;
	private RegistrationStatus registrationStatus;
	private String submittedDate;
	private String responseDate;
	private String gstNo;
	private String bankAccountNo;
	private String benefeciaryName;
	private String ifscCode;
	private String addedBy;
	private double latitude;
	private double longitude;
	private String lmb;
	
	private Long userId;
}
