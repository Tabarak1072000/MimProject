package com.innovationm.medinminutes.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.innovationm.medinminutes.entity.FcmAuthInfoEntity;

@Repository
public interface FcmAuthRepository extends JpaRepository<FcmAuthInfoEntity, Long> {

//	@Query(value="select new com.innovationm.medinminutes.request.PushNotificationTokenRequest(f.fcmToken,f.deviceType) from FcmAuthInfoEntity f where f.userId In(:userId) and f.active=true" )	
//	List<PushNotificationTokenRequest> findAllByUserId(List<Long> userId);
//
	@Query(value = "select f from FcmAuthInfoEntity f where f.userId=:userId and f.active=true")
	FcmAuthInfoEntity findByUserId(Long userId);
	

	@Query(value = "SELECT f from FcmAuthInfoEntity as f where f.userId=:userId ")
	FcmAuthInfoEntity findByUserEntity(Long userId);
	
	@Query(value = "SELECT a from FcmAuthInfoEntity a where a.deviceId=:deviceId and a.id=:id and a.active=true")
	FcmAuthInfoEntity findByUserEntityAndDeviceId(Long id, String deviceId);
	

}
