package com.innovationm.medinminutes.service;

import com.innovationm.medinminutes.entity.SellerDiscountEntity;
import com.innovationm.medinminutes.entity.SellerOrganisationBranchEntity;

public interface SellerDiscountService {

	SellerDiscountEntity findById(Long id);

	SellerDiscountEntity findBysellerId(SellerOrganisationBranchEntity seller);

	// public List<SellerDiscountEntity> findById(Long id);
}
