package com.innovationm.medinminutes;

import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

import com.innovationm.medinminutes.resources.AppConstant;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@PropertySources(value = { @PropertySource(AppConstant.Config.APPLICATION_PROPERTY_SOURCE_PATH) })
@SpringBootApplication
@EnableSwagger2
@EnableScheduling
public class MedinminutesApplication {

	public static void main(String[] args) {
		Logger logger = Logger.getLogger(MedinminutesApplication.class);
		SpringApplication.run(MedinminutesApplication.class, args);

		// logger.error("File is not save");
		logger.warn("Run Successfully");
		logger.debug("Log4j appender configuration is successful !!");
		logger.fatal("Fatal Message!");

	}

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
