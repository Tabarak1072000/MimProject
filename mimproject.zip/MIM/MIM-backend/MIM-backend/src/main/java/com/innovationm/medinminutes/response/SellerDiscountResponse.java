package com.innovationm.medinminutes.response;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.innovationm.medinminutes.enums.RegistrationStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SellerDiscountResponse {

	private Long sellerId;
	
	private double discountFrom;
	private double discounTo;
	private RegistrationStatus registrationStatus;
	
	private String submittedDate;
	private String responseDate;
	
}
