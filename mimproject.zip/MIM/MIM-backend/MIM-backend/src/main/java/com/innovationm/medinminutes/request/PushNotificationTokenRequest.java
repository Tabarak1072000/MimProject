package com.innovationm.medinminutes.request;



import com.innovationm.medinminutes.enums.DeviceType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class PushNotificationTokenRequest {

	private String userDeviceToken;
	private DeviceType deviceType;
}
