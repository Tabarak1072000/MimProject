package com.innovationm.medinminutes.serviceImpl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.innovationm.medinminutes.entity.FcmAuthInfoEntity;
import com.innovationm.medinminutes.entity.OtpVerificationEntity;
import com.innovationm.medinminutes.entity.RoleEntity;
import com.innovationm.medinminutes.entity.SellerOrganisationBranchEntity;
import com.innovationm.medinminutes.entity.User;
import com.innovationm.medinminutes.enums.RegistrationStatus;
import com.innovationm.medinminutes.exception.InvalidIdException;
import com.innovationm.medinminutes.exception.InvalidOtpException;
import com.innovationm.medinminutes.exception.ResourceNotFoundException;
import com.innovationm.medinminutes.exception.UserNotFoundException;
import com.innovationm.medinminutes.repository.FcmAuthRepository;
import com.innovationm.medinminutes.repository.OtpVerificationRepository;
import com.innovationm.medinminutes.repository.SellerOrganisationBranchRepository;
import com.innovationm.medinminutes.repository.UserRepository;
import com.innovationm.medinminutes.request.FcmTokenRequest;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.response.AddUserResponse;
import com.innovationm.medinminutes.response.AuthorizationResponse;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.service.OrganisationService;
import com.innovationm.medinminutes.service.RoleService;
import com.innovationm.medinminutes.service.UserService;
import com.innovationm.medinminutes.util.JwtTokenUtil;

@Service
public class UserServiceImpl implements UserService, UserDetailsService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	OTPService otpService;

	@Autowired
	SellerOrganisationBranchRepository organizationRepository;

	@Autowired
	OtpVerificationRepository otpVerificationRepository;

	@Autowired
	Base64PasswordService encoder;

	@Autowired
	private JwtTokenUtil accessToken;

	@Autowired
	private RoleService roleService;

	@Autowired
	private OrganisationService organisaionService;

	@Autowired
	FcmAuthRepository fcmAuthRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRepository.getUserByEmail(username);

		// User user = userRepository.getUserByUid(uid);
		if (user == null) {
			throw new UserNotFoundException(AppConstant.ErrorTypes.USER_NOT_EXIST_ERROR,
					AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
					AppConstant.ErrorMessages.USER_NOT_EXIST_MESSAGE);
		}
		return new MIMUserDetails(user);
	}

	@Override
	public AddUserResponse addSeller(String phoneNumber) {

		User userEntity = userRepository.findByPhoneNumber(phoneNumber);

		AddUserResponse response = new AddUserResponse();
		if (userEntity != null) {
			int otp = otpService.generateOTP(phoneNumber);
			// boolean isSent = otpService.createPhoneOTP(phoneNumber, otp);

			OtpVerificationEntity verification = otpVerificationRepository.findByPhoneNumber(phoneNumber);
			if (verification != null) {
				verification.setUpdated(new Date());
				verification.setOtp(String.valueOf(otp));
				otpVerificationRepository.save(verification);

			} else {
				OtpVerificationEntity verificationEntity = OtpVerificationEntity.builder().email(null).isVerified(true)
						.otp(String.valueOf(otp)).phoneNumber(phoneNumber).build();
				otpVerificationRepository.save(verificationEntity);
			}

			response.setUserId(userEntity.getId());
			response.setVerficationOtp(otp);
		} else {

			String randomPassword = generateRandomPassword();
			String randomUsername = generateRandomPassword();

			RoleEntity sellerRole = roleService.findById((long) 1);

			User user = User.builder().email(randomUsername).password(encoder.encode(randomPassword))
					.phoneNumber(phoneNumber).role(sellerRole).status(0).createdAt(new Date()).updatedAt(new Date())
					.build();

			// saving seller info in user table

			int otp = otpService.generateOTP(phoneNumber);
			// boolean isSent = otpService.createPhoneOTP(phoneNumber, otp);

			// otpService.createPhoneOTP(phoneNumber);
			user = userRepository.save(user);

			OtpVerificationEntity verification = OtpVerificationEntity.builder().otp(String.valueOf(otp))
					.phoneNumber(phoneNumber).isVerified(false).build();

			SellerOrganisationBranchEntity sellerOrganisationBranchEntity = new SellerOrganisationBranchEntity();
			sellerOrganisationBranchEntity.setWhatsAppNumber(phoneNumber);
			sellerOrganisationBranchEntity.setSellerUserId(user.getId());
			otpVerificationRepository.save(verification);
			organizationRepository.save(sellerOrganisationBranchEntity);

			response.setUserId(user.getId());
			response.setVerficationOtp(otp);

		}
		return response;
	}

	public User findByEmail(String email) {
		User user = userRepository.getUserByEmail(email);
		if (user != null) {
			return user;
		} else {
			throw new UserNotFoundException(AppConstant.ErrorTypes.USER_NOT_EXIST_ERROR,
					AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
					AppConstant.ErrorMessages.USER_NOT_EXIST_MESSAGE);
		}
	}

	public String generateRandomPassword() {
		return UUID.randomUUID().toString().replaceAll("[^A-Za-z0-9]", "").substring(0, 10);
	}

	public AuthorizationResponse verifySeller(String phoneNumber, String otp) {

		OtpVerificationEntity verification = otpVerificationRepository.findByPhoneNumber(phoneNumber);

		if (verification == null) {
			throw new UserNotFoundException(AppConstant.ErrorTypes.USER_DOES_NOT_EXIST_ERROR,
					AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
					AppConstant.ErrorMessages.USER_DOES_NOT_EXIST_MESSAGE);

		}

		String originalOtp = verification.getOtp();

		if (!originalOtp.equals(otp)) {
			throw new InvalidOtpException(AppConstant.ErrorTypes.OTP_MISMATCH_ERROR,
					AppConstant.ErrorCodes.OTP_MISMATCH_ERROR_CODE,
					AppConstant.ErrorMessages.OTP_MISMATCH_ERROR_MESSAGE);
		}

		if (verification.getUpdated() != null) {
			Date updatedAt = verification.getUpdated();
			long updatedMins = updatedAt.getTime() / (60 * 1000);
			Date date = new Date();
			long time = date.getTime();
			Timestamp timestamp = new Timestamp(time);
			long currentMins = timestamp.getTime() / (60 * 1000);

			long diff = currentMins - updatedMins;

			if (diff >= 30) {
				throw new InvalidOtpException(AppConstant.ErrorTypes.OTP_MISMATCH_ERROR,
						AppConstant.ErrorCodes.OTP_MISMATCH_ERROR_CODE,
						AppConstant.ErrorMessages.OTP_EXPIRED_ERROR_MESSAGE);
			}
		}
		User user = userRepository.findByPhoneNumber(verification.getPhoneNumber());
		SellerOrganisationBranchEntity seller = organisaionService.getSellerOrganisationByUserID(user.getId());
		if (seller.getRegistrationStatus() == null || user.getRegistrationStatus() == null) {
			seller.setRegistrationStatus(RegistrationStatus.STEP1);
			user.setRegistrationStatus(RegistrationStatus.STEP1);
			
		}
		
		if (seller.getRegistrationStatus() == RegistrationStatus.MANUAL  || user.getRegistrationStatus() == RegistrationStatus.MANUAL) {
			seller.setRegistrationStatus(RegistrationStatus.LIVE);
			user.setRegistrationStatus(RegistrationStatus.LIVE);
			
		}
		userRepository.save(user);
		organizationRepository.save(seller);
		
		long sellerId = 0;
		if (seller != null) {
			sellerId = seller.getId();
		}
		return AuthorizationResponse.builder().email(verification.getEmail()).email(user.getEmail())
				.name(user.getName()).userId(user.getId()).primaryPhone(verification.getPhoneNumber())
				.role(user.getRole().getName()).token(accessToken.generateToken(user.getEmail())).sellerId(sellerId)
				.status(user.getRegistrationStatus()).build();
	}

	@Override
	public User findById(Long id) {
		if (id == null) {
			throw new InvalidIdException(AppConstant.ErrorTypes.ID_NULL_EXIST_ERROR,
					AppConstant.ErrorCodes.ID_NULL_ERROR_CODE, AppConstant.ErrorMessages.ID_EMPTY_MESSAGE);
		} else {
			return userRepository.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException(AppConstant.ErrorTypes.USER_DOES_NOT_EXIST_ERROR,
							AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
							AppConstant.ErrorMessages.USER_DOES_NOT_EXIST_MESSAGE));
		}
	}

	@Override
	public CommonSuccessResponse registerFcmToken(FcmTokenRequest fcmTokenRequest) {
		User userEntity = userRepository.findById(fcmTokenRequest.getUserId())
				.orElseThrow(() -> new ResourceNotFoundException(AppConstant.ErrorTypes.USER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
						AppConstant.ErrorMessages.USER_DOES_NOT_EXIST_MESSAGE));

          FcmAuthInfoEntity entity = fcmAuthRepository.findByUserEntity(userEntity.getId());

		if (entity != null) {

			entity.setActive(true);
			entity.setFcmToken(fcmTokenRequest.getDeviceToken());
			entity.setDeviceType(fcmTokenRequest.getDeviceType());
			fcmAuthRepository.save(entity);
		} else {

			FcmAuthInfoEntity fcmEntity = FcmAuthInfoEntity.builder().userId(userEntity.getId())
					.deviceId(fcmTokenRequest.getDeviceId()).deviceType(fcmTokenRequest.getDeviceType())
					.fcmToken(fcmTokenRequest.getDeviceToken()).build();

			fcmAuthRepository.save(fcmEntity);

		}
		return new CommonSuccessResponse(true);

	}

	@Override
	public CommonSuccessResponse toCheckRegisteredUser(String phoneNumber) {

		CommonSuccessResponse response = new CommonSuccessResponse(false);

		Boolean check = userRepository.existsByPhoneNumber(phoneNumber);

		if (Boolean.TRUE.equals(check)) {
			response.setSuccess(true);
		}
		return response;
	}

	@Override
	public CommonSuccessResponse logout(Long userId ) {
		CommonSuccessResponse response = new CommonSuccessResponse(false);
		User account = userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException(AppConstant.ErrorTypes.USER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
						AppConstant.ErrorMessages.USER_DOES_NOT_EXIST_MESSAGE));

		try {
			FcmAuthInfoEntity entity = fcmAuthRepository.findByUserEntity(account.getId());

			entity.setActive(false);

			fcmAuthRepository.save(entity);

			response.setSuccess(true);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return response;
	}

	@Override
	public CommonSuccessResponse checkRegisteredUserByMail(String email) {
		CommonSuccessResponse response = new CommonSuccessResponse(false);

		Boolean check = userRepository.existsByEmail(email);

		if (Boolean.TRUE.equals(check)) {
			response.setSuccess(true);
		}
		return response;
	}
}