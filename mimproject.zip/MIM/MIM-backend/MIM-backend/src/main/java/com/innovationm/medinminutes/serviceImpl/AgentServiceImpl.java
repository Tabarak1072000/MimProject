package com.innovationm.medinminutes.serviceImpl;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.innovationm.medinminutes.entity.RoleEntity;
import com.innovationm.medinminutes.entity.User;
import com.innovationm.medinminutes.enums.RegistrationStatus;
import com.innovationm.medinminutes.exception.ResourceNotFoundException;
import com.innovationm.medinminutes.exception.UserAlreadyExistException;
import com.innovationm.medinminutes.exception.UserNotFoundException;
import com.innovationm.medinminutes.repository.OtpVerificationRepository;
import com.innovationm.medinminutes.repository.UserRepository;
import com.innovationm.medinminutes.request.AddAgentRequest;
import com.innovationm.medinminutes.request.ChangeAgentStatusRequest;
import com.innovationm.medinminutes.request.GetAgentListRequest;
import com.innovationm.medinminutes.request.UpdateAgentRequest;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.response.AddUserResponse;
import com.innovationm.medinminutes.response.AgentListResponse;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.GetAgentResponse;
import com.innovationm.medinminutes.service.AgentService;
import com.innovationm.medinminutes.service.RoleService;
import com.innovationm.medinminutes.service.UserService;

@Service
public class AgentServiceImpl implements AgentService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	UserService userService;

	@Autowired
	OTPService otpService;

	@Autowired
	OtpVerificationRepository otpVerificationRepository;

	@Autowired
	Base64PasswordService encoder;

	@Autowired
	private RoleService roleService;

	@Autowired
	private UserServiceImpl userServiceImpl;

	@Override
	public AddUserResponse addAgent(AddAgentRequest addAgentRequest) {

		RoleEntity agentRole = roleService.findById((long) 2);

		Boolean existUser = userRepository.existsByEmail(addAgentRequest.getEmail());
		if (Boolean.TRUE.equals(existUser)) {
			throw new UserAlreadyExistException(AppConstant.ErrorTypes.USER_ALREADY_EXIST_ERROR,
					AppConstant.ErrorCodes.USER_ALREADY_EXIST_ERROR_CODE,
					AppConstant.ErrorMessages.EMAIL_ALREADY_EXIST_MESSAGE);
		}

		List<User> existUser1 = userRepository.findByPhone(addAgentRequest.getPhoneNumber()	);

		if (existUser1.size()>0) {
			throw new UserAlreadyExistException(AppConstant.ErrorTypes.USER_ALREADY_EXIST_ERROR,
					AppConstant.ErrorCodes.USER_ALREADY_EXIST_ERROR_CODE,
					AppConstant.ErrorMessages.PHONE_NUMBER_ALREADY_EXIST_MESSAGE);
		}

		User user = User.builder().email(addAgentRequest.getEmail())
				.password(encoder.encode(addAgentRequest.getPassword())).role(agentRole).name(addAgentRequest.getName())
				.phoneNumber(addAgentRequest.getPhoneNumber()).startDate(addAgentRequest.getStartDate())
				.endDate(addAgentRequest.getEndDate()).alternatePhoneNumber(addAgentRequest.getAlternatePhoneNumber())
				.registrationStatus(RegistrationStatus.STEP1).status(0).createdAt(new Date()).updatedAt(new Date())
				.build();
		user.setActive(true);
		user.setCreatedAt(new Date());
		user.setCreated(new Date());
		user.setCreatedBy("Admin");
		// user.setUpdatedAt(new Date());

		AddUserResponse response = new AddUserResponse();
		// saving agent info in user table

		int otp = otpService.generateOTP(addAgentRequest.getPassword());

		// otpService.createPhoneOTP(phoneNumber);
		user = userRepository.save(user);
		response.setUserId(user.getId());
		response.setVerficationOtp(otp);
		return response;
	}

	@Override
	public AgentListResponse getAgentList(GetAgentListRequest getAgentListRequest) {
		Pageable page = PageRequest.of(getAgentListRequest.getPageNo(), getAgentListRequest.getPageSize());
		RoleEntity agentRole = roleService.findById((long) 2);

		AgentListResponse response = new AgentListResponse();
		if (getAgentListRequest.getAgentStatus() != null && getAgentListRequest.getAgentName() == null) {
			Boolean status = false;
			if (getAgentListRequest.getAgentStatus().equals("Enable")) {
				status = true;
				Page<User> agentPage = userRepository.findAllByActiveAndRoleOrderByCreatedDesc(status, agentRole, page);
				List<User> agentList = agentPage.getContent();
				response.setAgentList(agentList.stream().map(agent -> convertToAgentListResponse(agent))
						.collect(Collectors.toList()));
				response.setNoOfPagesAsPerPageLimit(agentPage.getTotalPages());
			} else if (getAgentListRequest.getAgentStatus().equals("Disable")) {
				Page<User> agentPage = userRepository.findAllByActiveAndRoleOrderByCreatedDesc(status, agentRole, page);
				List<User> agentList = agentPage.getContent();
				response.setAgentList(agentList.stream().map(agent -> convertToAgentListResponse(agent))
						.collect(Collectors.toList()));
				response.setNoOfPagesAsPerPageLimit(agentPage.getTotalPages());
			} else {
				Page<User> agentPage = userRepository.findAllByRoleOrderByCreatedDesc(agentRole, page);
				List<User> agentList = agentPage.getContent();
				response.setAgentList(agentList.stream().map(agent -> convertToAgentListResponse(agent))
						.collect(Collectors.toList()));
				response.setNoOfPagesAsPerPageLimit(agentPage.getTotalPages());
			}

		} else if (getAgentListRequest.getAgentName() != null && getAgentListRequest.getAgentStatus() != null) {
			Boolean status = false;
			if (getAgentListRequest.getAgentStatus().equals("Enable")) {
				status = true;

				Page<User> agentPage = userRepository.findAllByActiveAndNameContainsAndRoleOrderByCreatedDesc(status,
						getAgentListRequest.getAgentName(), agentRole, page);
				List<User> agentList = agentPage.getContent();
				response.setAgentList(agentList.stream().map(agent -> convertToAgentListResponse(agent))
						.collect(Collectors.toList()));
				response.setNoOfPagesAsPerPageLimit(agentPage.getTotalPages());
			} else if (getAgentListRequest.getAgentStatus().equals("Disable")) {
				Page<User> agentPage = userRepository.findAllByActiveAndNameContainsAndRoleOrderByCreatedDesc(status,
						getAgentListRequest.getAgentName(), agentRole, page);
				List<User> agentList = agentPage.getContent();
				response.setAgentList(agentList.stream().map(agent -> convertToAgentListResponse(agent))
						.collect(Collectors.toList()));
				response.setNoOfPagesAsPerPageLimit(agentPage.getTotalPages());
			} else {
				Page<User> agentPage = userRepository.findAllByNameContainsAndRoleOrderByCreatedDesc(
						getAgentListRequest.getAgentName(), agentRole, page);
				List<User> agentList = agentPage.getContent();
				response.setAgentList(agentList.stream().map(agent -> convertToAgentListResponse(agent))
						.collect(Collectors.toList()));
				response.setNoOfPagesAsPerPageLimit(agentPage.getTotalPages());
			}

		} else if (getAgentListRequest.getAgentName() != null && getAgentListRequest.getAgentStatus() == null) {
			Page<User> agentPage = userRepository.findAllByNameContainsAndRoleOrderByCreatedDesc(
					getAgentListRequest.getAgentName(), agentRole, page);
			List<User> agentList = agentPage.getContent();
			response.setAgentList(
					agentList.stream().map(agent -> convertToAgentListResponse(agent)).collect(Collectors.toList()));
			response.setNoOfPagesAsPerPageLimit(agentPage.getTotalPages());
		}

		else {
			Page<User> agentPage = userRepository.findAllByRoleOrderByCreatedDesc(agentRole, page);
			List<User> agentList = agentPage.getContent();
			response.setAgentList(
					agentList.stream().map(agent -> convertToAgentListResponse(agent)).collect(Collectors.toList()));
			response.setNoOfPagesAsPerPageLimit(agentPage.getTotalPages());
		}

		return response;

	}

	@Override
	public CommonSuccessResponse updateAgent(UpdateAgentRequest request,String email) {
          
		
		User account = userRepository.findByEmail(email);
		String updatedBy="Admin";
		if(account!=null) {
			 updatedBy=account.getName();
		}
				
		CommonSuccessResponse response = new CommonSuccessResponse(false);
		
		
		User agent = userServiceImpl.findById(request.getAgentId());

		if (request.getName() != null) {
			agent.setName(request.getName());
		}
		if (request.getPhoneNumber() != null) {
			agent.setPhoneNumber(request.getPhoneNumber());
		}

		if (request.getAlternatePhoneNumber() != null) {
			agent.setAlternatePhoneNumber(request.getAlternatePhoneNumber());
		}

		if (request.getEmail() != null) {
			agent.setEmail(request.getEmail());
		}

		if (request.getPassword() != null) {
			agent.setPassword(encoder.encode(request.getPassword()));
		}

		if (request.getStartDate() != null) {
			agent.setStartDate(request.getStartDate());
		}

		if (request.getEndDate() != null) {
			agent.setEndDate(request.getEndDate());
		}

		agent.setUpdatedAt(new Date());
		agent.setUpdatedBy(updatedBy);
		agent.setUpdated(new Date());
		try {
			userRepository.save(agent);
			response.setSuccess(true);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return response;
	}

	public GetAgentResponse convertToAgentListResponse(User user) {
		return GetAgentResponse.builder().email(user.getEmail()).activeStatus(user.getActive())
				.endDate(user.getEndDate()).LMB(user.getUpdatedBy()).startDate(user.getStartDate())
				.password(encoder.decode(user.getPassword())).name(user.getName()).phoneNumber(user.getPhoneNumber())
				.alternateMobileNo(user.getAlternatePhoneNumber()).userId(user.getId()).build();

	}

	@Override
	public CommonSuccessResponse changeStatus(ChangeAgentStatusRequest changeAgentStatusRequest) {
		CommonSuccessResponse response = new CommonSuccessResponse(false);
		User agent = userService.findById(changeAgentStatusRequest.getAgentId());
		if (changeAgentStatusRequest.isStatus()) {
			agent.setActive(true);
		} else {
			agent.setActive(false);
		}
		try {
			userRepository.save(agent);
			response.setSuccess(true);
		} catch (Exception e) {

		}
		return response;
	}

}
