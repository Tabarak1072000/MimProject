package com.innovationm.medinminutes.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class UpdateSellerRequest {

	private Long agentId;
	private Long sellerId;
	private String sellerName;
	private String businessName;
	private String branchName;
	private String managerName;
	private String sellerContact;
	private String address;
	private String city;
	private String pinCode;
	private double latitude;
	private double longitude;
	private double maxdiscount;
	private double minDiscount;
	private String bankAccountNo;
	private String gstNo;
	private String ifscCode;
	private String benefeciaryName;

}
