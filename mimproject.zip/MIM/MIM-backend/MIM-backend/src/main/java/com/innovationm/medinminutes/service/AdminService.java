package com.innovationm.medinminutes.service;

import com.innovationm.medinminutes.request.AddAdminRequest;
import com.innovationm.medinminutes.request.AddSellerRequest;
import com.innovationm.medinminutes.response.AddUserResponse;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.SellerAdminResponse;

public interface AdminService {

	CommonSuccessResponse approveSeller(Long sellerId, boolean accepted);

	AddUserResponse addAdmin(AddAdminRequest addAdminRequest);

	SellerAdminResponse createSellerByAdmin(AddSellerRequest selleRequest, String email);

}
