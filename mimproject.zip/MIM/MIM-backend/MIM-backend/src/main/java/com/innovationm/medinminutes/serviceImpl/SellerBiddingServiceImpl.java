package com.innovationm.medinminutes.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.innovationm.medinminutes.entity.SellerBiddingEntity;
import com.innovationm.medinminutes.exception.InvalidInputException;
import com.innovationm.medinminutes.exception.ResourceNotFoundException;
import com.innovationm.medinminutes.repository.SellerBiddingRepository;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.service.SellerBiddingService;

@Service
public class SellerBiddingServiceImpl implements SellerBiddingService {

	@Autowired
	SellerBiddingRepository sellerBiddingRepo;

	@Override
	public SellerBiddingEntity findSellerBiddingEntityById(long sellerBiddingId) {

		if (sellerBiddingId == 0) {
			throw new InvalidInputException(AppConstant.ErrorTypes.ID_NULL_EXIST_ERROR,
					AppConstant.ErrorCodes.ID_NULL_ERROR_CODE, AppConstant.ErrorMessages.ID_EMPTY_MESSAGE);
		} else {
			return sellerBiddingRepo.findById(sellerBiddingId)
					.orElseThrow(() -> new ResourceNotFoundException(AppConstant.ErrorTypes.ORDER_NOT_EXIST_ERROR,
							AppConstant.ErrorCodes.ORDER_ERROR_CODE,
							AppConstant.ErrorMessages.SELLER_BIDDING_NOT_EXIST_MESSAGE));
		}
	}

}
