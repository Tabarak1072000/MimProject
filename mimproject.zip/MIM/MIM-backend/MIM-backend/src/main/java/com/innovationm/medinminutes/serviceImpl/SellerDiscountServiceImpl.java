package com.innovationm.medinminutes.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.innovationm.medinminutes.entity.SellerDiscountEntity;
import com.innovationm.medinminutes.entity.SellerOrganisationBranchEntity;
import com.innovationm.medinminutes.exception.InvalidInputException;
import com.innovationm.medinminutes.exception.ResourceNotFoundException;
import com.innovationm.medinminutes.repository.SellerDiscountRepository;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.service.SellerDiscountService;

@Service
public class SellerDiscountServiceImpl implements SellerDiscountService {

	@Autowired
	SellerDiscountRepository sellerDiscountRepository;

	@Override
	public SellerDiscountEntity findById(Long id) {
		if (id == null) {
			throw new InvalidInputException(AppConstant.ErrorTypes.ID_NULL_EXIST_ERROR,
					AppConstant.ErrorCodes.ID_NULL_ERROR_CODE, AppConstant.ErrorMessages.ID_EMPTY_MESSAGE);
		} else {
			return sellerDiscountRepository.findById(id).orElseThrow(
					() -> new ResourceNotFoundException(AppConstant.ErrorTypes.SELLER_DISCOUNT_NOT_EXIST_ERROR,
							AppConstant.ErrorCodes.SELLER_DISCOUNT_NOT_EXIST_ERROR_CODE,
							AppConstant.ErrorMessages.SELLER_DISCOUNT_NOT_EXIST_MESSAGE));
		}
	}

	@Override
	public SellerDiscountEntity findBysellerId(SellerOrganisationBranchEntity seller) {

		SellerDiscountEntity sellerDiscount = sellerDiscountRepository.findBySellerId(seller);
		return sellerDiscount;
	}

}
