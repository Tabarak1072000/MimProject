package com.innovationm.medinminutes.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.innovationm.medinminutes.entity.User;
import com.innovationm.medinminutes.exception.PasswordMismatchException;
import com.innovationm.medinminutes.exception.UserNotFoundException;
import com.innovationm.medinminutes.repository.UserRepository;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.response.AuthorizationResponse;
import com.innovationm.medinminutes.service.LoginService;
import com.innovationm.medinminutes.util.JwtTokenUtil;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	UserServiceImpl userServiceImpl;

	@Autowired
	private JwtTokenUtil accessToken;

	@Autowired
	UserRepository userRepository;

	@Autowired
	public OTPService otpService;

	@Autowired
	Base64PasswordService encoder;

	public AuthorizationResponse verifyLogin(String email, String password) {
		User user = userServiceImpl.findByEmail(email);

		if (user == null) {
			throw new UserNotFoundException(AppConstant.ErrorTypes.USER_NOT_EXIST_ERROR,
					AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
					AppConstant.ErrorMessages.EMAIL_CREDENTIALS_MESSAGE);
		}

		if (!user.getActive()) {
			throw new UserNotFoundException(AppConstant.ErrorTypes.PERMISSION_ERROR,
					AppConstant.ErrorCodes.USER_VALIDATION_ERROR_CODE,
					AppConstant.ErrorMessages.PERMISSION_ERROR_MESSAGE);
		}

		String rawPassword = password;

		String decodedPassword = encoder.decode(user.getPassword());
		if (encoder.matches(rawPassword, user.getPassword()) && user.getStatus() == 0) {

			return convertToModel(user);
		} else {
			throw new PasswordMismatchException(AppConstant.ErrorTypes.PASSWORD_MISMATCH_ERROR,
					AppConstant.ErrorCodes.PASSWORD_MISMATCH_ERROR_CODE,
					AppConstant.ErrorMessages.EMAIL_CREDENTIALS_MESSAGE);

		}

	}

	private AuthorizationResponse convertToModel(User user) {

		return AuthorizationResponse.builder().email(user.getEmail()).name(user.getName())
				.primaryPhone(user.getPhoneNumber()).userId(user.getId()).role(user.getRole().getName())
				.token(accessToken.generateToken(user.getEmail())).build();

	}
}
