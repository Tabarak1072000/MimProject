package com.innovationm.medinminutes.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.innovationm.medinminutes.entity.CategoryEntity;
import com.innovationm.medinminutes.entity.InventoryEntity;
import com.innovationm.medinminutes.entity.OrderEntity;
import com.innovationm.medinminutes.entity.OrderMedicineDetailsEntity;
import com.innovationm.medinminutes.entity.User;
import com.innovationm.medinminutes.enums.OrderStatus;
import com.innovationm.medinminutes.exception.AlreadyAddedItemException;
import com.innovationm.medinminutes.exception.InvalidInputException;
import com.innovationm.medinminutes.exception.ResourceNotFoundException;
import com.innovationm.medinminutes.repository.OrderMedicineDetailsRepository;
import com.innovationm.medinminutes.repository.OrderRepository;
import com.innovationm.medinminutes.repository.SellerBiddingRepository;
import com.innovationm.medinminutes.request.AddOrderItemRequest;
import com.innovationm.medinminutes.request.NewItemsRequest;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.GetOrderItemListResponse;
import com.innovationm.medinminutes.response.GetOrderItemResponseList;
import com.innovationm.medinminutes.service.CategoryService;
import com.innovationm.medinminutes.service.InventoryService;
import com.innovationm.medinminutes.service.OrderMedicineDetailsService;
import com.innovationm.medinminutes.service.OrderService;
import com.innovationm.medinminutes.service.UserService;

@Service
public class OrderMedicineDetailsServiceImpl implements OrderMedicineDetailsService {

	@Autowired
	OrderMedicineDetailsRepository orderMedicineDetailsRepository;

	@Autowired
	OrderRepository orderRepository;

	@Autowired
	OrderService orderService;

	@Autowired
	InventoryService inventoryService;

	@Autowired
	UserService userService;

	@Autowired
	CategoryService categoryService;

	@Autowired
	SellerBiddingRepository sellerBiddingRepository;

	@Override
	public CommonSuccessResponse addOrderItems(AddOrderItemRequest addOrderItemRequest) {

		CommonSuccessResponse response = new CommonSuccessResponse(false);

		OrderEntity order = orderService.findOrderById(addOrderItemRequest.getOrderId());

		User agent = userService.findById(addOrderItemRequest.getAgentId());

		List<OrderMedicineDetailsEntity> orderMedicineDetailsEntities = new ArrayList<OrderMedicineDetailsEntity>();

		for (int i = 0; i < addOrderItemRequest.getNewItemsList().size(); i++) {

			NewItemsRequest itemRequest = addOrderItemRequest.getNewItemsList().get(i);

			if (!itemRequest.isNewInventory()) {

				InventoryEntity inventoryEntity = inventoryService.findInventoryById(itemRequest.getInventoryId());

				OrderMedicineDetailsEntity checkOrderItemEntity = orderMedicineDetailsRepository
						.findByOrderIdAndInventoryId(addOrderItemRequest.getOrderId(), itemRequest.getInventoryId());

				if (checkOrderItemEntity != null) {
					throw new AlreadyAddedItemException(AppConstant.ErrorTypes.ALREADY_ADDED_ITEM_ERROR,
							AppConstant.ErrorCodes.ALREADY_ADDED_ITEM_ERROR_CODE,
							AppConstant.ErrorMessages.ALREADY_ADDED_ITEM_ERROR_MESSAGE);

				} else {

					OrderMedicineDetailsEntity orderItemEntity = OrderMedicineDetailsEntity.builder()
							.quantityRequired(itemRequest.getQuantityRequired()).mrp(inventoryEntity.getMrp())
							.inventory(inventoryEntity).order(order).build();

					orderItemEntity.setActive(true);
					orderItemEntity.setCreated(new Date());
					orderItemEntity.setUpdatedBy(agent.getName());

					orderMedicineDetailsEntities.add(orderItemEntity);
				}
			}

			else {

				InventoryEntity newInventoryEntity = convertToInventoryEntity(itemRequest, agent);
				OrderMedicineDetailsEntity checkOrderItemEntity = orderMedicineDetailsRepository
						.findByOrderIdAndInventoryId(addOrderItemRequest.getOrderId(), itemRequest.getInventoryId());

				if (checkOrderItemEntity != null) {
					throw new AlreadyAddedItemException(AppConstant.ErrorTypes.ALREADY_ADDED_ITEM_ERROR,
							AppConstant.ErrorCodes.ALREADY_ADDED_ITEM_ERROR_CODE,
							AppConstant.ErrorMessages.ALREADY_ADDED_ITEM_ERROR_MESSAGE);

				} else {
					OrderMedicineDetailsEntity orderItemEntity = OrderMedicineDetailsEntity.builder()
							.mrp(itemRequest.getMrp()).quantityRequired(itemRequest.getQuantityRequired())
							.inventory(newInventoryEntity).order(order).build();

					orderItemEntity.setActive(true);
					orderItemEntity.setCreated(new Date());
					orderItemEntity.setUpdatedBy(agent.getName());
					orderItemEntity.setCreatedBy(agent.getName());
					orderMedicineDetailsEntities.add(orderItemEntity);
				}
			}

		}
		try {
			orderMedicineDetailsRepository.saveAll(orderMedicineDetailsEntities);
			order.setOrderStatus(OrderStatus.ORDERSET);
			orderRepository.save(order);
			response.setSuccess(true);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return response;
	}

	public InventoryEntity convertToInventoryEntity(NewItemsRequest request, User agent) {

		Boolean preSubscription = null;
		if (request.getPrescription() != null) {
			if (request.getPrescription().equals("Yes")) {
				preSubscription = true;
			} else {
				preSubscription = false;
			}
		}
		StringBuilder updatedByString = new StringBuilder("");
		updatedByString.append("By " + agent.getName() + " on ");
		updatedByString.append(new Date().toLocaleString());
		String updatedBy = updatedByString.toString();
		CategoryEntity categoryEntity = categoryService.findCategoryById((long) 1);
		InventoryEntity inventoryEntity = InventoryEntity.builder().categoryId(categoryEntity)
				.composition(request.getComposition()).compositionUpdateBy(updatedBy).form(request.getForm())
				.formUpdateBy(updatedBy).manufacture(request.getManufacture()).manufactureUpdateBy(updatedBy)
				.mrp(request.getMrp()).mrpUpdateBy(updatedBy).name(request.getName()).nameUpdateBy(updatedBy)
				.pack(request.getPack()).packUpdateBy(updatedBy).prescription(preSubscription).units(request.getUnits())
				.prescriptionUpdateBy(updatedBy).qtyPerPack(request.getQtyPerPack()).qtyPerPackUpdateBy(updatedBy)
				.type(request.getType()).typeUpdateBy(updatedBy).build();

		inventoryEntity.setActive(true);
		inventoryEntity.setCreated(new Date());
		inventoryEntity.setCreatedBy(agent.getName());
		inventoryEntity.setUpdatedBy(agent.getName());

		return inventoryEntity;
	}

	@Override
	public GetOrderItemResponseList getOrderItemList(Long id, int pageNo, int pageLimit) {

		Pageable page = PageRequest.of(pageNo, pageLimit);

		GetOrderItemResponseList response = new GetOrderItemResponseList();
		OrderEntity order = orderService.findOrderById(id);
		Page<OrderMedicineDetailsEntity> orderItemPage = orderMedicineDetailsRepository
				.findByOrderAndActiveOrderByIdDesc(order, true, page);
		List<OrderMedicineDetailsEntity> orderItemList = orderItemPage.getContent();
		response.setOrderItem(
				orderItemList.stream().map(item -> convertToItemResponse(item)).collect(Collectors.toList()));
		response.setNoOfPagesAsPerPageLimit(orderItemPage.getTotalPages());

		return response;
	}

	public GetOrderItemListResponse convertToItemResponse(OrderMedicineDetailsEntity orderMedicineDetailsEntity) {

		InventoryEntity inventory = orderMedicineDetailsEntity.getInventory();

		String subscription = null;
		if (inventory.getPrescription() == Boolean.TRUE) {
			subscription = "Yes";
		} else {
			subscription = "No";
		}
		return GetOrderItemListResponse.builder().orderId(orderMedicineDetailsEntity.getOrder().getId())
				.orderMedicineId(orderMedicineDetailsEntity.getId()).composition(inventory.getComposition())
				.form(inventory.getForm()).inventoryId(inventory.getId()).manufacture(inventory.getManufacture())
				.mrp(inventory.getMrp()).name(inventory.getName()).pack(inventory.getPack()).prescription(subscription)
				.qtyPerPack(inventory.getQtyPerPack())
				.quantityRequired(orderMedicineDetailsEntity.getQuantityRequired()).type(inventory.getType())
				.units(inventory.getUnits()).build();

	}

	@Override
	public GetOrderItemResponseList getOrderItemListToBid(Long id, int pageNo, int pageLimit) {

		Pageable page = PageRequest.of(pageNo, pageLimit);

		GetOrderItemResponseList response = new GetOrderItemResponseList();
		OrderEntity order = orderService.findOrderById(id);
		Page<OrderMedicineDetailsEntity> orderItemPage = orderMedicineDetailsRepository
				.findByOrderAndActiveOrderByIdDesc(order, true, page);
		List<OrderMedicineDetailsEntity> orderItemList = orderItemPage.getContent();
		response.setOrderItem(orderItemList.stream().map(item -> convertToItemResponseToBid(item))
				.filter(getOrderItemListResponse -> getOrderItemListResponse.getQuantityRequired() > 0)
				.collect(Collectors.toList()));
		response.setNoOfPagesAsPerPageLimit(orderItemPage.getTotalPages());

		return response;
	}

	public GetOrderItemListResponse convertToItemResponseToBid(OrderMedicineDetailsEntity orderMedicineDetailsEntity) {

		InventoryEntity inventory = orderMedicineDetailsEntity.getInventory();

		String subscription = null;
		if (inventory.getPrescription() == Boolean.TRUE) {
			subscription = "Yes";
		} else {
			subscription = "No";
		}
		int quantityRequired = orderMedicineDetailsEntity.getQuantityRequired();
		if (orderMedicineDetailsEntity.getQuantitySellerProvide() != null) {
			quantityRequired = quantityRequired - orderMedicineDetailsEntity.getQuantitySellerProvide();
		}
		System.out.println("Quantity Required"+quantityRequired);
		return GetOrderItemListResponse.builder().orderId(orderMedicineDetailsEntity.getOrder().getId())
				.orderMedicineId(orderMedicineDetailsEntity.getId()).composition(inventory.getComposition())
				.form(inventory.getForm()).inventoryId(inventory.getId()).manufacture(inventory.getManufacture())
				.mrp(inventory.getMrp()).name(inventory.getName()).pack(inventory.getPack()).prescription(subscription)
				.qtyPerPack(inventory.getQtyPerPack()).quantityRequired(quantityRequired).type(inventory.getType())
				.units(inventory.getUnits()).build();

	}

	@Override
	public OrderMedicineDetailsEntity findOrderMedicineDetailsById(Long id) {
		if (id == null) {
			throw new InvalidInputException(AppConstant.ErrorTypes.ID_NULL_EXIST_ERROR,
					AppConstant.ErrorCodes.ID_NULL_ERROR_CODE, AppConstant.ErrorMessages.ID_EMPTY_MESSAGE);
		} else {
			return orderMedicineDetailsRepository.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException(AppConstant.ErrorTypes.ORDER_ITEM_NOT_EXIST_ERROR,
							AppConstant.ErrorCodes.ORDER_ERROR_CODE,
							AppConstant.ErrorMessages.ORDER_ITEM_NOT_EXIST_MESSAGE));
		}
	}

	@Override
	public CommonSuccessResponse deleteOrderItemById(long id) {
		CommonSuccessResponse response = new CommonSuccessResponse(false);
		OrderMedicineDetailsEntity item = findOrderMedicineDetailsById(id);
		item.setActive(false);
		try {
			orderMedicineDetailsRepository.save(item);
			response.setSuccess(true);
		} catch (Exception e) {
			throw new InvalidInputException(AppConstant.ErrorTypes.FAILED_TO_UPDATE_RESOURCE_ERROR,
					AppConstant.ErrorCodes.INVENTORY_ERROR_CODE, AppConstant.ErrorMessages.INVENTORY_NOT_EXIST_MESSAGE);
		}
		return response;
	}
}
