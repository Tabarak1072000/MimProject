package com.innovationm.medinminutes.enums;

public enum MedicineAvailabilityStatus {

	AVAILABLE,CANNOT,TODAY,TOMORROW
}
