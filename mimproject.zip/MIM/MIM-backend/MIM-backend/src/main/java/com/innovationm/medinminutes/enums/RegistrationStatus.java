package com.innovationm.medinminutes.enums;

public enum RegistrationStatus {

     STEP1,STEP2,VALIDATING,LIVE,APPROVED,REJECTED,All,MANUAL

}
