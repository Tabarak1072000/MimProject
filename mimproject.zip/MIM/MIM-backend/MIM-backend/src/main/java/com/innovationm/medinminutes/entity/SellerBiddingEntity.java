package com.innovationm.medinminutes.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.innovationm.medinminutes.enums.BuzzStatus;
import com.innovationm.medinminutes.enums.SellerStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "seller_bidding")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SellerBiddingEntity extends BaseEntity {

	@Column(name = "ranks")
	private Integer ranks;
	
	@Column(name = "app_status")
	private Boolean appStatus;

	@Enumerated(EnumType.STRING)
	@Column(name = "seller_status", nullable = false, columnDefinition = "ENUM('TOFIND','TOBID','BIDDED','TOPACK','TOPACKDONE','PACKED','SENT','SNOOZED','REJECTED')")
	private SellerStatus sellerStatus;

	@Column(name = "buzz_status", nullable = false, columnDefinition = "ENUM(''TOFIND',BUZZED','REJECTED','SNOOZED')")
	@Enumerated(EnumType.STRING)
	private BuzzStatus buzzStatus;

	private Date buzzTime;
	
	private Date snoozedBuzzTime;

	private double sellerDiscount;

	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.PERSIST }, fetch = FetchType.EAGER)
	@JoinColumn(name = "order_id", nullable = false)
	private OrderEntity order;

	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.PERSIST }, fetch = FetchType.EAGER)
	@JoinColumn(name = "seller_id", nullable = false)
	private SellerOrganisationBranchEntity seller;

}