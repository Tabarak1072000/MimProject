package com.innovationm.medinminutes.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovationm.medinminutes.request.AddOrUpdateInventoryRequest;
import com.innovationm.medinminutes.request.ChangeAgentStatusRequest;
import com.innovationm.medinminutes.request.ChangeInventoryStatusRequest;
import com.innovationm.medinminutes.request.GetInventoriesListRequest;
import com.innovationm.medinminutes.resources.RestMappingConstants;
import com.innovationm.medinminutes.response.BaseApiResponse;
import com.innovationm.medinminutes.response.ResponseBuilder;
import com.innovationm.medinminutes.service.InventoryService;
import com.sun.istack.NotNull;

@RestController
@RequestMapping(path = RestMappingConstants.InventoryInterfaceUri.INVENTORY__BASE_URI)
public class InventoryController {

	// @Autowired
	// private PasswordEncoder passwordEncoder;

	@Autowired
	InventoryService inventoryService;

	@PostMapping(RestMappingConstants.InventoryInterfaceUri.GET_INVENTORIES)
	public ResponseEntity<?> getInventoriesByName(@RequestParam String name) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(inventoryService.findInventoriesByName(name));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);

	}

	@GetMapping(RestMappingConstants.InventoryInterfaceUri.GET_INVENTORIES)
	public ResponseEntity<?> getAllInventoriesName() {

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(inventoryService.findAllInventoriesName());
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);

	}
	
	@GetMapping(RestMappingConstants.InventoryInterfaceUri.GET_INVENTORIES_NAMES)
	public ResponseEntity<?> getAllInventoriesNames(@RequestParam String name) {

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(inventoryService.findAllInventoriesNames(name));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);

	}

	@GetMapping(RestMappingConstants.InventoryInterfaceUri.GET_INVENTORY)
	public ResponseEntity<?> getInventoryById(@RequestParam long inventoryId) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(inventoryService.getInventoryById(inventoryId));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);

	}

	@PostMapping(RestMappingConstants.InventoryInterfaceUri.GET_ALL_INVENTORY)

	public ResponseEntity<?> getAllInventory(@RequestBody GetInventoriesListRequest request) {

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(inventoryService.findAllInventories(request));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);

	}

	@PostMapping(RestMappingConstants.InventoryInterfaceUri.ADD_OR_EDIT_INVENTORY)
	public ResponseEntity<?> addOrUpdateInventory(@RequestBody AddOrUpdateInventoryRequest request) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(inventoryService.addOrUpdateInventory(request));  
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);

	}

	
	@PutMapping(RestMappingConstants.InventoryInterfaceUri.ENABLE_DISABLE_INVENTORY)
	public ResponseEntity<?> changeInventoryStatus(@RequestBody ChangeInventoryStatusRequest  request) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(inventoryService.changeInventoryStatus(request));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}
}
