package com.innovationm.medinminutes.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovationm.medinminutes.request.DiscountRequest;
import com.innovationm.medinminutes.request.GetSellerListRequest;
import com.innovationm.medinminutes.request.OrganisationSignUpRequest;
import com.innovationm.medinminutes.request.UpdateSellerRequest;
import com.innovationm.medinminutes.resources.RestMappingConstants;
import com.innovationm.medinminutes.response.BaseApiResponse;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.ResponseBuilder;
import com.innovationm.medinminutes.response.SellerDetailListResponse;
import com.innovationm.medinminutes.response.SellerDetailResponse;
import com.innovationm.medinminutes.response.SellerDiscountResponse;
import com.innovationm.medinminutes.response.SellerProfileResponse;
import com.innovationm.medinminutes.service.OrganisationService;

@RestController
@CrossOrigin
@RequestMapping(path = RestMappingConstants.SellerInterfaceUri.SELLER__BASE_URI)
public class OrganisationController {

	@Autowired
	OrganisationService organisationService;

	@PostMapping(RestMappingConstants.SellerInterfaceUri.SELLER_ORGANISATION_ADD_URI)
	public ResponseEntity<BaseApiResponse> createOrganisation(
			@RequestBody OrganisationSignUpRequest organisationSignUpRequest, HttpServletRequest request,
			HttpServletResponse response) {

		SellerProfileResponse commonSuccessResponse = organisationService.createOrganisation(organisationSignUpRequest);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@GetMapping(RestMappingConstants.SellerInterfaceUri.GET_SELLER_DETAILS)
	public ResponseEntity<BaseApiResponse> getSellerDetail(@RequestParam(name = "sellerId") Long sellerId,
			HttpServletRequest request, HttpServletResponse response) {

		SellerDetailResponse commonSuccessResponse = organisationService.getSellerDetail(sellerId);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@PostMapping(RestMappingConstants.SellerInterfaceUri.GET_SELLER_LIST)
	public ResponseEntity<BaseApiResponse> getSellerList(@RequestBody GetSellerListRequest getSellerListRequest,
			HttpServletRequest request, HttpServletResponse response) {

		SellerDetailListResponse commonSuccessResponse = organisationService.getSellerList(getSellerListRequest);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@PostMapping(RestMappingConstants.SellerInterfaceUri.ADD_SELLER_DISCOUNT)
	public ResponseEntity<BaseApiResponse> sellerDiscount(@RequestBody DiscountRequest discount,
			HttpServletRequest request, HttpServletResponse response) {

		SellerDiscountResponse commonSuccessResponse = organisationService.sellerDiscount(discount);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}
	
	@PutMapping(RestMappingConstants.SellerInterfaceUri.UPDATE_SELLER)
	public ResponseEntity<BaseApiResponse> updateSeller(@RequestBody UpdateSellerRequest updateSellerRequest,
			HttpServletRequest request, HttpServletResponse response) {

		CommonSuccessResponse commonSuccessResponse = organisationService.updateSeller(updateSellerRequest);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

}
