package com.innovationm.medinminutes.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Getter;
import lombok.Setter;

@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
@Setter
@Getter
public class BaseEntity {

	@Column(name = "id", updatable = false, insertable = false, nullable = false)
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "created", nullable = false, updatable = false)
	@Temporal(value = TemporalType.TIMESTAMP)
	@CreationTimestamp
	private Date created;

	@Column(name = "updated", updatable = true)
	@Temporal(value = TemporalType.TIMESTAMP)
	@LastModifiedDate
	private Date updated;

	@Column(name = "created_by", updatable = false, length = 25)
	@CreatedBy
	private String createdBy;

	@Column(name = "updated_by", updatable = true, length = 25)
	@LastModifiedBy
	private String updatedBy;

	@Column(name = "active", columnDefinition = "BOOLEAN")
	private Boolean active = true;
}
