package com.innovationm.medinminutes.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.innovationm.medinminutes.enums.RegistrationStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "user")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class User extends BaseEntity {

	@Column
	private String name;

	@Column
	private String email;

	@Column
	private String phoneNumber;
	
	@Column
	private String alternatePhoneNumber;

	@Column
	private String password;

	@OneToOne
	private RoleEntity role;

	@Column(updatable = false)
	@CreationTimestamp
	private Date createdAt;

	@Column
	@UpdateTimestamp
	private Date updatedAt;
	
	@Column(nullable = true)
	private Date startDate;
	
	@Column(nullable = true)
	private Date endDate;

	@Column
	private int status;
	

	@Column(name="registration_status",updatable = true, columnDefinition = "enum ('STEP1 ','STEP2','VALIDATING','LIVE','APPROVED','REJECTED','MANUAL') default 'STEP1'")
	@Enumerated(EnumType.STRING)
	private RegistrationStatus registrationStatus;

}
