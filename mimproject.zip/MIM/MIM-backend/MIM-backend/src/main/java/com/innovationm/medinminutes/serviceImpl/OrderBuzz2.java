package com.innovationm.medinminutes.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.innovationm.medinminutes.entity.OrderEntity;
import com.innovationm.medinminutes.enums.AutoBuzzStatus;
import com.innovationm.medinminutes.repository.OrderRepository;

@Service
public class OrderBuzz2 {

	@Autowired
	OrderRepository orderRepository;
	
	@Autowired
	OrderBuzz1 orderBuzz1;
	
	@Transactional(propagation= Propagation.REQUIRES_NEW)
	public void updateBuzzStatus(Long orderId) {
		OrderEntity orderEntity =orderBuzz1.findOrderDetails(orderId);
		orderEntity.setAutoBuzzStatus(AutoBuzzStatus.ON);
		orderRepository.save(orderEntity);
	}
	
	@Transactional(propagation= Propagation.REQUIRES_NEW)
	public void updateBuzzStatusOFF(Long orderId) {
		OrderEntity orderEntity =orderBuzz1.findOrderDetails(orderId);
		orderEntity.setAutoBuzzStatus(AutoBuzzStatus.OFF);
		orderRepository.save(orderEntity);
	}
}
