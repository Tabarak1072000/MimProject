package com.innovationm.medinminutes.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class BiddingMedicineDetailsResponse {
        
	    private Long inventoryId;
	    
	    private String inventoryName;
	
	    private Integer quantitySellerProvide;
		
		private double discount ;
		
		private double sellerPrice;
		
		private Boolean isToBePacked;
		
		private Boolean havingSubstitute;
		
		private Integer avlQuantity;
		
		private Integer totalSubs;
		
		private List<String> substituteName;
		
		 
		
		
}
