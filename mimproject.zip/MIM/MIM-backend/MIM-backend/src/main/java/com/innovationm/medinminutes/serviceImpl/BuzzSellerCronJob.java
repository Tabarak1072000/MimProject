package com.innovationm.medinminutes.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.innovationm.medinminutes.entity.OrderEntity;
import com.innovationm.medinminutes.entity.SellerBiddingEntity;
import com.innovationm.medinminutes.enums.BuzzStatus;
import com.innovationm.medinminutes.enums.SellerStatus;
import com.innovationm.medinminutes.repository.SellerBiddingRepository;
import com.innovationm.medinminutes.service.OrderService;
import com.innovationm.medinminutes.service.SellerBiddingService;

@Service
public class BuzzSellerCronJob {

	@Autowired
	SellerBiddingRepository sellerBiddingRepository;

	@Autowired
	SellerBiddingService sellerBiddingService;

	@Autowired
	NotificationService notificationService;

	@Autowired
	OrderService orderService;

//	@Scheduled(cron = "0/01 * * * * ?")
	public void cronJobSch() {

		Logger logger = Logger.getLogger(BuzzSellerCronJob.class);

		try {

			List<SellerBiddingEntity> sellerBiddingEntities = sellerBiddingRepository
					.findAllByBuzzStatusAndSnoozedBuzzTimeLessThan(BuzzStatus.SNOOZED, new Date());

			logger.warn("::::::::started push notification::::::::");

			if (!sellerBiddingEntities.isEmpty()) {
				for (int i = 0; i < sellerBiddingEntities.size(); i++) {

					SellerBiddingEntity sellerBiddingEntity = sellerBiddingEntities.get(i);
					OrderEntity order = orderService.findOrderById(sellerBiddingEntities.get(i).getOrder().getId());

					if (sellerBiddingEntity.getSellerStatus().equals(SellerStatus.TOPACK)) {
						logger.warn(":#:#:#:#:#:#:#:#:#Sending TOPACK Notification to :- Seller Bidding ID"
								+ sellerBiddingEntity.getId() + "#:#:#:#:#:#:#:#:#:");

						sellerBiddingEntity.setBuzzStatus(BuzzStatus.BUZZED);
						sellerBiddingEntity.setUpdated(new Date());
						sellerBiddingEntity.setBuzzTime(new Date());
						sellerBiddingEntity.setSnoozedBuzzTime(new Date());
						sellerBiddingRepository.save(sellerBiddingEntity);
						notificationService.sendToPackAndPackedNotificationToSeller(sellerBiddingEntity,
								SellerStatus.TOPACK);
						logger.warn(":#:#:#:#: NOTIFICATION SEND :#:#:#:#:#");

						

						logger.warn(":#:#:#:#: SELLER BIDDING UPDATED SEND :#:#:#:#:#");

					}
					if (sellerBiddingEntity.getSellerStatus().equals(SellerStatus.PACKED)) {

						logger.warn(":#:#:#:#:#:#:#:#:#Sending PACKED Notification to :- Seller Bidding ID"
								+ sellerBiddingEntity.getId() + "#:#:#:#:#:#:#:#:#:");

						sellerBiddingEntity.setBuzzStatus(BuzzStatus.BUZZED);
						sellerBiddingEntity.setUpdated(new Date());
						sellerBiddingEntity.setBuzzTime(new Date());
						sellerBiddingEntity.setSnoozedBuzzTime(new Date());
						sellerBiddingRepository.save(sellerBiddingEntity);

						notificationService.sendToPackAndPackedNotificationToSeller(sellerBiddingEntity,
								SellerStatus.PACKED);
						logger.warn(":#:#:#:#: NOTIFICATION SEND :#:#:#:#:#");

						
						logger.warn(":#:#:#:#: SELLER BIDDING UPDATED SEND :#:#:#:#:#");

					}
					if (sellerBiddingEntity.getSellerStatus().equals(SellerStatus.TOBID)) {

						logger.warn(":#:#:#:#:#:#:#:#:#Sending" + sellerBiddingEntity.getSellerStatus()
								+ " Notification to :- Seller Bidding ID" + sellerBiddingEntity.getId()
								+ "#:#:#:#:#:#:#:#:#:");

						sellerBiddingEntity.setBuzzStatus(BuzzStatus.BUZZED);
						sellerBiddingEntity.setUpdated(new Date());
						sellerBiddingEntity.setBuzzTime(new Date());
						sellerBiddingEntity.setSnoozedBuzzTime(new Date());
						
						sellerBiddingRepository.save(sellerBiddingEntity);
						
						notificationService.convertToPushNotification(sellerBiddingEntity.getId(), order);
						logger.warn(":#:#:#:#: NOTIFICATION SEND :#:#:#:#:#");

						

						logger.warn(":#:#:#:#: SELLER BIDDING UPDATED SEND :#:#:#:#:#");

					}
				}
			}

			logger.warn("::::::::::::::::::::::end push notification::::::::::::::::::::::");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	public List<SellerBiddingEntity> getSnoozedBid() {
		Logger logger = Logger.getLogger(BuzzSellerCronJob.class);

		List<SellerBiddingEntity> sellerBiddingList = new ArrayList<SellerBiddingEntity>();
		try {

			List<SellerBiddingEntity> sellerBiddingEntities = sellerBiddingRepository
					.findAllByBuzzStatusAndSnoozedBuzzTimeLessThan(BuzzStatus.SNOOZED, new Date());
			logger.warn("seller Bidding count:-" + sellerBiddingEntities.size());
			sellerBiddingList = sellerBiddingEntities.stream()
					.filter(sellerBidding -> sellerBidding.getBuzzStatus().equals(BuzzStatus.SNOOZED))
					.collect(Collectors.toList());
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return sellerBiddingList;
	}

}
