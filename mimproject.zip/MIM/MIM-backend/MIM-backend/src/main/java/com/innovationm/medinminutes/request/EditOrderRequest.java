package com.innovationm.medinminutes.request;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class EditOrderRequest {

	private Long orderId;
	private String customerName;
	private String address;
	private String city;
	private String pincode;
	private double latitude;
	private double longitude;
	private Date deliverBy;
	private String courier;
	private Long agentId;
	private String agentName;
	private double discount;
	private double deliveryCharges;
}
