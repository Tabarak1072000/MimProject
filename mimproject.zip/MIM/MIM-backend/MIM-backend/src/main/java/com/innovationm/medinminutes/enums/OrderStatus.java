package com.innovationm.medinminutes.enums;

public enum OrderStatus {

	ORDERSET,ORDERCREATED,ORDERLIVE,ORDERHOLD,ORDERCANCELLED,ORDERCOMPLETED,ORDERALL
	
}
