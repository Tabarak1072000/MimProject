package com.innovationm.medinminutes.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.innovationm.medinminutes.entity.CategoryEntity;

public interface CategoryRepository extends JpaRepository<CategoryEntity, Long>{

}
