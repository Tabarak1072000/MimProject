package com.innovationm.medinminutes.enums;

public enum BuzzStatus {
	TOFIND,BUZZED, REJECTED, SNOOZED
}
