package com.innovationm.medinminutes.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.innovationm.medinminutes.entity.InventoryEntity;
import com.innovationm.medinminutes.entity.OrderMedicineDetailsEntity;
import com.innovationm.medinminutes.exception.ResourceNotFoundException;
import com.innovationm.medinminutes.repository.InventoryRepository;
import com.innovationm.medinminutes.repository.OrderMedicineDetailsRepository;
import com.innovationm.medinminutes.resources.AppConstant;

@Service
public class LTPTotalPrice {

	
	@Autowired
	OrderMedicineDetailsRepository orderMedicineRepo;
	
	@Autowired
	InventoryRepository inventoryRepository;
	
	
	@Transactional(propagation= Propagation.REQUIRES_NEW)
	public double getTotalMRP(Long orderId) {
		List<OrderMedicineDetailsEntity> entity = orderMedicineRepo.findByOrderId(orderId);

		double totalMRP = 0;
		if (entity != null) {
			for (long i = 0; i < entity.size(); i++) {
				InventoryEntity inventory = inventoryRepository.findById(entity.get((int) i).getInventory().getId())
						.orElseThrow(
								() -> new ResourceNotFoundException(AppConstant.ErrorTypes.INVENTORY_NOT_EXIST_ERROR,
										AppConstant.ErrorCodes.INVENTORY_ERROR_CODE,
										AppConstant.ErrorMessages.INVENTORY_NOT_EXIST_MESSAGE));

			//	int quantity = entity.get((int) i).getQuantityRequired();
				int leftTopack = entity.get((int) i).getQuantityRequired();
				if (entity.get((int) i).getQuantitySellerProvide() != null) {
					leftTopack = entity.get((int) i).getQuantityRequired() - entity.get((int) i).getQuantitySellerProvide();
				}

				totalMRP = totalMRP + leftTopack * inventory.getMrp();

			}
		}
		return totalMRP;
	}
}
