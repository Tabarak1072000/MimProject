package com.innovationm.medinminutes.request;

import com.innovationm.medinminutes.enums.SellerStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class GetSellerOrderByStatusRequest {

	private long sellerId;

	private SellerStatus sellerStatus;
}
