package com.innovationm.medinminutes.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class GetOrderItemListResponse {

	private long orderId;

	private long orderMedicineId;

	private long inventoryId;

	private Integer quantityRequired;

	private String name;

	private String form;

	private String pack;

	private Integer qtyPerPack;

	private String units;

	private double mrp;

	private String prescription;

	private String type;

	private String composition;

	private String manufacture;

}
