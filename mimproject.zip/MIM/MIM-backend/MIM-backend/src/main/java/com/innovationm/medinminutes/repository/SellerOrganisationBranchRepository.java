package com.innovationm.medinminutes.repository;

import com.innovationm.medinminutes.entity.SellerOrganisationBranchEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SellerOrganisationBranchRepository extends JpaRepository<SellerOrganisationBranchEntity,Long> {
}
