package com.innovationm.medinminutes.request;
import com.innovationm.medinminutes.enums.DeviceType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FcmTokenRequest {
	
	private String deviceToken;
	private DeviceType deviceType;
	private String deviceId;
	private Long userId;

}
