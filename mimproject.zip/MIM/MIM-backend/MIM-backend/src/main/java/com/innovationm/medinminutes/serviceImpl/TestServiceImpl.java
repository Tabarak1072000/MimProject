package com.innovationm.medinminutes.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.innovationm.medinminutes.entity.Test;
import com.innovationm.medinminutes.repository.TestRepository;

@Service
public class TestServiceImpl {

	@Autowired
	TestRepository repo;

	public List<Test> getTestData() {
		return repo.findAll();
	}

}
