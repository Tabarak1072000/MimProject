package com.innovationm.medinminutes.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.innovationm.medinminutes.entity.RoleEntity;
import com.innovationm.medinminutes.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	Boolean existsByPhoneNumber(String phoneNumber);

	User getUserByEmail(String email);

	Boolean existsByEmail(String email);

	User findByPhoneNumber(String phoneNumber);

	public Page<User> findAllByRoleOrderByCreatedDesc(RoleEntity role, Pageable pageable);

	List<User> findAllByActive(boolean activeStatus);

	Page<User> findAllByNameContainsAndRoleOrderByCreatedDesc(String name,RoleEntity role,Pageable pageable);
	
	Page<User> findAllByActiveAndRoleOrderByCreatedDesc(boolean activeStatus, RoleEntity role, Pageable pageable);
	
	@Query(value = "SELECT distinct(o.name) from User as o where o.role=:role AND TRIM(o.name) <> '' order by o.name asc")
	List<String> findAllByRole(RoleEntity role);

	Page<User> findAllByActiveAndNameContainsAndRoleOrderByCreatedDesc(Boolean status, String agentName,
			RoleEntity role, Pageable page);

//	@Query(value = "SELECT o from User as o where o.phoneNumber=:phoneNumber OR o.phoneNumber=:alternateMob OR o.alternatePhoneNumber=:phoneNumber OR o.alternatePhoneNumber=:alternateMob")	
//	List<User> findByPhone(String phoneNumber, String alternateMob);
	
	@Query(value = "SELECT o from User as o where o.phoneNumber=:phoneNumber")	
	List<User> findByPhone(String phoneNumber);

	User findByEmail(String email);

	
}
