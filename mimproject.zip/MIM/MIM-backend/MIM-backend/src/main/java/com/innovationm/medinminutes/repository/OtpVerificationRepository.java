package com.innovationm.medinminutes.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.innovationm.medinminutes.entity.OtpVerificationEntity;

public interface OtpVerificationRepository extends JpaRepository<OtpVerificationEntity, Long>{

	OtpVerificationEntity findByPhoneNumber(String phoneNumber);

}
