package com.innovationm.medinminutes.advice;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.innovationm.medinminutes.exception.AlreadyAddedItemException;
import com.innovationm.medinminutes.exception.BuzzPausedException;
import com.innovationm.medinminutes.exception.ClientOrderIdAlreadyExistException;
import com.innovationm.medinminutes.exception.FailToSendOtpException;
import com.innovationm.medinminutes.exception.FailedToSaveResourceException;
import com.innovationm.medinminutes.exception.InvalidIdException;
import com.innovationm.medinminutes.exception.InvalidInputException;
import com.innovationm.medinminutes.exception.InvalidOtpException;
import com.innovationm.medinminutes.exception.InventoryExistException;
import com.innovationm.medinminutes.exception.LtpOverException;
import com.innovationm.medinminutes.exception.PasswordMismatchException;
import com.innovationm.medinminutes.exception.ResourceNotFoundException;
//github.com/InnovationM-Developer/MIM-backend.git
import com.innovationm.medinminutes.exception.UserAlreadyExistException;
import com.innovationm.medinminutes.exception.UserNotFoundException;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.response.BaseApiResponse;
import com.innovationm.medinminutes.response.ResponseStatus;

@ControllerAdvice
public class UniversalAdviceController extends ResponseEntityExceptionHandler {

	/**
	 * For Handling MethodArgumentNotValidException
	 **/
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		List<FieldError> allBindingErrorsList = ex.getBindingResult().getFieldErrors();
		List<String> allBindingErrorsMessageList = new ArrayList<String>();

		for (FieldError error : allBindingErrorsList) {
			allBindingErrorsMessageList.add(error.getField() + " - " + error.getDefaultMessage());
		}

		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));

		InvalidInputException invalidInputException = new InvalidInputException(
				AppConstant.ErrorTypes.INVALID_INPUT_ERROR, AppConstant.ErrorCodes.INVALID_INPUT_ERROR_CODE,
				allBindingErrorsMessageList.toString());

		baseApiResponse.setResponseData(invalidInputException);

		return new ResponseEntity<Object>(baseApiResponse, HttpStatus.OK);
	}

	/**
	 * For Handling UserAlreadyExistException
	 **/

	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<BaseApiResponse> userNotFoundException(UserNotFoundException userNotFoundException,
			HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(userNotFoundException);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@ExceptionHandler(UserAlreadyExistException.class)
	public ResponseEntity<BaseApiResponse> userAlreadyExistException(
			UserAlreadyExistException userAlreadyExistException, HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(userAlreadyExistException);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@ExceptionHandler(FailToSendOtpException.class)
	public ResponseEntity<BaseApiResponse> failToSendOtpException(FailToSendOtpException failToSendOtpException,
			HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(failToSendOtpException);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@ExceptionHandler(InvalidOtpException.class)
	public ResponseEntity<BaseApiResponse> invalidOtpException(InvalidOtpException invalidOtpException,
			HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(invalidOtpException);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@ExceptionHandler(PasswordMismatchException.class)
	public ResponseEntity<BaseApiResponse> passwordMismatchException(
			PasswordMismatchException passwordMismatchException, HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(passwordMismatchException);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<BaseApiResponse> resourceNotFoundException(
			ResourceNotFoundException resourceNotFoundException, HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(resourceNotFoundException);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@ExceptionHandler(InvalidIdException.class)
	public ResponseEntity<BaseApiResponse> invalidIdException(InvalidIdException invalidIdException,
			HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(invalidIdException);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@ExceptionHandler(FailedToSaveResourceException.class)
	public ResponseEntity<BaseApiResponse> failedToSaveResourceException(
			FailedToSaveResourceException failedToSaveResourceException, HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(failedToSaveResourceException);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@ExceptionHandler(ClientOrderIdAlreadyExistException.class)
	public ResponseEntity<BaseApiResponse> clientOrderIdAlreadyExistException(
			ClientOrderIdAlreadyExistException clientOrderIdAlreadyExistException, HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(clientOrderIdAlreadyExistException);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@ExceptionHandler(InventoryExistException.class)
	public ResponseEntity<BaseApiResponse> inventoryExistException(InventoryExistException inventoryExistException,
			HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(inventoryExistException);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@ExceptionHandler(AlreadyAddedItemException.class)
	public ResponseEntity<BaseApiResponse> alreadyAddedItemException(
			AlreadyAddedItemException alreadyAddedItemException, HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(alreadyAddedItemException);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@ExceptionHandler(BuzzPausedException.class)
	public ResponseEntity<BaseApiResponse> buzzPausedException(BuzzPausedException buzzPausedException,
			HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(buzzPausedException);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}
	
	
	
	@ExceptionHandler(LtpOverException.class)
	public ResponseEntity<BaseApiResponse> ltpOverException(LtpOverException ltpOverException,
			HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(ltpOverException);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}
}
