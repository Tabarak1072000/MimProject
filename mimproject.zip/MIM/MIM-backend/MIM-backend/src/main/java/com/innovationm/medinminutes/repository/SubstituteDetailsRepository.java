package com.innovationm.medinminutes.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.innovationm.medinminutes.entity.OrderMedicineDetailsEntity;
import com.innovationm.medinminutes.entity.SellerBiddingEntity;
import com.innovationm.medinminutes.entity.SubstituteDetailsEntity;

public interface SubstituteDetailsRepository extends JpaRepository<SubstituteDetailsEntity, Long> {

	List<SubstituteDetailsEntity> findByorderMedicineDetailAndSellerBidding(OrderMedicineDetailsEntity orderMedicine,SellerBiddingEntity sellerBiddingEntity);

}
