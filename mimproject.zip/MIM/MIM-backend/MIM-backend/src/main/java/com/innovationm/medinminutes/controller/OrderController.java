package com.innovationm.medinminutes.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovationm.medinminutes.fcm.PushNotificationResponse;
import com.innovationm.medinminutes.request.AddOrderItemRequest;
import com.innovationm.medinminutes.request.BuzzedSellerRequest;
import com.innovationm.medinminutes.request.ChangeAutoBuzzStatusRequest;
import com.innovationm.medinminutes.request.ChangeOrderStatusRequest;
import com.innovationm.medinminutes.request.CreateOrderRequest;
import com.innovationm.medinminutes.request.EditOrderRequest;
import com.innovationm.medinminutes.request.OrderFilterRequest;
import com.innovationm.medinminutes.request.UpdateItemRequest;
import com.innovationm.medinminutes.request.UpdateSellerStatusRequest;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.resources.RestMappingConstants;
import com.innovationm.medinminutes.response.BaseApiResponse;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.GetAgentAndClientNameResponse;
import com.innovationm.medinminutes.response.OrderListResponse;
import com.innovationm.medinminutes.response.PushNotificationListResponse;
import com.innovationm.medinminutes.response.ResponseBuilder;
import com.innovationm.medinminutes.service.InventoryService;
import com.innovationm.medinminutes.service.OrderMedicineDetailsService;
import com.innovationm.medinminutes.service.OrderService;
import com.innovationm.medinminutes.service.SellerOrderService;
import com.sun.istack.NotNull;

@RestController
@CrossOrigin
@RequestMapping(path = RestMappingConstants.OrderInterfaceUri.ORDER_BASE_URI)
public class OrderController {

	@Autowired
	OrderService orderService;

	@Autowired
	InventoryService inventoryService;

	@Autowired
	OrderMedicineDetailsService orderMedicineDetailsService;

	@Autowired
	SellerOrderService sellerOrderService;

	@PostMapping(RestMappingConstants.OrderInterfaceUri.CREATE_ORDER)
	public ResponseEntity<?> createOrder(@RequestBody CreateOrderRequest createOrderRequest, HttpServletRequest request,
			HttpServletResponse response) {

		String email = request.getUserPrincipal().getName();

		System.out.println("email=" + email);
		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(orderService.createOrder(createOrderRequest, email));
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}

	@PutMapping(RestMappingConstants.OrderInterfaceUri.EDIT_ORDER)
	public ResponseEntity<BaseApiResponse> editOrder(@RequestBody EditOrderRequest editOrderRequest) {

		CommonSuccessResponse response = orderService.editOrder(editOrderRequest);
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(response);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}

	@PostMapping(RestMappingConstants.OrderInterfaceUri.GET_ORDER_LIST)
	public ResponseEntity<BaseApiResponse> getOrderList(
			@RequestParam(value = AppConstant.Commons.PAGE_NUMBER) int pageNo,
			@RequestParam(value = AppConstant.Commons.PAGE_LIMIT, required = false) int pageLimit,
			HttpServletRequest httpServletRequest, @RequestParam(required = false) String searchQuery,
			@RequestBody OrderFilterRequest filterRequest) {

		OrderListResponse commonSuccessResponse = orderService.getOrderList(pageNo, pageLimit, searchQuery,
				filterRequest);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}

	@PostMapping(RestMappingConstants.OrderInterfaceUri.ADD_ORDER_ITEMS)
	public ResponseEntity<?> addOrderItems(@RequestBody AddOrderItemRequest addOrderItemRequests) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(orderMedicineDetailsService.addOrderItems(addOrderItemRequests));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);

	}

	@GetMapping(RestMappingConstants.OrderInterfaceUri.GET_ORDER_ITEMS + "/{orderId}")
	public ResponseEntity<?> getOrderItems(@NotNull @PathVariable("orderId") long orderId,
			@RequestParam(value = AppConstant.Commons.PAGE_NUMBER) int pageNo,
			@RequestParam(value = AppConstant.Commons.PAGE_LIMIT, required = false) int pageLimit) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(orderMedicineDetailsService.getOrderItemList(orderId, pageNo, pageLimit));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);

	}

	@GetMapping(RestMappingConstants.OrderInterfaceUri.GET_ORDER_ITEMS_TO_BID + "/{orderId}")
	public ResponseEntity<?> getOrderItemsToBid(@NotNull @PathVariable("orderId") long orderId,
			@RequestParam(value = AppConstant.Commons.PAGE_NUMBER) int pageNo,
			@RequestParam(value = AppConstant.Commons.PAGE_LIMIT, required = false) int pageLimit) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(orderMedicineDetailsService.getOrderItemListToBid(orderId, pageNo, pageLimit));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);

	}

	@PutMapping(RestMappingConstants.OrderInterfaceUri.EDIT_INVENTORY)
	public ResponseEntity<BaseApiResponse> editItem(@RequestBody UpdateItemRequest updateItemRequest) {

		CommonSuccessResponse response = inventoryService.updateInventory(updateItemRequest);
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(response);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}

	@PutMapping(RestMappingConstants.OrderInterfaceUri.DELETE_ORDER_ITEM + "/{itemId}")
	public ResponseEntity<?> deleteOrderItem(@NotNull @PathVariable("itemId") long itemId) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(orderMedicineDetailsService.deleteOrderItemById(itemId));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}

	@GetMapping(RestMappingConstants.OrderInterfaceUri.GET_ORDER_DETAILS_BY_ORDER_ID)
	public ResponseEntity<BaseApiResponse> getOrderDetails(@RequestParam(name = "orderId") Long orderId) {

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(orderService.getOrderDetails(orderId));
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}

	@GetMapping(RestMappingConstants.OrderInterfaceUri.GET_ESTIMATE_BY_ORDER_ID)
	public ResponseEntity<BaseApiResponse> getEstimate(@RequestParam(name = "orderId") Long orderId) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(orderService.getEstimateByOrderId(orderId));
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}

	@PostMapping(RestMappingConstants.OrderInterfaceUri.ASSIGN_ORDER_STATUS)
	public ResponseEntity<BaseApiResponse> changeStatus(@RequestBody ChangeOrderStatusRequest changeOrderStatusRequest,
			HttpServletRequest request, HttpServletResponse response) {

		CommonSuccessResponse commonSuccessResponse = orderService.changeStatus(changeOrderStatusRequest);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@PostMapping(RestMappingConstants.OrderInterfaceUri.BUZZED_SELLER)
	public ResponseEntity<BaseApiResponse> assignSeller(@RequestBody BuzzedSellerRequest buzzedSellerRequest,
			HttpServletRequest request, HttpServletResponse response) {

		PushNotificationListResponse commonSuccessResponse = orderService.assignSeller(buzzedSellerRequest);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@PostMapping(RestMappingConstants.OrderInterfaceUri.UPDATE_SELLER_STATUS)
	public ResponseEntity<BaseApiResponse> updateSellerStatus(
			@RequestBody UpdateSellerStatusRequest updateSellerStatusRequest, HttpServletRequest request,
			HttpServletResponse response) {

//		String accountId= (String) request.getAttribute(AppConstant. Commons.USER_ACCOUNT_ID);
//		
//		System.out.println("accountId"+accountId);

		PushNotificationResponse commonSuccessResponse = orderService.updateSellerStatus(updateSellerStatusRequest);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);

		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@PostMapping(RestMappingConstants.OrderInterfaceUri.CHANGE_AOUTO_BUZZ_STATUS)
	public ResponseEntity<BaseApiResponse> changeAutoBuzzStatus(
			@RequestBody ChangeAutoBuzzStatusRequest changeAutoBuzzStatusRequest) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(orderService.changeAutoBuzzStatus(changeAutoBuzzStatusRequest));
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}

	@GetMapping(RestMappingConstants.OrderInterfaceUri.GET_CLIENTS_AND_AGENT_NAMES)
	public ResponseEntity<BaseApiResponse> getClientAndAgentName() {

		GetAgentAndClientNameResponse response = orderService.getAgentsAndClientsNames();

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(response);

		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@GetMapping(path = RestMappingConstants.OrderInterfaceUri.CHECK_ALREADY_ADDED_ITEMS)
	public ResponseEntity<BaseApiResponse> alreadyAdddedItems(
			@RequestParam(name = "inventoryName") String inventoryName, @RequestParam(name = "orderId") Long orderId,
			@RequestParam(name = "qtyPerPack") Integer qtyPerPack) {

		CommonSuccessResponse commonSuccessResponse = orderService.alreadyAdddedItems(inventoryName, orderId,
				qtyPerPack);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}
}
