package com.innovationm.medinminutes.enums;

public enum SellerStatus {
     TOFIND,TOBID,BIDDED,TOPACK,TOPACKDONE,PACKED,SENT,SNOOZED,REJECTED
}
