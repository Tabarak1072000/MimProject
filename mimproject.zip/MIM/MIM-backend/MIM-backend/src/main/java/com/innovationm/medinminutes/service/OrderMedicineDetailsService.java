package com.innovationm.medinminutes.service;

import com.innovationm.medinminutes.entity.OrderMedicineDetailsEntity;
import com.innovationm.medinminutes.request.AddOrderItemRequest;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.GetOrderItemResponseList;

public interface OrderMedicineDetailsService {

	CommonSuccessResponse addOrderItems(AddOrderItemRequest addOrderItemRequest);

	GetOrderItemResponseList getOrderItemList(Long id,int pageNo,int pageLimit);

	OrderMedicineDetailsEntity findOrderMedicineDetailsById(Long id);

	CommonSuccessResponse deleteOrderItemById(long id);

	GetOrderItemResponseList getOrderItemListToBid(Long id, int pageNo, int pageLimit);

}
