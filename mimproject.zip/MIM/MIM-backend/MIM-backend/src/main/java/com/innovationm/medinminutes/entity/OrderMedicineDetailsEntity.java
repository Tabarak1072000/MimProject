package com.innovationm.medinminutes.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "order_medicine_details")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrderMedicineDetailsEntity extends BaseEntity {

	private Integer quantityRequired;

	private Integer quantitySellerProvide;

	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name = "order_id", nullable = false)
	private OrderEntity order;

	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "inventory_id", nullable = false)
	private InventoryEntity inventory;
	
	private double mrp;

}
