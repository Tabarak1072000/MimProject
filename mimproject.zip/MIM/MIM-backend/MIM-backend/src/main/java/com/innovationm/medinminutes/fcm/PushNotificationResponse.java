package com.innovationm.medinminutes.fcm;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PushNotificationResponse {

	private String multicastId;

	private int numOfSuccessNotification;

	private int numOfFailureNotification;

	private int httpStatusCode;

	List<HashMap<String, String>> results;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date sentDate;

	public String getMulticastId() {
		return multicastId;
	}

	@JsonProperty("multicast_id")
	public void setMulticastId(String multicastId) {
		this.multicastId = multicastId;
	}

	public int getNumOfSuccessNotification() {
		return numOfSuccessNotification;
	}

	@JsonProperty("success")
	public void setNumOfSuccessNotification(int numOfSuccessNotification) {
		this.numOfSuccessNotification = numOfSuccessNotification;
	}

	public int getNumOfFailureNotification() {
		return numOfFailureNotification;
	}

	@JsonProperty("failure")
	public void setNumOfFailureNotification(int numOfFailureNotification) {
		this.numOfFailureNotification = numOfFailureNotification;
	}

	public List<HashMap<String, String>> getResults() {
		return results;
	}

	public void setResults(List<HashMap<String, String>> results) {
		this.results = results;
	}

	public int getHttpStatusCode() {
		return httpStatusCode;
	}

	public void setHttpStatusCode(int httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}

	public Date getSentDate() {
		return sentDate;
	}

	public void setSentDate(Date localDateTime) {
		this.sentDate = localDateTime;
	}

}
