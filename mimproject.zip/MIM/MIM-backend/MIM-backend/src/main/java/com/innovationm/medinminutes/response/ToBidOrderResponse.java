package com.innovationm.medinminutes.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ToBidOrderResponse {

    private Long orderId;
    private String mimOrderId;
    private Long sellerBiddingId;
    private String totalQuantity;
    private Double totalAmount;
    private String customerName;
}
