package com.innovationm.medinminutes.serviceImpl;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.innovationm.medinminutes.entity.CategoryEntity;
import com.innovationm.medinminutes.entity.RoleEntity;
import com.innovationm.medinminutes.entity.SellerDiscountEntity;
import com.innovationm.medinminutes.entity.SellerOrganisationBranchEntity;
import com.innovationm.medinminutes.entity.User;
import com.innovationm.medinminutes.enums.RegistrationStatus;
import com.innovationm.medinminutes.exception.UserAlreadyExistException;
import com.innovationm.medinminutes.exception.UserNotFoundException;
import com.innovationm.medinminutes.repository.CategoryRepository;
import com.innovationm.medinminutes.repository.OrganisationRepository;
import com.innovationm.medinminutes.repository.SellerDiscountRepository;
import com.innovationm.medinminutes.repository.UserRepository;
import com.innovationm.medinminutes.request.AddAdminRequest;
import com.innovationm.medinminutes.request.AddSellerRequest;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.response.AddUserResponse;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.SellerAdminResponse;
import com.innovationm.medinminutes.service.AdminService;
import com.innovationm.medinminutes.service.RoleService;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	OrganisationRepository organisationRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	RoleService roleService;

	@Autowired
	Base64PasswordService encoder;

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	NotificationService notificationService;

	@Autowired
	SellerDiscountRepository sellerDiscountRepository;

	@Autowired
	private UserServiceImpl userServiceImpl;

	@Override
	public AddUserResponse addAdmin(AddAdminRequest addAdminRequest) {

		AddUserResponse response = new AddUserResponse();
		
		if(userRepository.existsByEmail(addAdminRequest.getUsername()))
		{
			throw new UserNotFoundException(AppConstant.ErrorTypes.USER_ALREADY_EXIST_ERROR,
					AppConstant.ErrorCodes.USER_ALREADY_EXIST_ERROR_CODE,
					AppConstant.ErrorMessages.EMAIL_ALREADY_EXIST_MESSAGE);
		}
		
		RoleEntity agentRole = roleService.findById((long) 1);
		User user = User.builder().email(addAdminRequest.getUsername())
				.password(encoder.encode(addAdminRequest.getPassword())).role(agentRole).name(addAdminRequest.getName())
				.phoneNumber(addAdminRequest.getPhoneNumber()).registrationStatus(RegistrationStatus.STEP1).status(0)
				.createdAt(new Date()).updatedAt(new Date()).build();

		try {
			user = userRepository.save(user);
			response.setUserId(user.getId());
		} catch (Exception e) {
			// TODO: handle exception
		}
		return response;
	}

	@Override
	public CommonSuccessResponse approveSeller(Long sellerId, boolean accepted) {

		CommonSuccessResponse response = new CommonSuccessResponse(false);

		SellerOrganisationBranchEntity sellerEntity = organisationRepository.findById(sellerId)

				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.SELLER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.SELLER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.SELLER_DOES_NOT_EXIST_MESSAGE));

		User user = userRepository.findById(sellerEntity.getSellerUserId())

				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.USER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
						AppConstant.ErrorMessages.USER_DOES_NOT_EXIST_MESSAGE));

		sellerEntity.setIsApproved(accepted);
		sellerEntity.setRequestRejectionTime(new Date());
		organisationRepository.save(sellerEntity);
		if (accepted) {
			user.setRegistrationStatus(RegistrationStatus.LIVE);
			sellerEntity.setRegistrationStatus(RegistrationStatus.LIVE);
		} else {
			user.setRegistrationStatus(RegistrationStatus.REJECTED);
			sellerEntity.setRegistrationStatus(RegistrationStatus.REJECTED);
		}

		try {
			userRepository.save(user);
			organisationRepository.save(sellerEntity);
			notificationService.convertToApproveRejectPushNotification(sellerEntity);
			response.setSuccess(true);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return response;
	}

	@Override
	public SellerAdminResponse createSellerByAdmin(AddSellerRequest sellerRequest,String email) {

		User user = userRepository.findByPhoneNumber(sellerRequest.getSellerContact());
		// User agent= userServiceImpl.findById(sellerRequest.getAgentId());
		if (user != null) {
			throw new UserNotFoundException(AppConstant.ErrorTypes.USER_ALREADY_EXIST_ERROR,
					AppConstant.ErrorCodes.USER_ALREADY_EXIST_ERROR_CODE,
					AppConstant.ErrorMessages.PHONE_NUMBER_ALREADY_EXIST_MESSAGE);
		}
		User account = userRepository.findByEmail(email);
		String updatedBy="Admin";
		if(account!=null) {
			 updatedBy=account.getName();
		}

		Optional<CategoryEntity> category = categoryRepository.findById((long) 1);
		RoleEntity agentRole = roleService.findById((long) 1);

		String randomUsername = userServiceImpl.generateRandomPassword();
		String randomPassword = userServiceImpl.generateRandomPassword();

		User user1 = User.builder().name(sellerRequest.getSellerName()).password(encoder.encode(randomPassword))
				.phoneNumber(sellerRequest.getSellerContact()).registrationStatus(RegistrationStatus.MANUAL)
				.email(randomUsername).role(agentRole).build();

		user1 = userRepository.save(user1);

		SellerOrganisationBranchEntity sellerEntity = SellerOrganisationBranchEntity.builder()
				.addressLine1(sellerRequest.getAddress()).bankAccNo(sellerRequest.getBankAccountNo())
				.beneficiaryName(sellerRequest.getBenefeciaryName()).branchName(sellerRequest.getSellerName())
				.businessName(sellerRequest.getBusinessName()).city(sellerRequest.getCity())
				.ifsc(sellerRequest.getIfscCode()).isAgreementAccepted(true).isApproved(true)
				.latitude(sellerRequest.getLatitude()).longitude(sellerRequest.getLongitude())
				.managerName(sellerRequest.getManagerName()).maxdiscount(sellerRequest.getMaxDiscount())
				.pincode(sellerRequest.getPinCode()).registrationStatus(RegistrationStatus.MANUAL)
				.sellerName(sellerRequest.getSellerName()).sellerUserId(user1.getId()).gstNo(sellerRequest.getGstNo())
				.whatsAppNumber(sellerRequest.getSellerContact()).build();

		sellerEntity.setCreatedBy(updatedBy);

		organisationRepository.save(sellerEntity);

		SellerDiscountEntity sellerDiscount = SellerDiscountEntity.builder()
				.discountFrom(sellerRequest.getMinDiscount()).discountTo(sellerRequest.getMaxDiscount())
				.sellerId(sellerEntity).categoryId(category.get()).build();

		sellerDiscount.setActive(true);
		sellerDiscount.setCreated(new Date());
		sellerDiscount.setCreatedBy("Admin");
		// sellerDiscount.setCreatedBy(agent.getName());
		sellerDiscountRepository.save(sellerDiscount);

		return SellerAdminResponse.builder().userName(user1.getEmail()).password(encoder.decode(randomPassword))
				.sellerContact(user1.getPhoneNumber()).sellerId(sellerEntity.getId()).sellerName(user1.getName())
				.registrationStatus(user1.getRegistrationStatus()).build();
	}

}
