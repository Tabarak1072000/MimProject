package com.innovationm.medinminutes.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.innovationm.medinminutes.enums.RegistrationStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Seller_Organisation_Branch")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SellerOrganisationBranchEntity extends BaseEntity {

	@Column(name = "business_name")
	private String businessName;

	@Column(name = "branch_name")
	private String branchName;

	@Column(name = "seller_name")
	private String sellerName;

	@Column(name = "manager_name")
	private String managerName;

	@Column(name = "whatsApp_no")
	private String whatsAppNumber;

	@Column(name = "address_line1")
	private String addressLine1;

	@Column(name = "address_line2")
	private String addressLine2;

	@Column(name = "city")
	private String city;

	@Column(name = "pin_code")
	private String pincode;

	@Column(name = "Is_Agreement_Accepted")
	private Boolean isAgreementAccepted;

	@Column(name = "Is_Approved")
	private Boolean isApproved;

	@Column(name = "Request_Rejection_Time")
	private Date requestRejectionTime;

	@Column(name = "latitude")
	private double latitude;

	@Column(name = "longitude")
	private double longitude;

	@Column(name = "referred_By")
	private String referredBy;

	@Column(name = "max_discount")
	private double maxdiscount;

	@Column(name = "bank_Account_No")
	private String bankAccNo;

	@Column(name = "ifsc_code")
	private String ifsc;

	private String beneficiaryName;
	
	private String gstNo;

	@Column
	private Long sellerUserId;

	@Column(name = "registration_status", updatable = true, columnDefinition = "enum ('STEP1 ','STEP2','VALIDATING','LIVE','APPROVED','REJECTED','MANUAL') default 'STEP1'")
	@Enumerated(EnumType.STRING)
	private RegistrationStatus registrationStatus;

}
