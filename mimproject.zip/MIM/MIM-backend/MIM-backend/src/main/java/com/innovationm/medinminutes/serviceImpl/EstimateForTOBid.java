package com.innovationm.medinminutes.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.innovationm.medinminutes.entity.OrderEntity;
import com.innovationm.medinminutes.entity.OrderMedicineDetailsEntity;
import com.innovationm.medinminutes.repository.OrderMedicineDetailsRepository;
import com.innovationm.medinminutes.request.GetEstimateItemResponse;
import com.innovationm.medinminutes.request.GetEstimateResponse;

@Service
public class EstimateForTOBid {
	
	@Autowired
	OrderMedicineDetailsRepository orderMedicineRepo;
	
	@Autowired
	OrderServiceImpl orderServiceImpl;
	
	@Transactional(propagation= Propagation.REQUIRES_NEW)
	public GetEstimateResponse getEstimateByOrderId(long orderId) {

		double total = 0;

		GetEstimateResponse response = new GetEstimateResponse();
		OrderEntity order = orderServiceImpl.findOrderById(orderId);

		List<OrderMedicineDetailsEntity> itemsDetails = orderMedicineRepo.findByOrderId(orderId);


		List<GetEstimateItemResponse> itemResponse = itemsDetails.stream()
				.map(item -> convertToItemEstimateResponse(item)).collect(Collectors.toList());

		for (GetEstimateItemResponse i : itemResponse) {
			total += i.getTotal();
		}
		double discountValue = total * order.getDiscount() / 100;
		double totalToPay = (total + order.getDeliveryCharges()) - discountValue;
		response.setCity(order.getCity());
		response.setClientName(order.getClientName());
		response.setCustomerName(order.getCustomerName());
		response.setDeliveryCharges(order.getDeliveryCharges());
		response.setItemsValue(total);
		response.setDiscount(order.getDiscount());
		response.setDiscountValue(discountValue);
		response.setItemsEstimate(itemResponse);
		response.setOrderId(order.getMimOrderId());
		response.setTotalToPay(totalToPay);

		return response;
	}
	
	@Transactional(propagation= Propagation.REQUIRES_NEW)

	public GetEstimateItemResponse convertToItemEstimateResponse(OrderMedicineDetailsEntity item) {

		int ltp=item.getQuantityRequired() ;
		if (item.getQuantitySellerProvide() != null) {
			ltp = item.getQuantityRequired() - item.getQuantitySellerProvide();
		}
		double total = ltp * item.getMrp();
		return GetEstimateItemResponse.builder().itemName(item.getInventory().getName())
				.quantity(ltp).rate(item.getMrp()).total(total).build();
	}
}
