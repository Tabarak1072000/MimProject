package com.innovationm.medinminutes.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovationm.medinminutes.request.FcmTokenRequest;
import com.innovationm.medinminutes.resources.RestMappingConstants;
import com.innovationm.medinminutes.response.AuthorizationResponse;
import com.innovationm.medinminutes.response.BaseApiResponse;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.ResponseBuilder;
import com.innovationm.medinminutes.service.UserService;
import com.sun.istack.NotNull;

@RestController
@CrossOrigin
@RequestMapping(path = RestMappingConstants.UserInterfaceUri.USER_BASE_URI)
public class UserController {

	@Autowired
	UserService userService;

	@PostMapping(RestMappingConstants.UserInterfaceUri.USER_SELLER_ADD_URI + "/{phoneNumber}")
	public ResponseEntity<?> addSeller(@NotNull @PathVariable("phoneNumber") String phoneNumber) {

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(userService.addSeller(phoneNumber));

		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}

//	@PostMapping(RestMappingConstants.UserInterfaceUri.USER_AGENT_ADD_URI)
//	public ResponseEntity<?> addAgent(@RequestBody AddAgentRequest addAgentRequest) {
//
//		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(userService.addAgent(addAgentRequest));
//
//		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
//	}

	@PostMapping(RestMappingConstants.UserInterfaceUri.VERIFY_USER)
	public ResponseEntity<BaseApiResponse> verifySeller(@RequestParam(name = "phoneNumber") String phoneNumber,
			@RequestParam(name = "OTP") String otp, HttpServletRequest httpServletRequest) {

		AuthorizationResponse response = userService.verifySeller(phoneNumber, otp);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(response);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	@PostMapping(path = RestMappingConstants.UserInterfaceUri.REGISTER_FCM_TOKEN)
	public ResponseEntity<BaseApiResponse> registerFcmToken(@RequestBody FcmTokenRequest fcmTokenRequest,
			HttpServletResponse response, HttpServletRequest httpServletRequest) {

		// Long accountId=(Long) httpServletRequest.getAttribute(AppConstants.
		// Common.USER_ACCOUNT_ID);
		CommonSuccessResponse commonSuccessResponse = userService.registerFcmToken(fcmTokenRequest);

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.CREATED);

	}
	
	@GetMapping(path = RestMappingConstants.UserInterfaceUri.TO_CHECK_REGISTERED_SELLER)
	public ResponseEntity<BaseApiResponse> toCheckRegisteredUser (
			 @RequestParam (name="phoneNumber") String phoneNumber){
		
		
		CommonSuccessResponse commonSuccessResponse = userService.toCheckRegisteredUser(phoneNumber);
		
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}
	
	@GetMapping(path = RestMappingConstants.UserInterfaceUri.CHECK_REGISTERED_USER_BY_EMAIL)
	public ResponseEntity<BaseApiResponse> checkRegisteredUser (
			 @RequestParam (name="email") String email){
		
		
		CommonSuccessResponse commonSuccessResponse = userService.checkRegisteredUserByMail(email);
		
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(commonSuccessResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);

	}
	
	@PostMapping(path = RestMappingConstants.UserInterfaceUri.LOGOUT)
	public ResponseEntity<?> logout (
			 @RequestParam Long userId 
			) {	
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(userService.logout(userId));

		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

}
