package com.innovationm.medinminutes.serviceImpl;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.innovationm.medinminutes.entity.CategoryEntity;
import com.innovationm.medinminutes.entity.SellerDiscountEntity;
import com.innovationm.medinminutes.entity.SellerOrganisationBranchEntity;
import com.innovationm.medinminutes.entity.User;
import com.innovationm.medinminutes.enums.RegistrationStatus;
import com.innovationm.medinminutes.exception.FailedToSaveResourceException;
import com.innovationm.medinminutes.exception.InvalidIdException;
import com.innovationm.medinminutes.exception.InvalidInputException;
import com.innovationm.medinminutes.exception.ResourceNotFoundException;
import com.innovationm.medinminutes.exception.UserNotFoundException;
import com.innovationm.medinminutes.repository.CategoryRepository;
import com.innovationm.medinminutes.repository.OrganisationRepository;
import com.innovationm.medinminutes.repository.SellerDiscountRepository;
import com.innovationm.medinminutes.repository.UserRepository;
import com.innovationm.medinminutes.request.DiscountRequest;
import com.innovationm.medinminutes.request.GetSellerListRequest;
import com.innovationm.medinminutes.request.OrganisationSignUpRequest;
import com.innovationm.medinminutes.request.UpdateSellerRequest;
import com.innovationm.medinminutes.resources.AppConstant;
import com.innovationm.medinminutes.response.CommonSuccessResponse;
import com.innovationm.medinminutes.response.SellerDetailListResponse;
import com.innovationm.medinminutes.response.SellerDetailResponse;
import com.innovationm.medinminutes.response.SellerDiscountResponse;
import com.innovationm.medinminutes.response.SellerProfileResponse;
import com.innovationm.medinminutes.service.OrganisationService;
import com.innovationm.medinminutes.service.SellerDiscountService;
import com.innovationm.medinminutes.service.UserService;

@Service
public class OrganisationServiceImpl implements OrganisationService {

	@Autowired
	OrganisationRepository organisationRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	SellerDiscountRepository sellerDiscountRepository;

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	UserService userService;

	@Autowired
	SellerDiscountService sellerDiscountService;

	@Override
	public SellerProfileResponse createOrganisation(OrganisationSignUpRequest organisationSignUpRequest) {

		SellerOrganisationBranchEntity seller = organisationRepository.findById(organisationSignUpRequest.getSellerId())
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.SELLER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.SELLER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.SELLER_DOES_NOT_EXIST_MESSAGE));
		
		if(seller.getRegistrationStatus().ordinal()>=RegistrationStatus.STEP2.ordinal())
		{
			throw new FailedToSaveResourceException(AppConstant.ErrorTypes.SELLER_ALREADY_CREATED_ERROR,
					AppConstant.ErrorCodes.ALREADY_CREATED_ERROR_CODE,
					AppConstant.ErrorMessages.SELLER_ORGANIZATION_ALRADY_CREATED_MESSAGE);
		}
		
		User user = userRepository.findById(organisationSignUpRequest.getSellerUserId())
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.USER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
						AppConstant.ErrorMessages.USER_DOES_NOT_EXIST_MESSAGE));

		SellerOrganisationBranchEntity sellerEntity = SellerOrganisationBranchEntity.builder()
				.branchName(organisationSignUpRequest.getBranchName())
				.businessName(organisationSignUpRequest.getBusinessName()).city(organisationSignUpRequest.getCity())
				.isAgreementAccepted(false).isApproved(false).sellerUserId(organisationSignUpRequest.getSellerUserId())
				.registrationStatus(RegistrationStatus.STEP2).managerName(organisationSignUpRequest.getManagerName())
				.pincode(organisationSignUpRequest.getPinCode()).referredBy(organisationSignUpRequest.getReferredBy())
				.addressLine1(organisationSignUpRequest.getAddressLine1())
				.addressLine2(organisationSignUpRequest.getAddressLine2()).build();

		sellerEntity.setId(seller.getId());
		sellerEntity.setWhatsAppNumber(seller.getWhatsAppNumber());
		organisationRepository.save(sellerEntity);

		user.setRegistrationStatus(RegistrationStatus.STEP2);
		userRepository.save(user);

		SellerProfileResponse response = new SellerProfileResponse();
		response.setSellerId(seller.getId());
		response.setStatus(user.getRegistrationStatus());

		return response;

	}

	@Override
	public SellerDetailResponse getSellerDetail(Long sellerId) {

		SellerOrganisationBranchEntity sellerEntity = organisationRepository.findById(sellerId)

				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.SELLER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.SELLER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.SELLER_DOES_NOT_EXIST_MESSAGE));

		String sellerName = sellerEntity.getBranchName();
		if (sellerEntity.getSellerName() != null) {
			sellerName = sellerEntity.getSellerName();
		}

		Optional<User> userEntity=userRepository.findById(sellerEntity.getSellerUserId());
		SellerDetailResponse response = SellerDetailResponse.builder().businessName(sellerEntity.getBusinessName())
				.sellerId(sellerEntity.getId()).branchName(sellerEntity.getBranchName())
				.address(sellerEntity.getAddressLine1()).city(sellerEntity.getCity()).pincode(sellerEntity.getPincode())
				.whatsAppNumber(sellerEntity.getWhatsAppNumber())
				.isAgreementAccepted(sellerEntity.getIsAgreementAccepted()).isApproved(sellerEntity.getIsApproved())
				.managerName(sellerEntity.getManagerName()).referredBy(sellerEntity.getReferredBy())
				.requestRejectionTime(sellerEntity.getRequestRejectionTime())
				.registrationStatus(
						userEntity.get().getRegistrationStatus())
				.sellerName(sellerName).maxDiscount(sellerEntity.getMaxdiscount()).gstNo(sellerEntity.getGstNo())
				.bankAccountNo(sellerEntity.getBankAccNo()).benefeciaryName(sellerEntity.getBeneficiaryName())
				.ifscCode(sellerEntity.getIfsc()).sellerPhoneNumber(sellerEntity.getWhatsAppNumber())
				.longitude(sellerEntity.getLongitude()).latitude(sellerEntity.getLatitude())
				.gstNo(sellerEntity.getGstNo())
				.userId(userEntity.get().getId()).build();

		SellerDiscountEntity discountEntity = sellerDiscountRepository.findBySellerId(sellerEntity);
		if (discountEntity != null) {
			Date createdDate = discountEntity.getCreated();

			Calendar c = Calendar.getInstance();
			c.setTime(createdDate);
			c.add(Calendar.DATE, 7);
			Date responseD = c.getTime();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String submitDate = formatter.format(createdDate);
			String responseDate = formatter.format(responseD);
			response.setSubmittedDate(submitDate);
			response.setResponseDate(responseDate);
			response.setDiscountFrom(discountEntity.getDiscountFrom());
			response.setDiscountTo(discountEntity.getDiscountTo());
		}

		return response;
	}

	@Override
	public SellerDetailListResponse getSellerList(GetSellerListRequest getSellerListRequest) {

		Pageable page = PageRequest.of(getSellerListRequest.getPageNo(), getSellerListRequest.getPageSize(),
				Sort.by("created").descending());

		SellerDetailListResponse response = new SellerDetailListResponse();

		if (getSellerListRequest.getRegistrationStatus() != null && getSellerListRequest.getName() == null) {

			if (getSellerListRequest.getRegistrationStatus() == RegistrationStatus.All) {
				Page<SellerOrganisationBranchEntity> sellerPage = organisationRepository.findAll(page);
				List<SellerOrganisationBranchEntity> sellerList = sellerPage.getContent();
				response.setSellerList(sellerList.stream().map(
						seller -> convertToSellerListResponse(seller, userService.findById(seller.getSellerUserId())))
						.collect(Collectors.toList()));
				response.setNoOfPagesAsPerPageLimit(sellerPage.getTotalPages());
			} else {
				System.out.println("LV");
				Page<SellerOrganisationBranchEntity> sellerPage = organisationRepository
						.findAllByRegistrationStatusOrderByCreatedDesc(getSellerListRequest.getRegistrationStatus(),
								page);
				List<SellerOrganisationBranchEntity> sellerList = sellerPage.getContent();
				response.setSellerList(sellerList.stream().map(
						seller -> convertToSellerListResponse(seller, userService.findById(seller.getSellerUserId())))
						.collect(Collectors.toList()));
				response.setNoOfPagesAsPerPageLimit(sellerPage.getTotalPages());
			}

		} else if (getSellerListRequest.getName() != null && getSellerListRequest.getRegistrationStatus() == null) {
			Page<SellerOrganisationBranchEntity> sellerPage = organisationRepository
					.findAllBySellerNameContainsOrBranchNameContainsOrderByCreatedDesc(getSellerListRequest.getName(),getSellerListRequest.getName(), page);
			List<SellerOrganisationBranchEntity> sellerList = sellerPage.getContent();
			response.setSellerList(sellerList.stream()
					.map(seller -> convertToSellerListResponse(seller, userService.findById(seller.getSellerUserId())))
					.collect(Collectors.toList()));
			response.setNoOfPagesAsPerPageLimit(sellerPage.getTotalPages());
		} else if (getSellerListRequest.getName() != null && getSellerListRequest.getRegistrationStatus() != null) {

			if (getSellerListRequest.getRegistrationStatus() == RegistrationStatus.All) {
				Page<SellerOrganisationBranchEntity> sellerPage = organisationRepository
						.findAllBySellerNameContainsOrBranchNameContainsOrderByCreatedDesc(getSellerListRequest.getName(),getSellerListRequest.getName(), page);
				List<SellerOrganisationBranchEntity> sellerList = sellerPage.getContent();
				response.setSellerList(sellerList.stream().map(
						seller -> convertToSellerListResponse(seller, userService.findById(seller.getSellerUserId())))
						.collect(Collectors.toList()));
				response.setNoOfPagesAsPerPageLimit(sellerPage.getTotalPages());
			} else {

				Page<SellerOrganisationBranchEntity> sellerPage = organisationRepository
						.findAllByRegistrationStatusAndSellerNameContainsOrBranchNameContainsOrderByCreatedDesc(
								getSellerListRequest.getRegistrationStatus(), getSellerListRequest.getName(),getSellerListRequest.getName(), page);
				List<SellerOrganisationBranchEntity> sellerList = sellerPage.getContent();
				response.setSellerList(sellerList.stream().map(
						seller -> convertToSellerListResponse(seller, userService.findById(seller.getSellerUserId())))
						.collect(Collectors.toList()));
				response.setNoOfPagesAsPerPageLimit(sellerPage.getTotalPages());
			}
		} else {
			Page<SellerOrganisationBranchEntity> sellerPage = organisationRepository.findAll(page);
			List<SellerOrganisationBranchEntity> sellerList = sellerPage.getContent();
			response.setSellerList(sellerList.stream()
					.map(seller -> convertToSellerListResponse(seller, userService.findById(seller.getSellerUserId())))
					.collect(Collectors.toList()));
			response.setNoOfPagesAsPerPageLimit(sellerPage.getTotalPages());
		}

		return response;

	}

	@Override
	public SellerDiscountResponse sellerDiscount(DiscountRequest discount) {

		SellerOrganisationBranchEntity sellerEntity = organisationRepository.findById(discount.getSellerId())

				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.SELLER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.SELLER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.SELLER_DOES_NOT_EXIST_MESSAGE));
		
		if(sellerEntity.getRegistrationStatus().ordinal()>=RegistrationStatus.VALIDATING.ordinal())
		{
			throw new FailedToSaveResourceException(AppConstant.ErrorTypes.SELLER_DISCOUNT_ALREADY_ADDED_ERROR,
					AppConstant.ErrorCodes.ALREADY_CREATED_ERROR_CODE,
					AppConstant.ErrorMessages.SELLER_DISCOUNT_ALRADY_ADDED_MESSAGE);
		}

		User user = userRepository.findById(sellerEntity.getSellerUserId())
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.USER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
						AppConstant.ErrorMessages.USER_DOES_NOT_EXIST_MESSAGE));

		Optional<CategoryEntity> category = categoryRepository.findById((long) 1);

		SellerDiscountResponse response = new SellerDiscountResponse();

		SellerDiscountEntity discountEntity = sellerDiscountRepository.findBySellerId(sellerEntity);

		if (discountEntity != null) {

			Date createdDate = discountEntity.getCreated();
			Calendar c = Calendar.getInstance();
			c.setTime(createdDate);
			c.add(Calendar.DATE, 7);
			Date responseD = c.getTime();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String submitDate = formatter.format(createdDate);
			String responseDate = formatter.format(responseD);

			discountEntity.setDiscountFrom(discount.getDiscountFrom());
			discountEntity.setDiscountTo(discount.getDiscountTo());
			sellerDiscountRepository.save(discountEntity);

			response.setDiscountFrom(discountEntity.getDiscountFrom());
			response.setDiscounTo(discountEntity.getDiscountTo());
			response.setSellerId(discount.getSellerId());
			response.setSubmittedDate(submitDate);
			response.setResponseDate(responseDate);
		} else {
			SellerDiscountEntity discountEntity1 = SellerDiscountEntity.builder().categoryId(category.get())
					.discountFrom(discount.getDiscountFrom()).discountTo(discount.getDiscountTo())
					.sellerId(sellerEntity).build();
			sellerDiscountRepository.save(discountEntity1);

			Date createdDate = discountEntity1.getCreated();
			Calendar c = Calendar.getInstance();
			c.setTime(createdDate);
			c.add(Calendar.DATE, 7);
			Date responseD = c.getTime();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String submitDate = formatter.format(createdDate);
			String responseDate = formatter.format(responseD);

			response.setDiscountFrom(discountEntity1.getDiscountFrom());
			response.setDiscounTo(discountEntity1.getDiscountTo());
			response.setSellerId(discount.getSellerId());
			response.setSubmittedDate(submitDate);
			response.setResponseDate(responseDate);

		}
		user.setRegistrationStatus(RegistrationStatus.VALIDATING);
		userRepository.save(user);
		sellerEntity.setRegistrationStatus(RegistrationStatus.VALIDATING);
		sellerEntity.setMaxdiscount(discount.getDiscountTo());
		organisationRepository.save(sellerEntity);
		response.setRegistrationStatus(user.getRegistrationStatus());
		return response;
	}

	@Override
	public CommonSuccessResponse updateSeller(UpdateSellerRequest updateSellerRequest) {

		if (updateSellerRequest.getSellerId() == null || updateSellerRequest.getAgentId() == null) {
			throw new InvalidIdException(AppConstant.ErrorTypes.ID_NULL_EXIST_ERROR,
					AppConstant.ErrorCodes.ID_NULL_ERROR_CODE, AppConstant.ErrorMessages.ID_EMPTY_MESSAGE);
		}

		User agent = userService.findById(updateSellerRequest.getAgentId());
		SellerOrganisationBranchEntity sellerEntity = organisationRepository.findById(updateSellerRequest.getSellerId())

				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.SELLER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.SELLER_DOES_NOT_EXIST_ERROR_CODE,
						AppConstant.ErrorMessages.SELLER_DOES_NOT_EXIST_MESSAGE));

		User user = userRepository.findById(sellerEntity.getSellerUserId())
				.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.USER_DOES_NOT_EXIST_ERROR,
						AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
						AppConstant.ErrorMessages.USER_DOES_NOT_EXIST_MESSAGE));

		CommonSuccessResponse response = new CommonSuccessResponse();

		if (updateSellerRequest.getBranchName() != null) {
			sellerEntity.setBranchName(updateSellerRequest.getBranchName());
		}

		if (updateSellerRequest.getBusinessName() != null) {
			sellerEntity.setBusinessName(updateSellerRequest.getBusinessName());
		}

		if (updateSellerRequest.getManagerName() != null) {
			sellerEntity.setManagerName(updateSellerRequest.getManagerName());
		}

		if (updateSellerRequest.getAddress() != null) {
			sellerEntity.setAddressLine1(updateSellerRequest.getAddress());
		}

		if (updateSellerRequest.getCity() != null) {
			sellerEntity.setCity(updateSellerRequest.getCity());
		}

		if (updateSellerRequest.getPinCode() != null) {
			sellerEntity.setPincode(updateSellerRequest.getPinCode());
		}
		if (updateSellerRequest.getLatitude() != 0) {
			sellerEntity.setLatitude(updateSellerRequest.getLatitude());
		}

		if (updateSellerRequest.getLongitude() != 0) {
			sellerEntity.setLongitude(updateSellerRequest.getLongitude());
		}

		if (updateSellerRequest.getMaxdiscount() != 0) {
			sellerEntity.setMaxdiscount(updateSellerRequest.getMaxdiscount());
		}

		if (updateSellerRequest.getBankAccountNo() != null) {
			sellerEntity.setBankAccNo(updateSellerRequest.getBankAccountNo());
		}

		if (updateSellerRequest.getIfscCode() != null) {
			sellerEntity.setIfsc(updateSellerRequest.getIfscCode());
		}
		if (updateSellerRequest.getBenefeciaryName() != null) {
			sellerEntity.setBeneficiaryName(updateSellerRequest.getBenefeciaryName());
		}

		if (updateSellerRequest.getSellerName() != null) {
			user.setName(updateSellerRequest.getSellerName());
			sellerEntity.setSellerName(updateSellerRequest.getSellerName());
		}
		if (updateSellerRequest.getGstNo() != null) {
			sellerEntity.setGstNo(updateSellerRequest.getGstNo());
		}
		if (updateSellerRequest.getSellerContact() != null) {
			user.setPhoneNumber(updateSellerRequest.getSellerContact());
			sellerEntity.setWhatsAppNumber(updateSellerRequest.getSellerContact());
		}

		SellerDiscountEntity sellerDiscount = sellerDiscountRepository.findBySellerId(sellerEntity);

		if (updateSellerRequest.getMinDiscount() != 0) {
			sellerDiscount.setDiscountFrom(updateSellerRequest.getMinDiscount());
		}

		if (updateSellerRequest.getMaxdiscount() != 0) {
			sellerDiscount.setDiscountTo(updateSellerRequest.getMaxdiscount());
		}

		try {
			sellerEntity.setUpdated(new Date());
			sellerEntity.setUpdatedBy(agent.getName());
			sellerDiscount.setUpdated(new Date());
			sellerDiscount.setUpdatedBy(agent.getName());
			organisationRepository.save(sellerEntity);
			sellerDiscountRepository.save(sellerDiscount);
			userRepository.save(user);
			response.setSuccess(true);
		} catch (Exception e) {
			response.setSuccess(false);
		}

		return response;
	}

	public SellerDetailResponse convertToSellerListResponse(SellerOrganisationBranchEntity sellerEntity,
			User sellerUserDetails) {

		List<SellerDiscountEntity> sellerDiscountEntity = sellerDiscountRepository.findAllBySellerId(sellerEntity);

		String sellerName = sellerEntity.getBranchName();
		if (sellerEntity.getSellerName() != null) {
			sellerName = sellerEntity.getSellerName();
		}

		if (sellerDiscountEntity.size() != 0) {
			return SellerDetailResponse.builder().businessName(sellerEntity.getBusinessName())
					.sellerId(sellerEntity.getId()).branchName(sellerEntity.getBranchName())
					.address(sellerEntity.getAddressLine1()).city(sellerEntity.getCity())
					.pincode(sellerEntity.getPincode()).whatsAppNumber(sellerEntity.getWhatsAppNumber())
					.sellerName(sellerName).discountTo(sellerDiscountEntity.get(0).getDiscountTo())
					.discountFrom(sellerDiscountEntity.get(0).getDiscountFrom())
					.sellerPhoneNumber(sellerUserDetails.getPhoneNumber())
					.isAgreementAccepted(sellerEntity.getIsAgreementAccepted()).isApproved(sellerEntity.getIsApproved())
					.managerName(sellerEntity.getManagerName()).referredBy(sellerEntity.getReferredBy())
					.registrationStatus(sellerEntity.getRegistrationStatus()).gstNo(sellerEntity.getGstNo())
					.bankAccountNo(sellerEntity.getBankAccNo()).benefeciaryName(sellerEntity.getBeneficiaryName())
					.ifscCode(sellerEntity.getIfsc()).maxDiscount(sellerEntity.getMaxdiscount())
					.addedBy(sellerEntity.getCreatedBy()).latitude(sellerEntity.getLatitude())
					.longitude(sellerEntity.getLongitude()).requestRejectionTime(sellerEntity.getRequestRejectionTime())
					.lmb(sellerEntity.getUpdatedBy()).build();
		} else {
			return SellerDetailResponse.builder().businessName(sellerEntity.getBusinessName())
					.sellerId(sellerEntity.getId()).branchName(sellerEntity.getBranchName())
					.address(sellerEntity.getAddressLine1()).city(sellerEntity.getCity())
					.pincode(sellerEntity.getPincode()).whatsAppNumber(sellerEntity.getWhatsAppNumber())
					.sellerName(sellerName).sellerPhoneNumber(sellerUserDetails.getPhoneNumber())
					.registrationStatus(sellerEntity.getRegistrationStatus())
					.isAgreementAccepted(sellerEntity.getIsAgreementAccepted()).isApproved(sellerEntity.getIsApproved())
					.managerName(sellerEntity.getManagerName()).referredBy(sellerEntity.getReferredBy())
					.gstNo(sellerEntity.getGstNo()).bankAccountNo(sellerEntity.getBankAccNo())
					.benefeciaryName(sellerEntity.getBeneficiaryName()).ifscCode(sellerEntity.getIfsc())
					.maxDiscount(sellerEntity.getMaxdiscount()).addedBy(sellerEntity.getCreatedBy())
					.requestRejectionTime(sellerEntity.getRequestRejectionTime()).lmb(sellerEntity.getUpdatedBy())
					.build();
		}
	}

	@Override
	public SellerOrganisationBranchEntity getSellerOrganisationByUserID(Long userId) {
		List<SellerOrganisationBranchEntity> seller = organisationRepository.findAllBySellerUserId(userId);
		if (seller.size() > 0) {
			return seller.get(0);
		} else {
			return null;
		}
	}

	@Override
	public SellerOrganisationBranchEntity getSellerOrganizationBranchEntity(Long sellerId) {
		if (sellerId == null) {
			throw new InvalidInputException(AppConstant.ErrorTypes.ID_NULL_EXIST_ERROR,
					AppConstant.ErrorCodes.ID_NULL_ERROR_CODE, AppConstant.ErrorMessages.ID_EMPTY_MESSAGE);
		} else {
			return organisationRepository.findById(sellerId)
					.orElseThrow(() -> new ResourceNotFoundException(AppConstant.ErrorTypes.SELLER_DOES_NOT_EXIST_ERROR,
							AppConstant.ErrorCodes.SELLER_DOES_NOT_EXIST_ERROR_CODE,
							AppConstant.ErrorMessages.SELLER_DOES_NOT_EXIST_MESSAGE));
		}
	}
}
