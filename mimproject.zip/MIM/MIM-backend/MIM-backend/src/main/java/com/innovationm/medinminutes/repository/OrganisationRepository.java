package com.innovationm.medinminutes.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.innovationm.medinminutes.entity.SellerOrganisationBranchEntity;
import com.innovationm.medinminutes.enums.RegistrationStatus;

@Repository
public interface OrganisationRepository extends JpaRepository<SellerOrganisationBranchEntity, Long> {

	public Page<SellerOrganisationBranchEntity> findAllByRegistrationStatusOrderByCreatedDesc(
			RegistrationStatus registrationStatus, Pageable pageable);

	public Page<SellerOrganisationBranchEntity> findAllBySellerNameContainsOrBranchNameContainsOrderByCreatedDesc(String sellerName,
			String branchName,Pageable pageable);

	public Page<SellerOrganisationBranchEntity> findAll(Pageable pageable);

	public List<SellerOrganisationBranchEntity> findAllBySellerUserId(long userId);

	public SellerOrganisationBranchEntity findBySellerUserId(long sellerId);

	public Page<SellerOrganisationBranchEntity> findAllByRegistrationStatusAndSellerNameContainsOrBranchNameContainsOrderByCreatedDesc(
			RegistrationStatus registrationStatus, String name,String branchName, Pageable page);

}
