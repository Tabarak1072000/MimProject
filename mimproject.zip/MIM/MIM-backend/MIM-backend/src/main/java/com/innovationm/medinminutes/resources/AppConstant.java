package com.innovationm.medinminutes.resources;

public interface AppConstant {

	public interface Config {
		//public static final String APPLICATION_PROPERTY_SOURCE_PATH = "classpath:application.properties";

		 public static final String APPLICATION_PROPERTY_SOURCE_PATH = "file:///C:/Mimproperties/application.properties";

//		 public static final String APPLICATION_PROPERTY_SOURCE_PATH =
//		 "file:///mnt/medinminutes/properties/application.properties";

	}

	public interface StatusCodes {
		int SUCCESS = 0;
		int FAILURE = 1;
	}

	public interface ErrorTypes {
		String INVALID_INPUT_ERROR = "Invalid Input";
		String USER_ALREADY_EXIST_ERROR = "User Already Exist.";
		String FAILED_TO_SEND_OTP_ON_PHONE_ERROR = "Failed To Send OTP";
		String USER_NOT_EXIST_ERROR = "User Not Found";
		String PASSWORD_MISMATCH_ERROR = "Password Mismatch";
		String USER_DOES_NOT_EXIST_ERROR = "User does not exist";
		String OTP_MISMATCH_ERROR = "Otp mismatch";
		String SELLER_DOES_NOT_EXIST_ERROR = "Seller does not exist";
		String ID_NULL_EXIST_ERROR = "Id Null";
		String ROLE_NOT_EXIST_ERROR = "Role Not Exist.";
		String SELLER_DISCOUNT_NOT_EXIST_ERROR = "Seller Discount data not present";
		String SELLER_ALREADY_CREATED_ERROR = "Seller Already created";
		String SELLER_DISCOUNT_ALREADY_ADDED_ERROR = "Seller Discount Already added";

		String ORDER_NOT_EXIST_ERROR = "Order Not Exist.";
		String INVENTORY_NOT_EXIST_ERROR = "Inventory Not Exist.";
		String CATEGORY_NOT_EXIST_ERROR = "Category Not Exist.";

		String ORDER_DOES_NOT_EXIST_ERROR = "order not exist";
		String ORDER_ITEM_NOT_EXIST_ERROR = "Order Item not Exist.";
		String FAILED_TO_UPDATE_RESOURCE_ERROR = "Order Item not Exist.";
		String SELLER_BIDDING_MEDICINE_NOT_EXIST_ERROR = "Seller Bidding Medicine Not Exist.";
		String ALREADY_BUZZED_ERROR = "Already buzzed ";
		String PERMISSION_ERROR = " Access Denied ";
		String CLIENT_ORDERID_ALREADY_EXIST_ERROR = " Already exist";
		String INVENTORY_EXIST_ERROR = "Already exist";
		String ALREADY_ADDED_ITEM_ERROR = "This item is already added";
		String BUZZ_PAUSED_ERROR = "Buzz Paused";
		String QUANTITY_NOT_AVL_ERROR = "No more quantity";

	}

	public interface ErrorCodes {
		String USER_ALREADY_EXIST_ERROR_CODE = "101";
		String INVALID_INPUT_ERROR_CODE = "102";
		String FAILED_TO_SEND_OTP_ON_PHONE_ERROR_CODE = "103";

		String USER_DOES_NOT_EXISTS_ERROR_CODE = "104";
		String PASSWORD_MISMATCH_ERROR_CODE = "105";

		String OTP_MISMATCH_ERROR_CODE = "202";
		String SELLER_DOES_NOT_EXIST_ERROR_CODE = "203";
		String ID_NULL_ERROR_CODE = "204";
		String ROLE_ERROR_CODE = "205";
		String SELLER_DISCOUNT_NOT_EXIST_ERROR_CODE = "206";
		String ORDER_DOES_NOT_EXIST_ERROR_CODE = "207";
		String SELLER_BIDDING_MEDICINE_ERROR_CODE = "209";

		String INVENTORY_ERROR_CODE = "207";
		String CATEGORY_ERROR_CODE = "208";

		String ORDER_ERROR_CODE = "301";
		String FAILED_TO_UPDATE_RESOURCE_ERROR_CODE = "401";
		String ALREADY_BUZZED_ERROR_CODE = "303";
		String USER_VALIDATION_ERROR_CODE = "402";
		String CLIENT_ORDERID_ALREADY_EXIST_ERROR_CODE = "405";
		String INVENTORY_EXIST_ERROR_CODE = "210";
		String ALREADY_ADDED_ITEM_ERROR_CODE = "406";
		String BUZZ_PAUSED_ERROR_CODE = "407";
		String ALREADY_CREATED_ERROR_CODE = "408";
		String QUANTITY_NOT_AVL_ERROR_CODE = "409";

	}

	public interface ErrorMessages {
		String PHONE_NUMBER_ALREADY_EXIST_MESSAGE = "Phone Number Already Exist.";
		String USER_NOT_EXIST_MESSAGE = "User Doest Not Exists.";
		String EMAIL_CREDENTIALS_MESSAGE = "Invalid User Credentials";
		String EMAIL_ALREADY_EXIST_MESSAGE = "Email Already Exist.";
		String FAILED_TO_SEND_OTP_ON_PHONE_ERROR = "Failed To Send OTP On Phone.";
		String USER_DOES_NOT_EXIST_MESSAGE = "User does not exist.";
		String OTP_MISMATCH_ERROR_MESSAGE = "Invalid OTP. Please Retry.";
		String SELLER_DOES_NOT_EXIST_MESSAGE = "Seller does not exist.";
		String ID_EMPTY_MESSAGE = "Id Can't Be Null.";
		String ROLE_NOT_EXIST_MESSAGE = "Role Doesn't Exist.";
		String SELLER_DISCOUNT_NOT_EXIST_MESSAGE = "Seller discount data is empty";
		String SELLER_BIDDING_NOT_EXIST_MESSAGE = "Seller Bidding Doesn't Exist.";

		String ORDER_NOT_EXIST_MESSAGE = "Order Doesn't Exist.";
		String INVENTORY_NOT_EXIST_MESSAGE = "Inventory Doesn't Exist.";
		String CATEGORY_NOT_EXIST_MESSAGE = "Category Doesn't Exist.";

		String ORDER_DOES_NOT_EXIST_MESSAGE = " Order not found on this orderId";
		String ORDER_ITEM_NOT_EXIST_MESSAGE = "Order Item Doesn't Exist.";
		String FAILED_TO_DELETE_ITEM_MESSAGE = "Failed to delete Item.";

		String SELLER_BIDDING_MEDICINE_NOT_EXIST_MESSAGE = "Seller Bidding Medicine Doesn't Exist.";
		String ALREADY_BUZZED_ERROR_MESSAGE = " Seller Already Buzzed for this order";
		String PERMISSION_ERROR_MESSAGE = " Don't Have Permission To Login";
		String OTP_EXPIRED_ERROR_MESSAGE = "Entered OTP is Expired. Please resend again";
		String CLIENT_ORDERID_ALREADY_EXIST_ERROR_MESSAGE = "client OrderId Already Exist";
		String INVENTORY_EXIST_ERROR_MESSAGE = "Inventory Already exist";
		String ALREADY_ADDED_ITEM_ERROR_MESSAGE = "Item has already added in this order";
		String BUZZ_PAUSED_MESSAGE = "Buzz is Paused for the Order.";
		String BUZZ_PROCESSING_MESSAGE = "Buzzed is already started for this order";
		String SELLER_ORGANIZATION_ALRADY_CREATED_MESSAGE = "Seller already created.";
		String SELLER_DISCOUNT_ALRADY_ADDED_MESSAGE = "Seller Discount already added.";
		String QUANTITY_NOT_AVL_MESSAGE = "No more quantity is available";
	}

	public interface OtpService {

		public static final Integer OTP_EXPIRY_TIME = 1;
		public static final String OTP_SUBJECT_LINE = "MIM-OTP Verification";

	}

	public interface TwilioSmsService {

		public static final String ADMAGISTER_SENDERID = "INNFOX";
		public static final String MESSAGE = "Your MIM Verification OTP is : {var1}";

	}

	public interface OtpSmsService {

		public static final String USERID = "MovingPIN2017";
		public static final String PASSWORD = "dial$842";
		public static final String ADMAGISTER_CHANNEL = "Trans";
		public static final String ADMAGISTER_SENDERID = "INNFOX";
		public static final Integer ADMAGISTER_FLASH_SMS = 0;
		public static final Integer ADMAGISTER_DCS = 0;
		public static final Integer ADMAGISTER_ROUTE = 11;
		public static final String ADMAGISTERURL = "https://admagister.net/api/mt/SendSMS";
		public static final String MESSAGE = "Your FoxMatrix(INNFOX) verification OTP is : {var1}";

	}

	public interface SecretKey {
		public static final String SECRET_KEY = "`'+fao^~!^@*##j\nknlkvla";
	}

	public interface Commons {

		String USER_ACCOUNT_ID = "userId";

		String PAGE_NUMBER = "pageNo";
		String PAGE_LIMIT = "pageLimit";

		public static final String BLANK_STRING_VALUE = "";

		public static final Integer FLAG_VALUE_FOR_TOBID = 1;
		public static final Integer FLAG_VALUE_FOR_TOPACK = 2;
		public static final Integer FLAG_VALUE_FOR_SEND = 3;
		public static final Integer FLAG_VALUE_FOR_APPLICATION_ACCEPTED = 5;
		public static final Integer FLAG_VALUE_FOR_APPLICATION_REJECTED = 6;

	}

}
