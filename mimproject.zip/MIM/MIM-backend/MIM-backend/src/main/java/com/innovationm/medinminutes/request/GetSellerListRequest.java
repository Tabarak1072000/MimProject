package com.innovationm.medinminutes.request;

import com.innovationm.medinminutes.enums.RegistrationStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class GetSellerListRequest {

	private Integer pageNo;

	private Integer pageSize;
	
	private RegistrationStatus registrationStatus;
	
	private String name;

}
