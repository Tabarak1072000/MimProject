package com.innovationm.medinminutes.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.innovationm.medinminutes.entity.OrderEntity;
import com.innovationm.medinminutes.entity.OrderMedicineDetailsEntity;
import org.springframework.data.jpa.repository.Query;

public interface OrderMedicineDetailsRepository extends JpaRepository<OrderMedicineDetailsEntity, Long> {

	List<OrderMedicineDetailsEntity> findByOrderAndActive(OrderEntity order,boolean isActive);

	Page<OrderMedicineDetailsEntity> findByOrderAndActiveOrderByIdDesc(OrderEntity order,boolean isActive, Pageable page);


	List<OrderMedicineDetailsEntity> findByOrderId(Long orderId);
	

	@Query("Select SUM(o.quantityRequired) from OrderMedicineDetailsEntity o where o.order =:order")
	Long getTotalQuantity(OrderEntity order);

	OrderMedicineDetailsEntity findByOrderIdAndInventoryId(long orderId, long inventoryId);

	List<OrderMedicineDetailsEntity> findAllByOrderIdAndInventoryId(long orderId, long inventoryId);
}
